#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
s05_full_daily_rebuild.py — FULL history rebuild of DAILY bars (UTC)

- Tries a single bulk fetch with whatToShow=ADJUSTED_LAST (endDateTime MUST be "")
- If that yields no rows, falls back to chunked TRADES -> MIDPOINT with endDateTime paging
- Overwrites existing daily_raw files

Inputs:
  - ETF_list.xlsx (sheet auto: signals / signalsUSD unless you override --sheet)
  - optional mapping: <project>/config/ticker_mapping.csv  (semicolon-separated)

Outputs:
  <project>/data_raw/<TARGET_BUCKET>/daily/{TICKER}_daily_raw.csv  (UTC)
  columns: date,open,high,low,close,volume,average,barCount
"""

from __future__ import annotations

from pathlib import Path
from datetime import datetime, timedelta, timezone
import argparse
import os
import sys
import pandas as pd
from ib_insync import IB, Contract, util

# ---------------- bootstrapping: make 'common' importable ----------------
SCRIPT_DIR   = Path(__file__).resolve().parent          # .../QuantETF*/scripts
PROJECT_ROOT = SCRIPT_DIR.parent                        # .../QuantETF*
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

# ---------------- shared paths & settings ----------------
from common.paths import P

try:
    from common.settings import TARGET_BUCKET, default_etf_sheet
except Exception:
    TARGET_BUCKET = "targeted_ETFs"
    def default_etf_sheet() -> str:
        return "signalsUSD" if PROJECT_ROOT.name.endswith("US") else "signals"

DEFAULT_CCY = "USD" if PROJECT_ROOT.name.endswith("US") else "EUR"

RAW_BUCKET = P.DATA_RAW / TARGET_BUCKET
DIR_DAILY  = RAW_BUCKET / "daily"
DIR_DAILY.mkdir(parents=True, exist_ok=True)

EXCEL_LIST       = str(P.ETF_LIST)
EXCEL_SHEET      = default_etf_sheet()
EXCEL_TICKER_COL = "Ticker"
MAPPING_CSV      = str(P.CONFIG_DIR / "ticker_mapping.csv")

# ---------------- helpers ----------------
def _fmt_ib_time(ts: datetime) -> str:
    # IBKR expects local-like string "YYYYMMDD HH:MM:SS" (UTC works fine)
    return ts.strftime("%Y%m%d %H:%M:%S")

def load_tickers_from_excel(path_xlsx: str, sheet: str, col_name: str) -> list[str]:
    df = pd.read_excel(path_xlsx, sheet_name=sheet)
    colmap = {c.lower(): c for c in df.columns}
    key = col_name.lower()
    if key not in colmap:
        raise ValueError(f"Column '{col_name}' not found in {path_xlsx} (sheet '{sheet}').")
    tickers = df[colmap[key]].astype(str).str.strip().str.upper()
    return [t for t in tickers.unique().tolist() if t]

def load_mapping(path_csv: str) -> dict:
    """Optional mapping for IBKR contracts; CSV is semicolon-separated."""
    if not os.path.isfile(path_csv):
        return {}
    df = pd.read_csv(path_csv, sep=";")
    need = {"Ticker","SecType","Exchange","Currency","PrimaryExchange"}
    if not need.issubset(set(df.columns)):
        raise ValueError(f"{path_csv} must contain columns: {need}")
    mp = {}
    for _, r in df.iterrows():
        t = str(r["Ticker"]).strip().upper()
        mp[t] = {
            "SecType":         (str(r.get("SecType", "STK")).strip() or "STK").upper(),
            "Exchange":        str(r.get("Exchange", "SMART")).strip() or "SMART",
            "Currency":        (str(r.get("Currency", DEFAULT_CCY)).strip() or DEFAULT_CCY).upper(),
            "PrimaryExchange": str(r.get("PrimaryExchange", "")).strip() or ""
        }
    return mp

def make_contract(ticker: str, mapping: dict) -> Contract:
    m = mapping.get(ticker.upper(), {})
    c = Contract()
    c.symbol          = ticker
    c.secType         = m.get("SecType", "STK")
    c.exchange        = m.get("Exchange", "SMART")
    c.currency        = m.get("Currency", DEFAULT_CCY)
    pe = m.get("PrimaryExchange", "")
    if pe:
        c.primaryExchange = pe
    return c

def _normalize_hist_df(df: pd.DataFrame) -> pd.DataFrame:
    if df is None or df.empty:
        return pd.DataFrame(columns=["date","open","high","low","close","volume","average","barCount"])
    # ib_insync util.df() typically returns date + OHLCV + average + barCount
    for col in ["open","high","low","close","volume","average","barCount"]:
        if col not in df.columns:
            df[col] = pd.NA
    df["date"] = pd.to_datetime(df["date"], utc=True, errors="coerce")
    for c in ["open","high","low","close","volume","average","barCount"]:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    return df[["date","open","high","low","close","volume","average","barCount"]]

# ---- Strategy A: single bulk ADJUSTED_LAST (no endDateTime allowed) ----
def fetch_daily_bulk_adjusted(ib: IB, contract: Contract, years: int, use_rth: bool) -> pd.DataFrame:
    bars = ib.reqHistoricalData(
        contract,
        endDateTime="",                       # CRUCIAL for ADJUSTED_LAST
        durationStr=f"{years} Y",
        barSizeSetting="1 day",
        whatToShow="ADJUSTED_LAST",
        useRTH=use_rth,
        formatDate=1,
        keepUpToDate=False,
    )
    return _normalize_hist_df(util.df(bars)) if bars else pd.DataFrame()

# ---- Strategy B: chunked paging with TRADES -> MIDPOINT fallbacks ----
def fetch_daily_chunk(ib: IB, contract: Contract, end_ts: datetime, duration: str, use_rth: bool) -> pd.DataFrame:
    # Try TRADES first; if empty, try MIDPOINT for the same window
    for what in ("TRADES", "MIDPOINT"):
        bars = ib.reqHistoricalData(
            contract,
            endDateTime=_fmt_ib_time(end_ts),
            durationStr=duration,
            barSizeSetting="1 day",
            whatToShow=what,
            useRTH=use_rth,
            formatDate=1,
            keepUpToDate=False,
        )
        if bars:
            df = _normalize_hist_df(util.df(bars))
            if not df.empty:
                df["__what"] = what
                return df
    return pd.DataFrame(columns=["date","open","high","low","close","volume","average","barCount","__what"])

def backfill_daily(ib: IB, contract: Contract, years: int, use_rth: bool) -> pd.DataFrame:
    # 1) Try bulk ADJUSTED_LAST once
    df_adj = fetch_daily_bulk_adjusted(ib, contract, years=years, use_rth=use_rth)
    if not df_adj.empty:
        df_adj["__what"] = "ADJUSTED_LAST"
        return df_adj.sort_values("date").drop_duplicates(subset=["date"]).reset_index(drop=True)

    # 2) Fallback: walk backwards in chunks with TRADES/MIDPOINT
    #    Use larger windows for speed; IB is OK with ~1 Y windows for daily bars.
    end = datetime.now(timezone.utc).replace(microsecond=0)
    earliest = end - timedelta(days=int(years * 365.25) + 5)
    duration = "365 D"  # ~1 year per request

    rows = []
    last_edge = end
    guard = 0
    while last_edge > earliest and guard < 100:
        guard += 1
        df = fetch_daily_chunk(ib, contract, end_ts=last_edge, duration=duration, use_rth=use_rth)
        if df.empty:
            # step back a bit to avoid getting stuck on empty windows
            last_edge = last_edge - timedelta(days=365)
            continue
        rows.append(df)
        # next window ends at the earliest date we just got minus one day
        new_last = pd.to_datetime(df["date"].min(), utc=True) - timedelta(days=1)
        if new_last >= last_edge:
            break
        last_edge = new_last

    if not rows:
        return pd.DataFrame(columns=["date","open","high","low","close","volume","average","barCount"])

    out = pd.concat(rows, ignore_index=True)
    out = out.drop_duplicates(subset=["date"]).sort_values("date").reset_index(drop=True)
    # optional: drop the trace column
    if "__what" in out.columns:
        out = out.drop(columns=["__what"])
    return out

def save_overwrite(path_csv: str, df: pd.DataFrame):
    os.makedirs(os.path.dirname(path_csv), exist_ok=True)
    df = df.drop_duplicates(subset=["date"]).sort_values("date")
    df.to_csv(path_csv, index=False)

# ---------------- main ----------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=7496)
    ap.add_argument("--client_id", type=int, default=58)
    ap.add_argument("--years", type=int, default=10, help="How many years of daily history to rebuild.")
    ap.add_argument("--use_rth", type=int, default=1, help="1 = RTH bars; 0 = all sessions")
    ap.add_argument("--excel", default=str(EXCEL_LIST))
    ap.add_argument("--sheet", default=str(EXCEL_SHEET))
    ap.add_argument("--ticker_col", default=str(EXCEL_TICKER_COL))
    ap.add_argument("--mapping", default=str(MAPPING_CSV))
    ap.add_argument("--limit", type=int, default=0, help="Limit number of tickers (0 = all)")
    args = ap.parse_args()

    tickers = load_tickers_from_excel(args.excel, args.sheet, args.ticker_col)
    if args.limit and args.limit > 0:
        tickers = tickers[: args.limit]
    mapping = load_mapping(args.mapping)

    ib = IB()
    print(f"[IB] Connecting {args.host}:{args.port} (clientId={args.client_id}) …")
    ib.connect(args.host, args.port, clientId=args.client_id, readonly=True)
    print("[IB] Connected.")

    for i, t in enumerate(tickers, 1):
        try:
            contract = make_contract(t, mapping)
            qualified = ib.qualifyContracts(contract)
            if not qualified:
                print(f"[{i}/{len(tickers)}] {t}: could not qualify contract; skipping.")
                continue
            c = qualified[0]
            df = backfill_daily(ib, c, years=args.years, use_rth=bool(args.use_rth))
            if df.empty:
                print(f"[{i}/{len(tickers)}] {t}: no history returned.")
                continue
            out_path = str(DIR_DAILY / f"{t}_daily_raw.csv")
            save_overwrite(out_path, df)
            print(f"[{i}/{len(tickers)}] {t}: wrote {len(df)} rows → {out_path}")
            ib.sleep(0.2)
        except Exception as e:
            print(f"[{i}/{len(tickers)}] {t}: ERROR: {e}")

    ib.disconnect()
    print("[DONE] s05_full_daily_rebuild complete.")

if __name__ == "__main__":
    main()