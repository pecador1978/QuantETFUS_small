#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
s12_ibkr_download_weekly.py — Append-only weekly updater (IBKR via ib_insync, UTC-only)

Reads tickers from ETF_list.xlsx (sheet defaults to common.settings.default_etf_sheet)
and appends ONLY missing weekly bars into:
  <project>/data_raw/<BUCKET>/weekly/{TICKER}_weekly_raw.csv

Clone-friendly:
- Defaults (sheet & bucket) come from common.settings, but can be overridden via CLI.
- Optional mapping in config/ticker_mapping.csv (semicolon-separated).
"""

from pathlib import Path
import os, sys, argparse
import pandas as pd
from ib_insync import IB, Contract, util

# ---------------- bootstrapping ----------------
SCRIPT_DIR   = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parent
if str(PROJECT_ROOT) not in sys.path: sys.path.insert(0, str(PROJECT_ROOT))

from common.paths import P as _P
try:
    from common.settings import TARGET_BUCKET as SETTINGS_BUCKET, default_etf_sheet as settings_default_sheet
except Exception:
    SETTINGS_BUCKET = "targeted_ETFs"
    def settings_default_sheet() -> str:
        from common.paths import default_etf_sheet as shared_default
        return shared_default()

DEFAULT_CCY = "USD" if PROJECT_ROOT.name.endswith("US") else "EUR"

EXCEL_LIST       = str(_P.ETF_LIST)
EXCEL_TICKER_COL = "Ticker"
MAPPING_CSV      = str(_P.CONFIG_DIR / "ticker_mapping.csv")

# ---------------- helpers ----------------
def load_tickers_from_excel(path_xlsx: str, sheet: str, col_name: str) -> list[str]:
    df = pd.read_excel(path_xlsx, sheet_name=sheet)
    key = {c.lower(): c for c in df.columns}[col_name.lower()]
    s = df[key].astype(str).str.strip().str.upper()
    return [t for t in s.unique().tolist() if t]

def load_mapping(path_csv: str) -> dict:
    if not os.path.isfile(path_csv): return {}
    df = pd.read_csv(path_csv, sep=";")
    need = {"Ticker","SecType","Exchange","Currency","PrimaryExchange"}
    if not need.issubset(df.columns):
        raise SystemExit(f"[ERR] {path_csv} must have columns: {need}")
    mp = {}
    for _, r in df.iterrows():
        t = str(r["Ticker"]).strip().upper()
        mp[t] = {
            "SecType":         (str(r.get("SecType","STK")).strip() or "STK").upper(),
            "Exchange":        str(r.get("Exchange","SMART")).strip() or "SMART",
            "Currency":        (str(r.get("Currency", DEFAULT_CCY)).strip() or DEFAULT_CCY).upper(),
            "PrimaryExchange": str(r.get("PrimaryExchange","")).strip()
        }
    return mp

def make_contract(ticker: str, mapping: dict) -> Contract:
    m = mapping.get(ticker.upper(), {})
    c = Contract()
    c.symbol   = ticker
    c.secType  = m.get("SecType","STK")
    c.exchange = m.get("Exchange","SMART")
    c.currency = m.get("Currency", DEFAULT_CCY)
    pe = m.get("PrimaryExchange","")
    if pe: c.primaryExchange = pe
    return c

def fetch_weekly_df(ib: IB, contract: Contract, duration: str, what: str, use_rth: bool) -> pd.DataFrame:
    bars = ib.reqHistoricalData(
        contract,
        endDateTime="",
        durationStr=duration,
        barSizeSetting="1 week",
        whatToShow=what,
        useRTH=use_rth,
        formatDate=1,
        keepUpToDate=False,
    )
    if not bars:
        return pd.DataFrame(columns=["date","open","high","low","close","volume","average","barCount"])
    df = util.df(bars)
    if "date" not in df.columns:
        return pd.DataFrame(columns=["date","open","high","low","close","volume","average","barCount"])
    df["date"] = pd.to_datetime(df["date"], utc=True, errors="coerce")
    for c in ["open","high","low","close","volume","average","barCount"]:
        if c not in df.columns: df[c] = pd.NA
        df[c] = pd.to_numeric(df[c], errors="coerce")
    return df.dropna(subset=["date"])[["date","open","high","low","close","volume","average","barCount"]]

def append_only(path_csv: str, df_new: pd.DataFrame) -> int:
    df_new = df_new.copy()
    df_new["date"] = pd.to_datetime(df_new["date"], utc=True)
    if os.path.isfile(path_csv):
        old = pd.read_csv(path_csv)
        if "date" not in old.columns:
            raise SystemExit(f"[ERR] {path_csv} missing 'date'")
        old["date"] = pd.to_datetime(old["date"], utc=True, errors="coerce")
        last_dt = old["date"].max()
        df_new = df_new[df_new["date"] > last_dt] if pd.notna(last_dt) else df_new
        merged = pd.concat([old, df_new], ignore_index=True)
    else:
        merged = df_new
    merged = merged.drop_duplicates(subset=["date"]).sort_values("date")
    Path(path_csv).parent.mkdir(parents=True, exist_ok=True)
    merged.to_csv(path_csv, index=False)
    return len(df_new)

# ---------------- main ----------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=7496)
    ap.add_argument("--client_id", type=int, default=62)
    ap.add_argument("--duration", default="2 Y")
    ap.add_argument("--what", default="TRADES", choices=["TRADES","MIDPOINT"])
    ap.add_argument("--use_rth", type=int, default=1)
    # clone-friendly overrides
    ap.add_argument("--sheet", default=settings_default_sheet())
    ap.add_argument("--bucket", default=SETTINGS_BUCKET)
    # infra
    ap.add_argument("--excel", default=str(EXCEL_LIST))
    ap.add_argument("--ticker_col", default=EXCEL_TICKER_COL)
    ap.add_argument("--mapping", default=str(MAPPING_CSV))
    ap.add_argument("--sleep_ms", type=int, default=200)
    ap.add_argument("--limit", type=int, default=0)
    args = ap.parse_args()

    out_dir = Path(_P.DATA_RAW) / args.bucket / "weekly"
    out_dir.mkdir(parents=True, exist_ok=True)
    print(f"[INFO] Excel={args.excel} | sheet={args.sheet} | bucket={args.bucket} | outdir={out_dir}")

    tickers = load_tickers_from_excel(args.excel, args.sheet, args.ticker_col)
    if args.limit and args.limit > 0: tickers = tickers[: args.limit]
    mapping = load_mapping(args.mapping)

    ib = IB()
    print(f"[IB] Connecting {args.host}:{args.port} (clientId={args.client_id}) …")
    ib.connect(args.host, args.port, clientId=args.client_id, readonly=True)
    print("[IB] Connected.")

    for i, t in enumerate(tickers, 1):
        try:
            q = ib.qualifyContracts(make_contract(t, mapping))
            if not q:
                print(f"[{i}/{len(tickers)}] {t}: [SKIP] could not qualify.")
                continue
            df = fetch_weekly_df(ib, q[0], args.duration, args.what, bool(args.use_rth))
            if df.empty:
                print(f"[{i}/{len(tickers)}] {t}: [SKIP] no weekly data returned.")
                continue
            out_path = str(out_dir / f"{t}_weekly_raw.csv")
            added = append_only(out_path, df)
            print(f"[{i}/{len(tickers)}] {t}: +{added} rows → {out_path}")
            ib.sleep(max(args.sleep_ms,0)/1000.0)
        except Exception as e:
            print(f"[{i}/{len(tickers)}] {t}: [ERROR] {e}")

    ib.disconnect()
    print("[DONE] s12_ibkr_download_weekly complete.")

if __name__ == "__main__":
    main()