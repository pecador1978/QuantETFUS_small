#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
s07_build_weekly_from_daily.py
Build weekly OHLCV from existing DAILY raw files (no IB calls).

Reads:
  P.DATA_RAW/<TARGET_BUCKET>/daily/{TICKER}_daily_raw.csv  (IBKR schema: date, open, high, low, close, volume, ...)

Writes:
  P.DATA_RAW/<TARGET_BUCKET>/weekly/{TICKER}_weekly_raw.csv
  (columns: date, open, high, low, close, volume)
"""

from pathlib import Path
import sys
import pandas as pd

# --- import centralized paths/settings ---
SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
from common.paths import P  # noqa: E402
try:
    from common.settings import TARGET_BUCKET  # noqa: E402
except Exception:
    TARGET_BUCKET = "targeted_ETFs"

DAILY_DIR  = P.DATA_RAW / TARGET_BUCKET / "daily"
WEEKLY_DIR = P.DATA_RAW / TARGET_BUCKET / "weekly"
WEEKLY_DIR.mkdir(parents=True, exist_ok=True)

def build_weekly_from_daily(daily_csv: Path, weekly_csv: Path) -> int:
    df = pd.read_csv(daily_csv)
    if "date" not in df.columns:
        # allow alternate header 'datetime'
        if "datetime" in df.columns:
            df = df.rename(columns={"datetime": "date"})
        else:
            print(f"[WARN] {daily_csv.name}: no 'date' column, skipping.")
            return 0

    # parse UTC; order; keep numeric
    df["date"] = pd.to_datetime(df["date"], utc=True, errors="coerce")
    df = df.dropna(subset=["date"]).sort_values("date").set_index("date")

    for c in ["open","high","low","close","volume"]:
        if c not in df.columns:
            df[c] = pd.NA
        df[c] = pd.to_numeric(df[c], errors="coerce")

    # weekly aggregation (Friday close)
    wk = pd.DataFrame({
        "open":   df["open"].resample("W-FRI").first(),
        "high":   df["high"].resample("W-FRI").max(),
        "low":    df["low"].resample("W-FRI").min(),
        "close":  df["close"].resample("W-FRI").last(),
        "volume": df["volume"].resample("W-FRI").sum(),
    })

    wk = wk.dropna(subset=["open","high","low","close"])  # drop incomplete weeks
    wk = wk.reset_index().rename(columns={"date": "date"})
    wk.to_csv(weekly_csv, index=False)
    return len(wk)

def main():
    files = sorted(DAILY_DIR.glob("*_daily_raw.csv"))
    if not files:
        raise SystemExit(f"[ERR] No daily files in {DAILY_DIR} — run s05 first.")

    total = 0
    for i, f in enumerate(files, 1):
        tkr = f.name.replace("_daily_raw.csv", "")
        out = WEEKLY_DIR / f"{tkr}_weekly_raw.csv"
        try:
            n = build_weekly_from_daily(f, out)
            total += n
            print(f"[{i}/{len(files)}] {tkr}: wrote {n} rows → {out}")
        except Exception as e:
            print(f"[WARN] {tkr}: {e}")

    print(f"[OK] Weekly build complete. Tickers={len(files)} | Total rows written≈{total}")

if __name__ == "__main__":
    main()