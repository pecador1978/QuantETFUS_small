#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
s10_ibkr_download_daily.py — Append-only DAILY updater (IBKR via ib_insync, UTC-only)

- Reads tickers from shared ETF_list.xlsx
  * default sheet from common.settings.default_etf_sheet() if available
  * otherwise falls back to env ETF_SHEET or 'signals'
- Appends ONLY missing daily bars into:
    <project>/data_raw/<TARGET_BUCKET>/daily/{TICKER}_daily_raw.csv
- TARGET_BUCKET from common.settings if available; otherwise env TARGET_BUCKET or 'targeted_ETFs_US'
- Optional ticker mapping:
    <project>/config/ticker_mapping.csv  (semicolon-separated)
"""

from pathlib import Path
import os
import sys
import argparse
import pandas as pd
from ib_insync import IB, Contract, util

# ---------------- bootstrapping: make 'common' importable ----------------
SCRIPT_DIR   = Path(__file__).resolve().parent          # .../QuantETF*/scripts
PROJECT_ROOT = SCRIPT_DIR.parent                        # .../QuantETF*
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

# ---------------- shared paths & settings ----------------
from common.paths import P  # project/shared-aware paths (QuantShared)

# Try to get TARGET_BUCKET + default_etf_sheet from repo settings; provide safe fallbacks.
try:
    from common.settings import TARGET_BUCKET as _TB, default_etf_sheet as _dfs
    TARGET_BUCKET = _TB
    default_etf_sheet_fn = _dfs
except Exception:
    # Fallbacks: allow env override
    TARGET_BUCKET = os.getenv("TARGET_BUCKET", "targeted_ETFs_US")
    def default_etf_sheet_fn() -> str:
        return os.getenv("ETF_SHEET", "signals")

# Currency default (only used if mapping file omits currency)
DEFAULT_CCY = "USD" if PROJECT_ROOT.name.endswith("US") else "EUR"

# ---------------- folders/files ----------------
RAW_BUCKET = P.DATA_RAW / TARGET_BUCKET
DIR_DAILY  = RAW_BUCKET / "daily"
DIR_30M    = RAW_BUCKET / "30min"
DIR_WEEKLY = RAW_BUCKET / "weekly"
for d in (DIR_DAILY, DIR_30M, DIR_WEEKLY):
    d.mkdir(parents=True, exist_ok=True)

EXCEL_LIST       = str(P.ETF_LIST)               # shared ETF_list.xlsx
EXCEL_SHEET      = default_etf_sheet_fn()        # may come from settings or fallback/env
EXCEL_TICKER_COL = "Ticker"
MAPPING_CSV      = str(P.CONFIG_DIR / "ticker_mapping.csv")
OUT_DIR          = str(DIR_DAILY)                # final output dir

print(f"[INFO] Excel={EXCEL_LIST} | sheet={EXCEL_SHEET} | bucket={TARGET_BUCKET}")

# ---------------- helpers ----------------
def load_tickers_from_excel(path_xlsx: str, sheet: str, col_name: str) -> list[str]:
    df = pd.read_excel(path_xlsx, sheet_name=sheet)
    colmap = {c.lower(): c for c in df.columns}
    key = col_name.lower()
    if key not in colmap:
        raise ValueError(f"Column '{col_name}' not found in {path_xlsx} (sheet '{sheet}').")
    tickers = df[colmap[key]].astype(str).str.strip().str.upper()
    return [t for t in tickers.unique().tolist() if t]

def load_mapping(path_csv: str) -> dict:
    """Optional mapping for IBKR contracts; CSV is semicolon-separated."""
    if not os.path.isfile(path_csv):
        return {}
    df = pd.read_csv(path_csv, sep=";")
    need = {"Ticker", "SecType", "Exchange", "Currency", "PrimaryExchange"}
    if not need.issubset(df.columns):
        raise ValueError(f"{path_csv} must contain columns: {need}")
    mp = {}
    for _, r in df.iterrows():
        t = str(r["Ticker"]).strip().upper()
        mp[t] = {
            "SecType":          (str(r.get("SecType", "STK")).strip() or "STK").upper(),
            "Exchange":         str(r.get("Exchange", "SMART")).strip() or "SMART",
            "Currency":         (str(r.get("Currency", DEFAULT_CCY)).strip() or DEFAULT_CCY).upper(),
            "PrimaryExchange":  str(r.get("PrimaryExchange", "")).strip() or ""
        }
    return mp

def make_contract(ticker: str, mapping: dict) -> Contract:
    m = mapping.get(ticker.upper(), {})
    c = Contract()
    c.symbol          = ticker
    c.secType         = m.get("SecType", "STK")
    c.exchange        = m.get("Exchange", "SMART")
    c.currency        = m.get("Currency", DEFAULT_CCY)
    pe = m.get("PrimaryExchange", "")
    if pe:
        c.primaryExchange = pe
    return c

def fetch_daily_df(ib: IB, contract: Contract, duration: str, what: str, use_rth: bool) -> pd.DataFrame:
    bars = ib.reqHistoricalData(
        contract,
        endDateTime="",               # now
        durationStr=duration,
        barSizeSetting="1 day",
        whatToShow=what,
        useRTH=use_rth,
        formatDate=1,
        keepUpToDate=False,
    )
    if not bars:
        return pd.DataFrame(columns=["date","open","high","low","close","volume","average","barCount"])
    df = util.df(bars)
    if "date" not in df.columns:
        return pd.DataFrame(columns=["date","open","high","low","close","volume","average","barCount"])
    df["date"] = pd.to_datetime(df["date"], utc=True, errors="coerce")
    for c in ["open","high","low","close","volume","average","barCount"]:
        if c not in df.columns:
            df[c] = pd.NA
        df[c] = pd.to_numeric(df[c], errors="coerce")
    return df[["date","open","high","low","close","volume","average","barCount"]]

def append_only(path_csv: str, df_new: pd.DataFrame) -> int:
    """Append only newer rows (by 'date' col), keep UTC."""
    df_new = df_new.copy()
    df_new["date"] = pd.to_datetime(df_new["date"], utc=True)
    if os.path.isfile(path_csv):
        old = pd.read_csv(path_csv)
        if "date" not in old.columns:
            raise ValueError(f"{path_csv} missing 'date' column")
        old["date"] = pd.to_datetime(old["date"], utc=True, errors="coerce")
        last_dt = old["date"].max()
        df_new = df_new[df_new["date"] > last_dt] if pd.notna(last_dt) else df_new
        merged = pd.concat([old, df_new], ignore_index=True)
    else:
        merged = df_new
    merged = merged.drop_duplicates(subset=["date"]).sort_values("date")
    os.makedirs(os.path.dirname(path_csv), exist_ok=True)
    merged.to_csv(path_csv, index=False)
    return len(df_new)

# ---------------- main ----------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=7496)
    ap.add_argument("--client_id", type=int, default=60)
    ap.add_argument("--duration", default="10 Y", help="IB durationStr (e.g., '10 Y')")
    ap.add_argument("--what", default="TRADES", help="TRADES / MIDPOINT")
    ap.add_argument("--use_rth", type=int, default=1, help="1 = RTH only, 0 = all hours")
    ap.add_argument("--excel", default=str(EXCEL_LIST))
    ap.add_argument("--sheet", default=str(EXCEL_SHEET))
    ap.add_argument("--ticker_col", default=str(EXCEL_TICKER_COL))
    ap.add_argument("--mapping", default=str(MAPPING_CSV))
    ap.add_argument("--outdir", default=str(OUT_DIR))
    ap.add_argument("--sleep_ms", type=int, default=200)
    ap.add_argument("--limit", type=int, default=0)
    args = ap.parse_args()

    tickers = load_tickers_from_excel(args.excel, args.sheet, args.ticker_col)
    if args.limit and args.limit > 0:
        tickers = tickers[: args.limit]
    mapping = load_mapping(args.mapping)

    ib = IB()
    print(f"[IB] Connecting {args.host}:{args.port} (clientId={args.client_id}) …")
    ib.connect(args.host, args.port, clientId=args.client_id, readonly=True)
    print("[IB] Connected.")

    for i, t in enumerate(tickers, 1):
        try:
            c = make_contract(t, mapping)
            qualified = ib.qualifyContracts(c)
            if not qualified:
                print(f"[WARN] {t}: could not qualify contract (check mapping/permissions). Skipping.")
                continue

            df = fetch_daily_df(ib, qualified[0], args.duration, args.what, bool(args.use_rth))
            if df.empty:
                print(f"[WARN] {t}: no data returned. Skipping.")
                continue

            out_path = os.path.join(args.outdir, f"{t}_daily_raw.csv")
            added = append_only(out_path, df)
            print(f"[{i}/{len(tickers)}] {t}: +{added} rows → {out_path}")
            ib.sleep(args.sleep_ms / 1000.0)
        except Exception as e:
            print(f"[ERROR] {t}: {e}")

    ib.disconnect()
    print("[DONE] s10_ibkr_download_daily (append-only, UTC) complete.")

if __name__ == "__main__":
    main()