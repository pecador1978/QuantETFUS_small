#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
s08_build_ticker_mapping.py
Discover correct IBKR contract lines for LSE-traded ETFs/ETPs (prefer USD lines)
and write config/ticker_mapping.csv (semicolon-separated).

Discovery strategy:
- reqMatchingSymbols(ticker) to enumerate candidates
- for each candidate, fetch ContractDetails by conId
- score candidates preferring: currency USD, and primaryExchange in
  [LSEETF, LSEETP, LSE, LSEIOB]
- save as: SecType=STK, Exchange=SMART, Currency=USD/GBP, PrimaryExchange=<chosen LSE segment>

Optional manual overrides: config/ticker_overrides.csv with columns:
  Ticker;SecType;Exchange;Currency;PrimaryExchange
Rows found here are used as-is and discovery is skipped for that ticker.
"""

from pathlib import Path
import sys, os, argparse
import pandas as pd
from ib_insync import IB, Contract, ContractDetails

# ----- project paths -----
SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
from common.paths import P, default_etf_sheet  # noqa

OUT_CSV = P.CONFIG_DIR / "ticker_mapping.csv"
OVERRIDE_CSV = P.CONFIG_DIR / "ticker_overrides.csv"

PREFER_PE = ["LSEETF", "LSEETP", "LSE", "LSEIOB"]  # ETF > ETP > main > IOB
USD_FIRST = True

def load_tickers(xlsx: Path, sheet: str, col="Ticker") -> list[str]:
    df = pd.read_excel(xlsx, sheet_name=sheet)
    c = {x.lower(): x for x in df.columns}
    if col.lower() not in c:
        raise SystemExit(f"[ERR] Column '{col}' not found in {xlsx}:{sheet}")
    return (
        df[c[col.lower()]].astype(str).str.strip().str.upper()
          .replace({"": None}).dropna().unique().tolist()
    )

def load_overrides(path: Path) -> dict:
    if not path.exists():
        return {}
    df = pd.read_csv(path, sep=";")
    need = {"Ticker","SecType","Exchange","Currency","PrimaryExchange"}
    if not need.issubset(df.columns):
        raise SystemExit(f"[ERR] {path} must contain columns: {need}")
    out = {}
    for _, r in df.iterrows():
        t = str(r["Ticker"]).strip().upper()
        out[t] = {
            "SecType": (str(r.get("SecType","STK")) or "STK").upper(),
            "Exchange": str(r.get("Exchange","SMART")) or "SMART",
            "Currency": (str(r.get("Currency","USD")) or "USD").upper(),
            "PrimaryExchange": (str(r.get("PrimaryExchange","")) or "").upper(),
        }
    return out

def _score(cd: ContractDetails):
    """Lower is better."""
    c = cd.contract
    pe = (c.primaryExchange or "").upper()
    ex = (c.exchange or "").upper()
    cur= (c.currency or "").upper()

    try:
        pe_rank = PREFER_PE.index(pe)
    except ValueError:
        # sometimes exchange list is in `cd.validExchanges`
        pe_rank = len(PREFER_PE) + 1

    usd_penalty = 0 if cur == "USD" else 1
    # prefer SMART or LSE-like routing
    smart_bonus = 0 if ex in ("SMART","LSE","LSEETF","LSEETP") else 1
    return (usd_penalty if USD_FIRST else 0, pe_rank, smart_bonus)

def discover_one(ib: IB, ticker: str) -> dict | None:
    """Return mapping dict or None."""
    try:
        hits = ib.reqMatchingSymbols(ticker)
    except Exception as e:
        print(f"[WARN] {ticker}: matchingSymbols failed: {e}")
        return None
    if not hits:
        return None

    # collect detailed contracts for candidates with LSE-ish exchanges
    details: list[ContractDetails] = []
    for h in hits:
        c = h.contract
        ve = (h.derivativeSecTypes or [])  # not very useful here
        valid = (h.validExchanges or "") if hasattr(h, "validExchanges") else ""
        exch_list = (valid or "").upper().split(",")
        if not exch_list:
            exch_list = []
        # Keep if it mentions LSE in any form
        if not any(x.startswith("LSE") for x in exch_list):
            continue
        try:
            for d in ib.reqContractDetails(Contract(conId=c.conId)):
                if d.contract.secType == "STK":  # ETFs are STK in IB
                    details.append(d)
        except Exception:
            continue

    if not details:
        # one last attempt: ask by explicit exchanges
        for ex in ("LSEETF","LSEETP","LSE","LSEIOB"):
            try:
                for d in ib.reqContractDetails(Contract(symbol=ticker, secType="STK",
                                                        exchange=ex, currency="USD")):
                    details.append(d)
            except Exception:
                pass
            try:
                for d in ib.reqContractDetails(Contract(symbol=ticker, secType="STK",
                                                        exchange=ex, currency="GBP")):
                    details.append(d)
            except Exception:
                pass

    if not details:
        return None

    # pick best
    best = sorted(details, key=_score)[0]
    c = best.contract
    pe = (c.primaryExchange or "").upper()
    cur = (c.currency or "").upper() or "USD"
    return {
        "SecType": "STK",
        "Exchange": "SMART",          # route via SMART
        "Currency": cur,
        "PrimaryExchange": pe or "LSEETF"
    }

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--excel", default=str(P.ETF_LIST))
    ap.add_argument("--sheet", default=default_etf_sheet())
    ap.add_argument("--ticker_col", default="Ticker")
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=7496)
    ap.add_argument("--client_id", type=int, default=59)
    ap.add_argument("--limit", type=int, default=0)
    args = ap.parse_args()

    tickers = load_tickers(Path(args.excel), args.sheet, args.ticker_col)
    if args.limit > 0:
        tickers = tickers[: args.limit]
    overrides = load_overrides(OVERRIDE_CSV)

    ib = IB()
    print(f"[IB] Connecting {args.host}:{args.port} (clientId={args.client_id}) …")
    ib.connect(args.host, args.port, clientId=args.client_id, readonly=True)
    print("[IB] Connected.")

    rows = []
    for i, t in enumerate(tickers, 1):
        if t in overrides:
            m = overrides[t]
            rows.append({"Ticker": t, **m})
            print(f"[{i}/{len(tickers)}] {t} (override) → {m['Exchange']}/{m['Currency']} primary={m['PrimaryExchange']}")
            continue

        m = discover_one(ib, t)
        if not m:
            print(f"[WARN] {t}: no suitable LSE line found; add to overrides and re-run.")
            continue
        rows.append({"Ticker": t, **m})
        print(f"[{i}/{len(tickers)}] {t} → {m['Exchange']}/{m['Currency']} (primary={m['PrimaryExchange']})")
        ib.sleep(0.10)

    ib.disconnect()

    if not rows:
        raise SystemExit("[ERR] No rows to write.")

    df = pd.DataFrame(rows, columns=["Ticker","SecType","Exchange","Currency","PrimaryExchange"])
    OUT_CSV.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(OUT_CSV, index=False, sep=";")
    print(f"[OK] Wrote mapping → {OUT_CSV} (rows={len(df)})")
    if overrides:
        print(f"[INFO] Used overrides for {len(overrides)} tickers → {OVERRIDE_CSV}")

if __name__ == "__main__":
    main()