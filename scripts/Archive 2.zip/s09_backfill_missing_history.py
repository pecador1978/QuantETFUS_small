#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
s09_backfill_missing_history.py
Rename existing historical ETF files to the new "*_raw.csv" convention.

Changes per subfolder under data_raw/targeted_ETFs:
  daily : *_daily.csv   -> *_daily_raw.csv
  30min : *_30min.csv   -> *_30min_raw.csv
  weekly: *_weekly.csv  -> *_weekly_raw.csv

Usage examples:
  ./scripts/s09_rename_raw_files.py                 # do all (daily,30min,weekly)
  ./scripts/s09_rename_raw_files.py --dry_run       # preview only
  ./scripts/s09_rename_raw_files.py --only daily    # only daily
"""

from pathlib import Path
import sys
import argparse

# --- import centralized paths ---
SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from common.paths import P  # noqa: E402

BASE_DIR = P.DATA_RAW / "targeted_ETFs"

SUFFIX_MAP = {
    "daily":  ("_daily.csv",  "_daily_raw.csv"),
    "30min":  ("_30min.csv",  "_30min_raw.csv"),
    "weekly": ("_weekly.csv", "_weekly_raw.csv"),
}

def rename_files(folder_name: str, old_suffix: str, new_suffix: str, dry_run: bool = False) -> int:
    folder = BASE_DIR / folder_name
    if not folder.exists():
        print(f"[WARN] Missing folder: {folder}")
        return 0
    count = 0
    for p in sorted(folder.glob(f"*{old_suffix}")):
        new_path = p.with_name(p.name.replace(old_suffix, new_suffix))
        if new_path == p:
            continue
        if dry_run:
            print(f"DRY-RUN: {p.name}  ->  {new_path.name}")
        else:
            p.rename(new_path)
            print(f"RENAMED: {p.name}  ->  {new_path.name}")
            count += 1
    print(f"[INFO] {'Would rename' if dry_run else 'Renamed'} {count} file(s) in '{folder_name}'.")
    return count

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry_run", action="store_true", help="Preview changes without renaming.")
    ap.add_argument("--only", choices=list(SUFFIX_MAP.keys()), nargs="*", default=None,
                    help="Restrict to one or more buckets: daily 30min weekly")
    args = ap.parse_args()

    targets = args.only or list(SUFFIX_MAP.keys())
    print(f"[INFO] Base dir: {BASE_DIR}")
    total = 0
    for bucket in targets:
        old_sfx, new_sfx = SUFFIX_MAP[bucket]
        total += rename_files(bucket, old_sfx, new_sfx, dry_run=args.dry_run)
    if args.dry_run:
        print(f"[INFO] DRY-RUN complete. Total files that would be renamed: {total}")
    else:
        print(f"[OK] Done. Total files renamed: {total}")

if __name__ == "__main__":
    main()