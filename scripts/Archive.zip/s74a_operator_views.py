#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
s74a_operator_views.py
Make quick operator cuts from the latest final_signals:
- ML picks: ml_usable==True & y_prob_display >= 0.60
- Also exports a per-ticker count summary.

Inputs
------
<ROOT>/param_results/final_signals_<ts>.csv  (latest)

Outputs
-------
- <ROOT>/param_results/operator_ml_picks_<ts>.csv
- <ROOT>/param_results/operator_counts_by_ticker_<ts>.csv
"""

from __future__ import annotations
from pathlib import Path
from datetime import datetime, timezone
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
PR   = ROOT / "param_results"

def _ts() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%d_%H%M")

def _latest_final() -> Path:
    cands = sorted(PR.glob("final_signals_*.csv"))
    if not cands:
        raise SystemExit("[ERR] No final_signals_*.csv found. Run s74 first.")
    return cands[-1]

def main():
    final_fp = _latest_final()
    df = pd.read_csv(final_fp)
    ts = _ts()
    print(f"[INFO] Using final table: {final_fp}")

    # ML picks
    if "y_prob_display" not in df.columns or "ml_usable" not in df.columns:
        raise SystemExit("[ERR] Missing y_prob_display/ml_usable columns in final table.")

    picks = df[(df["ml_usable"] == True) & (df["y_prob_display"] >= 0.60)].copy()
    # light sort if we have time fields
    sort_cols = [c for c in ["date","entry_dt","ticker","y_prob_display"] if c in picks.columns]
    if sort_cols:
        picks = picks.sort_values(sort_cols)

    out1 = PR / f"operator_ml_picks_{ts}.csv"
    picks.to_csv(out1, index=False)
    print(f"[OK] ML picks (>=0.60) → {out1}  (rows={len(picks)})")

    # Per-ticker counts (all rows)
    cnt = df.groupby("ticker", dropna=False).size().reset_index(name="rows")
    out2 = PR / f"operator_counts_by_ticker_{ts}.csv"
    cnt.to_csv(out2, index=False)
    print(f"[OK] Counts by ticker → {out2}")

if __name__ == "__main__":
    main()