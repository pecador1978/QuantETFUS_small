#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
s64_select_and_export.py
Pick champion combo per ticker from s63 outputs and export:
  - /config/s60_final_combos.json  (ticker -> params dict)
  - /param_results/s64_final_strategies_{TS}.csv  (table with profit in EUR)

Uses common.paths.P so it works in both QuantETF and QuantETFUS.
"""

from pathlib import Path
from datetime import datetime, timezone
import json
import pandas as pd
import numpy as np
import os
import sys

# ---- import shared paths (project‑aware)
SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parent  # .../scripts -> project root
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
from common.paths import P  # provides ROOT, PARAM_RESULTS, CONFIG_DIR, etc.

PARAM_RESULTS = P.PARAM_RESULTS
CONFIG_DIR    = P.CONFIG_DIR
CONFIG_DIR.mkdir(parents=True, exist_ok=True)

UNIT_CAPITAL = 10_000.0   # must match s62/s60 assumption

def _latest(path: Path, prefix: str) -> Path:
    cands = sorted(path.glob(f"{prefix}*.csv"))
    if not cands:
        raise SystemExit(f"[ERR] Could not find {prefix}*.csv in {path}")
    return cands[-1]

def main():
    # 1) pick latest s63 best-per-ticker + load it
    best = _latest(PARAM_RESULTS, "s63_best_per_ticker_")
    print(f"[INFO] Using best-per-ticker file: {best.name}")
    df = pd.read_csv(best)

    # 2) detect parameter columns (everything that’s not metric-ish)
    metric_like = {
        "ticker","count_runs","observations","mean_return","median_return",
        "best_return","worst_return","std_return","mean_win_rate","mean_num_trades","run_ids"
    }
    param_cols = [c for c in df.columns if c not in metric_like]
    param_cols = [c for c in param_cols if not c.endswith("_return") and c not in ("rank",)]

    # 3) build combos json (ticker -> params)
    combos = {}
    for _, r in df.iterrows():
        tkr = str(r["ticker"])
        p = {k: (None if (pd.isna(r[k])) else r[k]) for k in param_cols}
        # Make ints neat where possible
        for k, v in list(p.items()):
            if isinstance(v, float) and v.is_integer():
                p[k] = int(v)
        combos[tkr] = p

    # 4) compute profit in EUR for info table (mean_return is a fraction)
    df_out = df[["ticker","count_runs","mean_return","median_return","best_return","worst_return",
                 "std_return","mean_win_rate","mean_num_trades","run_ids"] + param_cols].copy()
    df_out["unit_capital"] = UNIT_CAPITAL
    df_out["profit_eur_at_unit_capital"] = (df_out["mean_return"].astype(float)) * UNIT_CAPITAL

    # 5) save
    ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M")
    final_csv = PARAM_RESULTS / f"s64_final_strategies_{ts}.csv"
    df_out.sort_values(["mean_return","count_runs","mean_num_trades","mean_win_rate"],
                       ascending=[False, False, False, False]).to_csv(final_csv, index=False)

    final_json = CONFIG_DIR / "s60_final_combos.json"
    with open(final_json, "w") as f:
        json.dump(combos, f, indent=2)

    print(f"[OK] Final strategies CSV → {final_csv}")
    print(f"[OK] Per-ticker combos    → {final_json}")
    print("[HINT] Open the CSV to scan profits and sanity-check params. JSON feeds the next step.")

if __name__ == "__main__":
    main()