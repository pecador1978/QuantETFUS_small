#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
s70b_per_ticker_thresholds.py
Diagnose per-ticker performance and choose per-ticker thresholds on VAL (opt F1),
then apply those thresholds to TEST and report uplift vs the default 0.50.

Inputs (auto-discovered):
  <ROOT>/models/classifier_val_predictions_*.csv
  <ROOT>/models/classifier_test_predictions_*.csv
  (columns expected: ticker, y_true, y_prob; y_pred optional)

Outputs:
  <ROOT>/param_results/s70b_per_ticker_thresholds_<ts>.csv   # per-ticker metrics and chosen thresholds
  <ROOT>/param_results/s70b_overall_summary_<ts>.csv         # overall metrics (macro/micro) before/after

Notes:
- Threshold selection is done **per ticker on VAL** to maximize F1.
- The chosen per-ticker threshold is then applied to TEST to assess generalization.
"""

from __future__ import annotations
from pathlib import Path
from datetime import datetime, timezone
import sys
import re
import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score

# ---------- project-aware paths ----------
SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
from common.paths import P

MODELS_DIR = P.ROOT / "models"
OUT_DIR    = P.ROOT / "param_results"

def _ts() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%d_%H%M")

def _latest(split: str) -> Path:
    # split in {"val","test"}
    pattern = f"classifier_{split}_predictions_*.csv"
    cands = sorted(MODELS_DIR.glob(pattern))
    if not cands:
        raise SystemExit(f"[ERR] No files matching {pattern} in {MODELS_DIR}")
    return cands[-1]

def _load_preds(p: Path) -> pd.DataFrame:
    df = pd.read_csv(p)
    if "y_prob" not in df.columns or "y_true" not in df.columns:
        raise SystemExit(f"[ERR] {p} must contain y_true and y_prob columns.")
    if "ticker" not in df.columns:
        raise SystemExit(f"[ERR] {p} must contain ticker column.")
    out = df[["ticker","y_true","y_prob"]].copy()
    out["y_true"] = out["y_true"].astype(int)
    out["y_prob"] = out["y_prob"].astype(float)
    return out

def _metrics_at(y_true, y_prob, thr: float) -> dict:
    y_pred = (y_prob >= thr).astype(int)
    out = {
        "n": int(len(y_true)),
        "accuracy": accuracy_score(y_true, y_pred),
        "precision": precision_score(y_true, y_pred, zero_division=0),
        "recall": recall_score(y_true, y_pred, zero_division=0),
        "f1": f1_score(y_true, y_pred, zero_division=0),
    }
    try:
        out["roc_auc"] = roc_auc_score(y_true, y_prob)
    except Exception:
        out["roc_auc"] = np.nan
    return out

def _best_threshold_on_val(y_true, y_prob) -> float:
    # Search candidate thresholds on VAL probabilities at observed quantiles.
    # Constrain min positive predictions (>= 5) to avoid degenerate thresholds.
    probs = np.asarray(y_prob)
    cand = np.unique(np.quantile(probs, np.linspace(0.05, 0.95, 91)))
    best_thr, best_f1 = 0.50, -1.0
    for t in cand:
        pred = (probs >= t).astype(int)
        if pred.sum() < 5:  # avoid ultra-high thresholds with 0-1 positives
            continue
        f1 = f1_score(y_true, pred, zero_division=0)
        if f1 > best_f1:
            best_f1, best_thr = f1, float(t)
    return best_thr

def main():
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    val_path  = _latest("val")
    test_path = _latest("test")

    val  = _load_preds(val_path)
    test = _load_preds(test_path)

    # ---- per-ticker thresholds from VAL ----
    rows = []
    tickers = sorted(val["ticker"].unique())
    for tkr in tickers:
        v = val[val["ticker"] == tkr]
        if len(v) < 20:
            continue  # too thin for tuning
        thr_star = _best_threshold_on_val(v["y_true"].values, v["y_prob"].values)

        # metrics at default 0.50 on VAL/TEST
        m_val_def  = _metrics_at(v["y_true"].values, v["y_prob"].values, 0.50)
        w = test[test["ticker"] == tkr]
        if len(w) == 0:
            continue
        m_test_def = _metrics_at(w["y_true"].values, w["y_prob"].values, 0.50)

        # metrics at tuned threshold
        m_val_tun  = _metrics_at(v["y_true"].values, v["y_prob"].values, thr_star)
        m_test_tun = _metrics_at(w["y_true"].values, w["y_prob"].values, thr_star)

        rows.append({
            "ticker": tkr,
            "n_val": len(v),
            "n_test": len(w),
            "thr_star": round(thr_star, 4),

            "val_acc_0.50":  m_val_def["accuracy"],
            "val_f1_0.50":   m_val_def["f1"],
            "val_auc":       m_val_def["roc_auc"],

            "val_acc_star":  m_val_tun["accuracy"],
            "val_f1_star":   m_val_tun["f1"],

            "test_acc_0.50": m_test_def["accuracy"],
            "test_f1_0.50":  m_test_def["f1"],
            "test_auc":      m_test_def["roc_auc"],

            "test_acc_star": m_test_tun["accuracy"],
            "test_f1_star":  m_test_tun["f1"],
        })

    per_ticker = pd.DataFrame(rows).sort_values("test_auc", ascending=False)
    ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M")
    per_ticker_path = OUT_DIR / f"s70b_per_ticker_thresholds_{ts}.csv"
    per_ticker.to_csv(per_ticker_path, index=False)

    # ---- overall (micro-average) before/after ----
    # Build unified preds for TEST with 0.50 and per-ticker tuned thresholds
    merged = test.merge(per_ticker[["ticker","thr_star"]], on="ticker", how="left")
    merged["thr_applied"] = merged["thr_star"].fillna(0.50)
    y_true = merged["y_true"].values
    y_prob = merged["y_prob"].values

    m_def  = _metrics_at(y_true, y_prob, 0.50)
    m_tune = _metrics_at(y_true, y_prob, merged["thr_applied"].values)

    overall = pd.DataFrame([{
        "n_test": int(len(test)),
        "acc_0.50":  m_def["accuracy"],
        "f1_0.50":   m_def["f1"],
        "auc":       m_def["roc_auc"],
        "acc_star":  m_tune["accuracy"],
        "f1_star":   m_tune["f1"],
    }])
    overall_path = OUT_DIR / f"s70b_overall_summary_{ts}.csv"
    overall.to_csv(overall_path, index=False)

    # ---- console summary ----
    print("\n[Per-ticker thresholds (top 10 by test AUC)]")
    print(per_ticker.head(10).to_string(index=False))
    print(f"\n[Overall TEST]")
    print(f"  AUC:            {m_def['roc_auc']:.3f}")
    print(f"  Acc @0.50:      {m_def['accuracy']:.3f}   F1 @0.50: {m_def['f1']:.3f}")
    print(f"  Acc @tuned:     {m_tune['accuracy']:.3f}   F1 @tuned: {m_tune['f1']:.3f}")
    print(f"\n[OK] Wrote per-ticker → {per_ticker_path}")
    print(f"[OK] Wrote overall    → {overall_path}")

if __name__ == "__main__":
    main()