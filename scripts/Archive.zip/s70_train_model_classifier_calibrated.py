#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
s70_train_model_classifier_calibrated.py  (CONFIG-MANAGED)
Binary classifier for trade outcomes with calibrated probabilities + leakage/split audit
+ per-ticker Quality merge and live-friendly results export.

Now uses config/s70_config.json as the primary source of defaults.
CLI flags still work and OVERRIDE config values when provided.

Outputs:
- models/classifier_<ts>.pkl
- models/classifier_metrics_<ts>.json
- models/classifier_feature_names_<ts>.json
- models/classifier_feature_importances_base_<ts>.csv   (if available)
- models/classifier_{train,val,test}_predictions_<ts>.csv
- models/leakage_audit_<ts>.txt
- param_results/s70_results_with_guidance_<ts>.{csv,parquet}
"""

from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path
import sys
import numpy as np
import pandas as pd

# ---------- project-aware paths ----------
SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
from common.paths import P  # ROOT, CONFIG_DIR, etc.
CFG_DIR = getattr(P, "CONFIG_DIR", P.ROOT / "config")

# ---------- sklearn / models ----------
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.metrics import (
    accuracy_score, f1_score, precision_score, recall_score,
    roc_auc_score, confusion_matrix, brier_score_loss, log_loss
)
from sklearn.calibration import CalibratedClassifierCV
try:
    from sklearn.calibration import FrozenEstimator  # sklearn >= 1.6
    HAS_FROZEN = True
except Exception:
    HAS_FROZEN = False

from sklearn.ensemble import HistGradientBoostingClassifier
import joblib

# LightGBM (optional but default)
HAS_LGBM = False
try:
    from lightgbm import LGBMClassifier
    from lightgbm.callback import early_stopping, log_evaluation
    HAS_LGBM = True
except Exception:
    pass

# ----------------- utils -----------------
def _ts() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%d_%H%M")

def _default_paths():
    data_dir = P.ROOT / "data_final_training"
    return (data_dir / "train.csv", data_dir / "val.csv", data_dir / "test.csv")

def _load_csv(path: Path) -> pd.DataFrame:
    if not path.exists():
        raise SystemExit(f"[ERR] Missing split file: {path}")
    return pd.read_csv(path)

def _load_config() -> dict:
    cfg_path = CFG_DIR / "s70_config.json"
    if not cfg_path.exists():
        # Minimal defaults if config missing
        return {
            "model": "lgbm",
            "label_threshold": 0.0,
            "decision_threshold": 0.50,
            "min_abs_corr": 0.0,
            "drop_all_nan_cols": False,
            "cat_features": ["ticker"],
            "forbidden_features": [
                "ret_trade","pnl_eur","entry_px","exit_px",
                "entry_dt","exit_dt","trade_id","num_fills","legs"
            ],
            "paths": {"train": None, "val": None, "test": None},
            "encoder": {"ohe_min_frequency": 5},
            "live": {"whitelist_file": "param_results/s70_whitelist.csv"}
        }
    with open(cfg_path, "r") as f:
        return json.load(f)

def _coalesce_bool(cli_val, cfg_val, default):
    if cli_val is not None:
        return bool(cli_val)
    if cfg_val is not None:
        return bool(cfg_val)
    return bool(default)

def _coalesce(cli_val, cfg_val, default):
    return cli_val if cli_val is not None else (cfg_val if cfg_val is not None else default)

def _build_encoder(cat_cols: list[str], min_freq: int | None):
    kwargs = {"handle_unknown": "ignore"}
    try:
        if min_freq is not None:
            return OneHotEncoder(sparse_output=False, min_frequency=int(min_freq), **kwargs)
        return OneHotEncoder(sparse_output=False, **kwargs)
    except TypeError:  # older sklearn
        return OneHotEncoder(sparse=False, **kwargs)

def _select_features(train: pd.DataFrame, drop_always: set[str], cat_whitelist: list[str]):
    drop_cols = [c for c in drop_always if c in train.columns]
    num_cols = [c for c in train.select_dtypes(include=[np.number]).columns if c not in drop_cols]
    cat_cols = [c for c in cat_whitelist if c in train.columns and c not in drop_cols]
    feature_cols = num_cols + cat_cols
    return feature_cols, num_cols, cat_cols, drop_cols

def _maybe_filter_low_corr_numeric(X_num_train: pd.DataFrame, y_train: pd.Series, min_abs_corr: float) -> list[str]:
    if min_abs_corr <= 0.0 or X_num_train.empty:
        return list(X_num_train.columns)
    cors = X_num_train.apply(lambda col: np.corrcoef(col.fillna(col.mean()), y_train)[0, 1])
    cors = cors.replace([np.inf, -np.inf], np.nan).fillna(0.0)
    keep = cors.index[cors.abs() >= min_abs_corr].tolist()
    dropped = set(X_num_train.columns) - set(keep)
    if dropped:
        print(f"[s70] Numeric corr filter: dropped {len(dropped)} features with |corr|<{min_abs_corr}")
    return keep

def _build_target(df: pd.DataFrame, threshold: float) -> pd.Series:
    if "ret_trade" not in df.columns:
        raise SystemExit("[ERR] ret_trade not found for classification target.")
    return (pd.to_numeric(df["ret_trade"], errors="coerce") > float(threshold)).astype(int)

def _make_model(model_name: str):
    model_name = str(model_name).lower()
    if model_name == "lgbm":
        if not HAS_LGBM:
            raise SystemExit("[ERR] LightGBM not installed. Try: pip install lightgbm")
        return LGBMClassifier(
            n_estimators=2000,
            learning_rate=0.03,
            subsample=0.9,
            colsample_bytree=0.9,
            max_depth=-1,
            reg_lambda=1.0,
            random_state=42,
            n_jobs=-1,
            class_weight="balanced",
        )
    elif model_name == "hgb":
        return HistGradientBoostingClassifier(random_state=42)
    else:
        raise SystemExit(f"[ERR] Unsupported model '{model_name}'. Use 'lgbm' or 'hgb'.")

def _metrics_binary(y_true, y_prob, thresh=0.5):
    y_pred = (y_prob >= thresh).astype(int)
    out = {
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "precision": float(precision_score(y_true, y_pred, zero_division=0)),
        "recall": float(recall_score(y_true, y_pred, zero_division=0)),
        "f1": float(f1_score(y_true, y_pred, zero_division=0)),
    }
    try:
        out["roc_auc"] = float(roc_auc_score(y_true, y_prob))
    except Exception:
        out["roc_auc"] = float("nan")
    try:
        out["brier"] = float(brier_score_loss(y_true, y_prob))
    except Exception:
        out["brier"] = float("nan")
    try:
        out["log_loss"] = float(log_loss(y_true, np.clip(y_prob, 1e-6, 1-1e-6)))
    except Exception:
        out["log_loss"] = float("nan")
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()
    out["confusion_matrix"] = {"tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp)}
    return out

def _fit_with_early_stopping(model, Xtr, ytr, Xva, yva):
    if HAS_LGBM and isinstance(model, LGBMClassifier):
        callbacks = [early_stopping(stopping_rounds=100), log_evaluation(period=0)]
        model.fit(Xtr, ytr, eval_set=[(Xva, yva)], callbacks=callbacks)
    else:
        model.fit(Xtr, ytr)
    return model

def _safe_predict_proba(model, X):
    if hasattr(model, "predict_proba"):
        return model.predict_proba(X)[:, 1]
    if hasattr(model, "decision_function"):
        s = model.decision_function(X)
        return 1.0 / (1.0 + np.exp(-s))
    return model.predict(X).astype(float)

# ----------------- audit helpers -----------------
KEY_COLS = ["ticker", "entry_dt"]

def _audit_splits_and_leakage(models_dir: Path,
                              ts: str,
                              used_feature_columns: list[str],
                              train_df: pd.DataFrame,
                              val_df: pd.DataFrame,
                              test_df: pd.DataFrame,
                              forbidden_feature_names: set[str]) -> dict:
    def _dupe_summary(df: pd.DataFrame, name: str) -> str:
        if not all(c in df.columns for c in KEY_COLS):
            return f"[WARN] {name}: missing key columns {KEY_COLS}."
        dup = df.duplicated(KEY_COLS, keep=False)
        if not dup.any():
            return f"[DUPES] {name}: none."
        top = (df.loc[dup, KEY_COLS]
                 .value_counts()
                 .reset_index(name="n")
                 .head(5)
                 .to_string(index=False))
        return f"[DUPES] {name}: found {dup.sum()} duplicate keys ({KEY_COLS}). Top 5:\n{top}"

    def _overlap(a: pd.DataFrame, b: pd.DataFrame, an: str, bn: str) -> tuple[int, str]:
        if not all(c in a.columns for c in KEY_COLS) or not all(c in b.columns for c in KEY_COLS):
            return -1, f"[WARN] {an}∩{bn}: missing key columns {KEY_COLS}"
        left = a[KEY_COLS].drop_duplicates()
        right = b[KEY_COLS].drop_duplicates()
        n = left.merge(right, on=KEY_COLS, how="inner").shape[0]
        return n, f"[SANITY] Overlap by key: {an}∩{bn}={n}"

    forbidden_used = sorted(set(forbidden_feature_names) & set(used_feature_columns))
    forb_msg = "[OK] No forbidden/label-leakage features in feature matrix."
    if forbidden_used:
        forb_msg = f"[LEAK?] Forbidden-like columns in X: {forbidden_used}"

    msg_tr = _dupe_summary(train_df, "TRAIN")
    msg_va = _dupe_summary(val_df,   "VAL")
    msg_te = _dupe_summary(test_df,  "TEST")

    n_tv, msg_tv = _overlap(train_df, val_df,  "train", "val")
    n_tt, msg_tt = _overlap(train_df, test_df, "train", "test")
    n_vt, msg_vt = _overlap(val_df,   test_df, "val",   "test")

    audit_ok = (not forbidden_used) and (n_tv == 0) and (n_tt == 0) and (n_vt == 0)

    lines = [
        "[s70 audit]",
        forb_msg,
        msg_tr,
        msg_va,
        msg_te,
        msg_tv,
        msg_tt,
        msg_vt,
        f"[RESULT] audit_ok={audit_ok}"
    ]
    log_path = models_dir / f"leakage_audit_{ts}.txt"
    with open(log_path, "w") as f:
        f.write("\n".join(lines) + "\n")

    return {
        "forbidden_used": forbidden_used,
        "overlap_train_val": int(n_tv) if isinstance(n_tv, (int, np.integer)) else -1,
        "overlap_train_test": int(n_tt) if isinstance(n_tt, (int, np.integer)) else -1,
        "overlap_val_test": int(n_vt) if isinstance(n_vt, (int, np.integer)) else -1,
        "audit_ok": audit_ok,
        "log_file": str(log_path),
        "dup_train": int(train_df.duplicated(KEY_COLS, keep=False).sum()) if all(c in train_df.columns for c in KEY_COLS) else -1,
        "dup_val": int(val_df.duplicated(KEY_COLS, keep=False).sum()) if all(c in val_df.columns for c in KEY_COLS) else -1,
        "dup_test": int(test_df.duplicated(KEY_COLS, keep=False).sum()) if all(c in test_df.columns for c in KEY_COLS) else -1,
    }

# ----------------- main -----------------
def main():
    # ---- CLI (overrides config if provided) ----
    ap = argparse.ArgumentParser()
    ap.add_argument("--train", type=str, default=None, help="Path to train.csv (default: from config or data_final_training)")
    ap.add_argument("--val",   type=str, default=None, help="Path to val.csv   (default: from config or data_final_training)")
    ap.add_argument("--test",  type=str, default=None, help="Path to test.csv  (default: from config or data_final_training)")
    ap.add_argument("--model", type=str, default=None, choices=["lgbm", "hgb"])
    ap.add_argument("--threshold", type=float, default=None,
                    help="Label threshold for y = 1{ret_trade > threshold}. Overrides config.")
    ap.add_argument("--min_abs_corr", type=float, default=None,
                    help="Optional numeric filter: keep cols with |corr| >= value (computed on TRAIN). Overrides config.")
    ap.add_argument("--drop_all_nan_cols", action="store_true",
                    help="(Flag) Drop columns entirely NaN before processing (overrides config True).")
    ap.add_argument("--no_drop_all_nan_cols", action="store_true",
                    help="(Flag) Force NOT dropping all-NaN columns (overrides config False).")
    ap.add_argument("--decision_threshold", type=float, default=None,
                    help="Decision threshold for y_pred used in metrics & saved predictions. Overrides config.")
    args = ap.parse_args()

    # ---- Load config & coalesce values ----
    CFG = _load_config()

    model_name        = _coalesce(args.model, CFG.get("model"), "lgbm")
    label_threshold   = _coalesce(args.threshold, CFG.get("label_threshold"), 0.0)
    min_abs_corr      = _coalesce(args.min_abs_corr, CFG.get("min_abs_corr"), 0.0)
    decision_threshold= _coalesce(args.decision_threshold, CFG.get("decision_threshold"), 0.50)

    # tri-state bool from flags + config
    drop_all_nan_cols = _coalesce_bool(
        False if args.no_drop_all_nan_cols else (True if args.drop_all_nan_cols else None),
        CFG.get("drop_all_nan_cols"),
        False
    )

    cat_features      = list(CFG.get("cat_features", ["ticker"]))
    forbidden_features= set(CFG.get("forbidden_features", []))
    ohe_min_freq      = None
    if isinstance(CFG.get("encoder"), dict):
        ohe_min_freq = CFG["encoder"].get("ohe_min_frequency", None)

    cfg_paths = CFG.get("paths", {}) if isinstance(CFG.get("paths"), dict) else {}
    dft_train, dft_val, dft_test = _default_paths()
    train_path = Path(_coalesce(args.train, cfg_paths.get("train"), str(dft_train)))
    val_path   = Path(_coalesce(args.val,   cfg_paths.get("val"),   str(dft_val)))
    test_path  = Path(_coalesce(args.test,  cfg_paths.get("test"),  str(dft_test)))

    print("[s70] Loading splits…")
    train = _load_csv(train_path)
    val   = _load_csv(val_path)
    test  = _load_csv(test_path)

    if drop_all_nan_cols:
        train = train.loc[:, ~train.isna().all(axis=0)]
        val   = val.loc[:, ~val.isna().all(axis=0)]
        test  = test.loc[:, ~test.isna().all(axis=0)]
        print("[s70] Dropped all-NaN columns per split (config/flag).")

    # ----------------- target -----------------
    y_train = _build_target(train, label_threshold)
    y_val   = _build_target(val,   label_threshold)
    y_test  = _build_target(test,  label_threshold)

    # ----------------- features -----------------
    feature_cols, num_cols_all, cat_cols, dropped = _select_features(train, forbidden_features, cat_features)

    keep_num = _maybe_filter_low_corr_numeric(train[num_cols_all].copy(), y_train, float(min_abs_corr))
    num_cols = keep_num
    feature_cols = num_cols + cat_cols

    X_train = train[feature_cols].copy()
    X_val   = val[feature_cols].copy()
    X_test  = test[feature_cols].copy()

    print(f"[s70] Features: {len(num_cols)} numeric, {len(cat_cols)} categorical")
    if dropped:
        print(f"[s70] Dropped (IDs/leakage): {sorted([c for c in forbidden_features if c in train.columns])}")

    for c in cat_cols:
        X_train[c] = X_train[c].astype("string").fillna("__NA__")
        X_val[c]   = X_val[c].astype("string").fillna("__NA__")
        X_test[c]  = X_test[c].astype("string").fillna("__NA__")

    pre = ColumnTransformer(
        transformers=[
            ("num", "passthrough", num_cols),
            ("cat", _build_encoder(cat_cols, ohe_min_freq), cat_cols),
        ],
        remainder="drop",
    )

    # Fit/transform
    Xtr_full = pre.fit_transform(X_train)
    Xva_full = pre.transform(X_val)
    Xte_full = pre.transform(X_test)

    # Names before constant-drop (for s71 robustness)
    try:
        pre_full_names = pre.get_feature_names_out().tolist()
    except Exception:
        cat_names = []
        ohe = pre.named_transformers_.get("cat")
        if ohe is not None and len(cat_cols) > 0:
            try:
                cat_names = ohe.get_feature_names_out(cat_cols).tolist()
            except Exception:
                cat_names = [f"{c}__1" for c in cat_cols]
        pre_full_names = [f"num__{c}" for c in num_cols] + [f"cat__{n}" for n in cat_names]

    # Drop constant columns (mask shared across splits)
    tr_std = np.nanstd(Xtr_full, axis=0)
    keep_mask = tr_std > 0.0
    if (~keep_mask).sum() > 0:
        print(f"[s70] Dropping {(~keep_mask).sum()} constant features after preprocessing.")

    Xtr = Xtr_full[:, keep_mask]; Xva = Xva_full[:, keep_mask]; Xte = Xte_full[:, keep_mask]
    masked_idx = np.where(keep_mask)[0]
    feat_names = [f for f, k in zip(pre_full_names, keep_mask) if k]

    # ---- Base model & early stopping ----
    model = _make_model(model_name)
    print(f"[s70] Training ({model_name}, task=classification)…")
    model = _fit_with_early_stopping(model, Xtr, y_train, Xva, y_val)

    # ---- Save base importances (before calibration), if available ----
    try:
        if hasattr(model, "feature_importances_"):
            base_fi = (pd.DataFrame({"feature": feat_names, "importance": model.feature_importances_})
                         .sort_values("importance", ascending=False))
            base_fi_path = (P.ROOT / "models") / f"classifier_feature_importances_base_{_ts()}.csv"
            base_fi_path.parent.mkdir(parents=True, exist_ok=True)
            base_fi.to_csv(base_fi_path, index=False)
            print(f"[OK] Base importances → {base_fi_path}")
    except Exception:
        pass

    # ---- Calibration (choose best on VAL) ----
    def _calibrate_best(base_model, Xva_, yva_):
        preds_val = _safe_predict_proba(base_model, Xva_)

        def score_probs(p):
            return log_loss(yva_, np.clip(p, 1e-6, 1-1e-6)), brier_score_loss(yva_, p)

        cand = [("none", base_model, preds_val, *score_probs(preds_val))]

        def wrap(method: str):
            if HAS_FROZEN:
                est = FrozenEstimator(base_model)
                cc = CalibratedClassifierCV(est, method=method, cv="prefit")
            else:
                cc = CalibratedClassifierCV(base_model, method=method, cv="prefit")
            cc.fit(Xva_, yva_)
            p = _safe_predict_proba(cc, Xva_)
            ll, br = score_probs(p)
            return cc, p, ll, br

        for m in ("isotonic", "sigmoid"):
            try:
                cc, p, ll, br = wrap(m)
                cand.append((m, cc, p, ll, br))
            except Exception as e:
                print(f"[WARN] Calibration '{m}' failed: {e}")

        cand.sort(key=lambda t: (t[3], t[4]))  # by logloss, then brier
        return cand[0][0], cand[0][1]

    cal_name, calibrated_model = _calibrate_best(model, Xva, y_val)
    print(f"[s70] Chosen calibration → {cal_name}")

    # ---- Evaluate TRAIN / VAL / TEST ----
    train_prob = _safe_predict_proba(calibrated_model, Xtr)
    val_prob   = _safe_predict_proba(calibrated_model, Xva)
    test_prob  = _safe_predict_proba(calibrated_model, Xte)

    thr_decision = float(decision_threshold)

    train_metrics = _metrics_binary(y_train, train_prob, thresh=thr_decision)
    val_metrics   = _metrics_binary(y_val,   val_prob,   thresh=thr_decision)
    test_metrics  = _metrics_binary(y_test,  test_prob,  thresh=thr_decision)

    # ---- Prepare output dirs and timestamp ----
    models_dir = P.ROOT / "models"
    models_dir.mkdir(parents=True, exist_ok=True)
    ts = _ts()

    # ---- Save prediction CSVs for all splits ----
    def _write_preds(df_base: pd.DataFrame, y_true, y_prob, fname: str, thr: float):
        df_out = df_base.copy()
        df_out["y_true"] = pd.Series(y_true, index=df_out.index).values
        df_out["y_prob"] = pd.Series(y_prob, index=df_out.index).values
        df_out["y_pred"] = (df_out["y_prob"] >= thr).astype(int)
        df_out["threshold_used"] = float(thr)
        df_out.to_csv(models_dir / fname, index=False)

    _write_preds(train, y_train.values, train_prob, f"classifier_train_predictions_{ts}.csv", thr_decision)
    _write_preds(val,   y_val.values,   val_prob,   f"classifier_val_predictions_{ts}.csv",   thr_decision)
    _write_preds(test,  y_test.values,  test_prob,  f"classifier_test_predictions_{ts}.csv",  thr_decision)

    # ---------- Merge Quality & Action Guidance ----------
    quality_file = P.ROOT / "param_results" / "per_ticker_quality.csv"
    if not quality_file.exists():
        raise SystemExit(f"[ERR] Missing quality file: {quality_file}. Run s69_quality_check.py after s68_split_dataset.py.")
    quality_df = pd.read_csv(quality_file)[["ticker", "quality"]]

    test_out = test.copy()
    test_out["y_true"] = y_test.values
    test_out["y_prob"] = test_prob
    test_out["y_pred"] = (test_out["y_prob"] >= thr_decision).astype(int)
    test_out = test_out.merge(quality_df, on="ticker", how="left")

    # ML usability via quality or whitelist
    test_out["ml_usable"] = test_out["quality"].isin(["High Confidence", "Medium (OK)"])
    wl_file = CFG.get("live", {}).get("whitelist_file", "param_results/s70_whitelist.csv")
    wl_path = P.ROOT / wl_file
    if wl_path.exists():
        try:
            wl = pd.read_csv(wl_path)[["ticker"]].drop_duplicates()
            wl["ml_usable"] = True
            test_out = test_out.drop(columns=["ml_usable"]).merge(wl, on="ticker", how="left")
            test_out["ml_usable"] = test_out["ml_usable"].fillna(False).astype(bool)
            print(f"[s70] Applied whitelist override → {wl_path}")
        except Exception as e:
            print(f"[WARN] Failed to apply whitelist override: {e}")

    guidance_map = {
        "High Confidence": "Trust both signal + ML projection. Trade with confidence.",
        "Medium (OK)":     "Signal + ML OK, expect higher variance. Use smaller size.",
        "Risky":           "Signal only. Ignore ML projection. Use chart reading.",
        "No Go":           "Signal only. Manual confirmation required."
    }
    test_out["action_guidance"] = test_out["quality"].map(guidance_map)

    preferred_cols = [c for c in ["date","entry_dt","ticker","signal","y_prob","y_pred","y_true","quality","ml_usable","action_guidance"] if c in test_out.columns]
    if not preferred_cols:
        preferred_cols = ["ticker","y_prob","y_pred","y_true","quality","action_guidance"]
    live_df = test_out[preferred_cols].copy()

    live_dir = P.ROOT / "param_results"
    live_dir.mkdir(parents=True, exist_ok=True)
    live_csv = live_dir / f"s70_results_with_guidance_{ts}.csv"
    live_parquet = live_dir / f"s70_results_with_guidance_{ts}.parquet"
    live_df.to_csv(live_csv, index=False)
    try:
        live_df.to_parquet(live_parquet, index=False)
    except Exception:
        pass
    print(f"[OK] Live results with quality/guidance → {live_csv}")
    
    # ---------- Console summary: Quality buckets in TEST ----------
    try:
        qc = (test_out["quality"]
            .value_counts(dropna=False)
            .rename_axis("quality")
            .reset_index(name="count"))
        total_rows = len(test_out)
        qc["share_%"] = (qc["count"] / max(total_rows, 1) * 100).round(1)
        print("\n[TEST Quality Breakdown]")
        for _, r in qc.iterrows():
            q = r["quality"] if pd.notna(r["quality"]) else "UNKNOWN"
            print(f"  {q:<16} {r['count']:>5} rows  ({r['share_%']:>4.1f}%)")
        print(f"  {'TOTAL':<16} {total_rows:>5} rows")
    except Exception as e:
        print(f"[WARN] Could not produce TEST quality breakdown: {e}")
    
    # ---- Save model bundle & feature list ----
    model_path   = models_dir / f"classifier_{ts}.pkl"
    metrics_path = models_dir / f"classifier_metrics_{ts}.json"
    feats_path   = models_dir / f"classifier_feature_names_{ts}.json"

    # Save features list (pretty)
    with open(feats_path, "w") as f:
        json.dump(feat_names, f, indent=2)

    # ---- Feature guard check ----
    FORBIDDEN_EXACT = {"ret_trade","pnl_eur","entry_px","exit_px","exit_dt","trade_id","num_fills","legs"}
    FORBIDDEN_FUZZY = [
        "pnl","profit","loss","ret_trade","exit_dt","exit_px","realized",
        "closing_pnl","exit_","close_pnl","realized_pnl"
    ]

    def _strip_prefix(n: str) -> str:
        if n.startswith("num__"): return n[5:]
        if n.startswith("cat__"): return n[5:]
        if n.startswith("ticker_"): return n[7:]
        return n

    off_exact, off_fuzzy = [], []
    for n in feat_names:
        base = _strip_prefix(n)
        if base in FORBIDDEN_EXACT:
            off_exact.append(n)
        if any(tok in n.lower() for tok in FORBIDDEN_FUZZY):
            off_fuzzy.append(n)

    if off_exact or off_fuzzy:
        print("[LEAK BLOCK] Forbidden features detected!")
        if off_exact:
            print(" Exact (first 10):", off_exact[:10])
        if off_fuzzy:
            print(" Fuzzy (first 10):", off_fuzzy[:10])
        raise SystemExit("[ERR] Feature guard failed. Adjust features or config.")

    # ---- Continue with bundle ----
    bundle = {
        "pre": pre,
        "model": calibrated_model,
        "calibration": cal_name,
        "base_model_name": model_name,
        "label_threshold": float(label_threshold),
        "min_abs_corr": float(min_abs_corr),
        # for s71 robustness:
        "pre_full_names": pre_full_names,      # names before constant-drop
        "masked_idx": masked_idx,              # indices kept after constant-drop
        "feature_names": feat_names,           # names after constant-drop (aligned to masked_idx)
        # for reference:
        "num_cols": num_cols,
        "cat_cols": cat_cols,
    }
    joblib.dump(bundle, model_path)

    # ---- Leakage & split audit ----
    used_simple_names = [n.replace("num__", "", 1) if n.startswith("num__") else n for n in feat_names]
    audit = _audit_splits_and_leakage(
        models_dir=models_dir,
        ts=ts,
        used_feature_columns=used_simple_names,
        train_df=train,
        val_df=val,
        test_df=test,
        forbidden_feature_names=set(forbidden_features),
    )

    # ---- Write metrics JSON (with audit & config echo) ----
    with open(metrics_path, "w") as f:
        json.dump(
            {
                "task": "classification",
                "model": model_name,
                "calibration": cal_name,
                "threshold": float(label_threshold),
                "min_abs_corr": float(min_abs_corr),
                "decision_threshold": float(thr_decision),
                "train": train_metrics,
                "val":   val_metrics,
                "test":  test_metrics,
                "audit": audit,
                "config_file": str(CFG_DIR / "s70_config.json"),
            },
            f,
            indent=2,
        )

    # ---- Console summary ----
    print(f"\n[OK] Model      → {model_path}")
    print(f"[OK] Metrics    → {metrics_path}")
    print(f"[OK] Features   → {feats_path}")
    print(f"[OK] Train preds→ {models_dir / f'classifier_train_predictions_{ts}.csv'}")
    print(f"[OK] Val preds  → {models_dir / f'classifier_val_predictions_{ts}.csv'}")
    print(f"[OK] Test preds → {models_dir / f'classifier_test_predictions_{ts}.csv'}")
    print(f"[OK] Live CSV   → {live_csv}")
    print(f"[INFO] Decision threshold used: {thr_decision:.2f}")

if __name__ == "__main__":
    main()