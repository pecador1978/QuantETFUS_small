#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
s70a_metrics_split_report.py  (CONFIG-MANAGED)
Auto-discover latest s70 prediction CSVs and report metrics for TRAIN / VAL / TEST.
Reads decision_threshold from config/s70_config.json (unless y_pred already saved).

Looks for:
  <ROOT>/models/classifier_train_predictions_*.csv
  <ROOT>/models/classifier_val_predictions_*.csv
  <ROOT>/models/classifier_test_predictions_*.csv

Outputs:
  - prints a neat table to stdout
  - <ROOT>/param_results/s70_split_metrics_summary_<ts>.csv
"""

from __future__ import annotations
from pathlib import Path
from datetime import datetime, timezone
import sys
import re
import json
import pandas as pd
import numpy as np
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score, roc_auc_score
)

# ---------- project-aware paths ----------
SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
from common.paths import P  # uses your canonical ROOT

MODELS_DIR = P.ROOT / "models"
OUT_DIR    = P.ROOT / "param_results"
CFG_PATH   = P.CONFIG_DIR / "s70_config.json"

PATTERNS = {
    "train": re.compile(r"classifier_train_predictions_(\d{8}_\d{4})\.csv$"),
    "val":   re.compile(r"classifier_val_predictions_(\d{8}_\d{4})\.csv$"),
    "test":  re.compile(r"classifier_test_predictions_(\d{8}_\d{4})\.csv$"),
}

def _ts() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%d_%H%M")

def _load_cfg_threshold() -> float:
    if CFG_PATH.exists():
        try:
            with open(CFG_PATH, "r") as f:
                cfg = json.load(f)
            return float(cfg.get("decision_threshold", 0.50))
        except Exception:
            pass
    return 0.50

def _latest_file(split: str) -> Path | None:
    pat = PATTERNS[split]
    best = None
    best_ts = ""
    for p in MODELS_DIR.glob(f"classifier_{split}_predictions_*.csv"):
        m = pat.search(p.name)
        if not m:
            continue
        ts = m.group(1)
        if ts > best_ts:
            best_ts = ts
            best = p
    return best

def _load_preds(fp: Path, thr_default: float) -> pd.DataFrame:
    df = pd.read_csv(fp)
    # normalize column names: s70 writes y_true, y_prob, y_pred
    if "y_prob" in df.columns and "y_score" not in df.columns:
        df = df.rename(columns={"y_prob": "y_score"})
    missing = [c for c in ["y_true", "y_score"] if c not in df.columns]
    if missing:
        raise SystemExit(f"[ERR] {fp} missing required columns: {missing}")
    if "y_pred" not in df.columns:
        # re-derive using config threshold
        df["y_pred"] = (df["y_score"].astype(float) >= float(thr_default)).astype(int)
        df["threshold_used"] = float(thr_default)
    return df[["y_true","y_score","y_pred","threshold_used"]].copy()

def _metrics(df: pd.DataFrame) -> dict:
    y_true  = df["y_true"].astype(int).values
    y_pred  = df["y_pred"].astype(int).values
    y_score = df["y_score"].astype(float).values
    out = {
        "n": int(len(y_true)),
        "accuracy": accuracy_score(y_true, y_pred),
        "precision": precision_score(y_true, y_pred, zero_division=0),
        "recall": recall_score(y_true, y_pred, zero_division=0),
        "f1": f1_score(y_true, y_pred, zero_division=0),
    }
    try:
        out["roc_auc"] = roc_auc_score(y_true, y_score)
    except Exception:
        out["roc_auc"] = np.nan
    return out

def main():
    # decision threshold from config (fallback 0.50)
    thr_cfg = _load_cfg_threshold()

    # find latest files for all three splits
    files = {split: _latest_file(split) for split in ["train","val","test"]}
    missing = [k for k, v in files.items() if v is None]
    if missing:
        raise SystemExit(f"[ERR] Could not find prediction CSVs for: {', '.join(missing)} in {MODELS_DIR}")

    rows = []
    for split in ["train","val","test"]:
        df = _load_preds(files[split], thr_cfg)
        m = _metrics(df)
        m["split"] = split
        # prefer saved threshold_used (from s70), else cfg
        used_thr = float(df.get("threshold_used", pd.Series([], dtype=float)).iloc[0]) if "threshold_used" in df.columns and len(df) else thr_cfg
        m["threshold_used"] = used_thr
        rows.append(m)

    summary = (pd.DataFrame(rows)
                 .loc[:, ["split","n","threshold_used","accuracy","precision","recall","f1","roc_auc"]]
                 .sort_values("split"))

    print(summary.to_string(index=False))

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    out_path = OUT_DIR / f"s70_split_metrics_summary_{_ts()}.csv"
    summary.to_csv(out_path, index=False)
    print(f"\n[OK] Saved: {out_path}")

if __name__ == "__main__":
    main()