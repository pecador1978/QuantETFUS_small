#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Run s70 with decision_threshold=0.10 and then print split metrics.
Outputs land in the usual places:
- models/classifier_*_predictions_<ts>.csv (with threshold_used=0.10)
- param_results/s70_split_metrics_summary_<ts>.csv
"""

from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent.parent
PY   = str(ROOT / "venv" / "bin" / "python")
S70  = str(ROOT / "scripts" / "s70_train_model_classifier_calibrated.py")
S70A = str(ROOT / "scripts" / "s70a_metrics_split_report.py")

def run(cmd):
    print("+", " ".join(cmd))
    r = subprocess.run(cmd)
    if r.returncode != 0:
        sys.exit(r.returncode)

def main():
    run([PY, S70, "--decision_threshold", "0.10"])
    run([PY, S70A])

if __name__ == "__main__":
    main()