#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
s73_eval_per_ticker.py — Per-ticker metrics for TRAIN / VAL / TEST.

Defaults:
- Auto-load the latest predictions produced by s70:
    models/classifier_train_predictions_*.csv
    models/classifier_val_predictions_*.csv
    models/classifier_test_predictions_*.csv

Outputs:
    models/per_ticker_metrics_train_<ts>.csv
    models/per_ticker_metrics_val_<ts>.csv
    models/per_ticker_metrics_test_<ts>.csv
    models/per_ticker_metrics_ALL_<ts>.csv   (stacked with a 'split' column)
"""

from __future__ import annotations
import argparse, glob
from pathlib import Path
from datetime import datetime, timezone
import sys, numpy as np, pandas as pd
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score

# ---- project paths ----
SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
from common.paths import P

def _ts(): return datetime.now(timezone.utc).strftime("%Y%m%d_%H%M")
def _latest(pattern: str) -> Path | None:
    c = sorted(glob.glob(str((P.ROOT / "models" / pattern).resolve())))
    return Path(c[-1]) if c else None

def _ensure_cols(df: pd.DataFrame):
    need = {"ticker", "y_true"}
    if not need.issubset(df.columns):
        raise SystemExit(f"[ERR] predictions missing required columns {need}")
    # autodetect proba/score
    cand = [c for c in ["y_prob","y_pred_prob","proba","prob","score"] if c in df.columns]
    proba = cand[0] if cand else None
    # fallback to y_pred if no proba present
    ypred_col = "y_pred" if "y_pred" in df.columns else None
    return proba, ypred_col

def _per_ticker(df: pd.DataFrame, min_n: int, thr: float | None):
    proba_col, ypred_col = _ensure_cols(df)
    rows = []
    for tkr, g in df.groupby("ticker"):
        if len(g) < min_n: 
            continue
        y_true = g["y_true"].astype(int).values
        if proba_col:
            y_prob = g[proba_col].astype(float).values
            thr_used = thr if thr is not None else 0.5
            y_pred = (y_prob >= thr_used).astype(int)
            try: auc = float(roc_auc_score(y_true, y_prob))
            except Exception: auc = float("nan")
        else:
            if not ypred_col:
                continue
            y_pred = g[ypred_col].astype(int).values
            auc = float("nan")
            thr_used = float("nan")

        rows.append({
            "ticker": tkr,
            "n": len(g),
            "accuracy": float(accuracy_score(y_true, y_pred)),
            "precision": float(precision_score(y_true, y_pred, zero_division=0)),
            "recall": float(recall_score(y_true, y_pred, zero_division=0)),
            "f1": float(f1_score(y_true, y_pred, zero_division=0)),
            "roc_auc": auc,
            "thr_used": thr_used,
        })
    if not rows:
        return pd.DataFrame(columns=["ticker","n","accuracy","precision","recall","f1","roc_auc","thr_used"])
    out = pd.DataFrame(rows).sort_values(["accuracy","f1","roc_auc","n"], ascending=[False,False,False,False])
    # add weighted overall row
    if len(out):
        w = out["n"] / out["n"].sum()
        overall = {
            "ticker": "__ALL__ (weighted)",
            "n": int(out["n"].sum()),
            "accuracy": float(np.average(out["accuracy"], weights=w)),
            "precision": float(np.average(out["precision"], weights=w)),
            "recall": float(np.average(out["recall"], weights=w)),
            "f1": float(np.average(out["f1"], weights=w)),
            "roc_auc": float(np.average(out["roc_auc"].fillna(out["roc_auc"].mean()), weights=w)),
            "thr_used": out["thr_used"].iloc[0] if "thr_used" in out.columns and out["thr_used"].notna().any() else np.nan,
        }
        out = pd.concat([pd.DataFrame([overall]), out], ignore_index=True)
    return out

def main():
    ap = argparse.ArgumentParser()
    # Option A: single file → computes metrics for that file only
    ap.add_argument("--preds", type=str, default=None, help="Path to a predictions CSV (single split).")
    # Option B: let the script discover train/val/test (or override per-split)
    ap.add_argument("--train_preds", type=str, default=None)
    ap.add_argument("--val_preds", type=str, default=None)
    ap.add_argument("--test_preds", type=str, default=None)
    ap.add_argument("--thr", type=float, default=0.50, help="Threshold used when proba available.")
    ap.add_argument("--min_n", type=int, default=30, help="Minimum rows per ticker.")
    args = ap.parse_args()

    models_dir = P.ROOT / "models"
    models_dir.mkdir(parents=True, exist_ok=True)
    ts = _ts()

    # ---- single file mode
    if args.preds:
        df = pd.read_csv(args.preds)
        res = _per_ticker(df, min_n=args.min_n, thr=args.thr)
        out = models_dir / f"per_ticker_metrics_{ts}.csv"
        res.to_csv(out, index=False)
        print(f"[OK] Per-ticker metrics → {out}")
        print(res.head(20).to_string(index=False))
        return

    # ---- multi-split mode (default)
    train_p = Path(args.train_preds) if args.train_preds else _latest("classifier_train_predictions_*.csv")
    val_p   = Path(args.val_preds)   if args.val_preds   else _latest("classifier_val_predictions_*.csv")
    test_p  = Path(args.test_preds)  if args.test_preds  else _latest("classifier_test_predictions_*.csv")

    if not all([train_p, val_p, test_p]):
        raise SystemExit("[ERR] Could not locate latest train/val/test predictions in models/. "
                         "You can pass them explicitly with --train_preds / --val_preds / --test_preds.")

    split_files = {"train": train_p, "val": val_p, "test": test_p}
    combined = []
    for split, path in split_files.items():
        df = pd.read_csv(path)
        res = _per_ticker(df, min_n=args.min_n, thr=args.thr)
        res_path = models_dir / f"per_ticker_metrics_{split}_{ts}.csv"
        res.to_csv(res_path, index=False)
        print(f"[OK] {split.upper()} per-ticker → {res_path}")
        res.insert(0, "split", split)
        combined.append(res)

    all_df = pd.concat(combined, ignore_index=True)
    all_path = models_dir / f"per_ticker_metrics_ALL_{ts}.csv"
    all_df.to_csv(all_path, index=False)
    print(f"[OK] ALL splits (stacked) → {all_path}")
    print(all_df.head(30).to_string(index=False))

if __name__ == "__main__":
    main()