#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from __future__ import annotations

import argparse, subprocess, sys, time
from pathlib import Path
from datetime import datetime, timezone
import pandas as pd

# ----- bootstrap -----
SCRIPT_DIR   = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from common.paths import P  # type: ignore

# Engines (your exact filenames)
S50 = P.SCRIPTS_DIR / "s50_30m_backtest_engine.py"
S51 = P.SCRIPTS_DIR / "s51_liquidity_sweep_engine.py"
S52 = P.SCRIPTS_DIR / "s52_30m_backtest_engine_atr_fib.py"

# Outdirs
OUT30      = P.ROOT / "backtest_results_30m"
OUT30_S52  = P.ROOT / "backtest_results_30m_s52"
OUTCMP     = P.ROOT / "backtest_results_compare"
OUTCMP.mkdir(parents=True, exist_ok=True)

def _run(tag: str, script: Path, common_args: list[str], extra: list[str]) -> float:
    if not script.exists():
        raise SystemExit(f"[ERR] {tag}: script not found at {script}")
    start = time.time()
    cmd = [sys.executable, str(script), *common_args, *extra]
    print(f"\n[{tag}] Running:\n  {' '.join(map(str, cmd))}\n")
    res = subprocess.run(cmd, check=False, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    if res.stdout:
        print(res.stdout)
    if res.returncode != 0:
        raise SystemExit(f"[ERR] {tag} exited with code {res.returncode}")
    return start

def _newest(paths: list[Path]) -> Path | None:
    return max(paths, key=lambda p: p.stat().st_mtime) if paths else None

def _pick_latest_from_dirs(outdirs: list[Path], prefix: str, stem: str, after_ts: float | None) -> Path | None:
    """
    Prefer files '<prefix>_<stem>_*.csv' written after 'after_ts'. Fallback:
      - newest prefixed any time
      - newest generic '<stem>_*.csv' after 'after_ts'
      - newest generic any time
      Across all outdirs in order.
    """
    cands_pref_recent, cands_pref_all, cands_gen_recent, cands_gen_all = [], [], [], []
    for d in outdirs:
        if not d.exists():
            continue
        pref = list(d.glob(f"{prefix}_{stem}_*.csv"))
        gen  = list(d.glob(f"{stem}_*.csv"))
        if after_ts is not None:
            cands_pref_recent += [p for p in pref if p.stat().st_mtime >= after_ts - 1.0]
            cands_gen_recent  += [p for p in gen  if p.stat().st_mtime >= after_ts - 1.0]
        cands_pref_all += pref
        cands_gen_all  += gen
    return (
        _newest(cands_pref_recent) or
        _newest(cands_pref_all)    or
        _newest(cands_gen_recent)  or
        _newest(cands_gen_all)
    )

def _load_by_ticker(df_path: Path, tag: str) -> pd.DataFrame:
    df = pd.read_csv(df_path)
    cols = {c.lower(): c for c in df.columns}
    if "avg" in cols and "mean" not in cols:
        df.rename(columns={cols["avg"]: "mean"}, inplace=True)
        cols = {c.lower(): c for c in df.columns}
    need = {"ticker","fills","mean","median"}
    if not need.issubset(cols.keys()):
        raise SystemExit(f"[ERR] {tag}: {df_path.name} missing {need} (has {list(df.columns)})")
    out = df.rename(columns={
        cols["ticker"]: "ticker",
        cols["fills"]:  f"{tag}_fills",
        cols["mean"]:   f"{tag}_mean",
        cols["median"]: f"{tag}_median",
    })
    return out[["ticker", f"{tag}_fills", f"{tag}_mean", f"{tag}_median"]]

def _load_cap_by_ticker(df_path: Path, tag: str) -> pd.DataFrame:
    df = pd.read_csv(df_path)
    cols = {c.lower(): c for c in df.columns}
    need = {"ticker","win_rate","total_return","num_trades"}
    if not need.issubset(cols.keys()):
        return pd.DataFrame(columns=["ticker",
                                     f"{tag}_win_rate",
                                     f"{tag}_total_return",
                                     f"{tag}_num_trades"])
    out = df.rename(columns={
        cols["ticker"]: "ticker",
        cols["win_rate"]: f"{tag}_win_rate",
        cols["total_return"]: f"{tag}_total_return",
        cols["num_trades"]: f"{tag}_num_trades",
    })
    return out[["ticker", f"{tag}_win_rate", f"{tag}_total_return", f"{tag}_num_trades"]]

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--unit_capital", type=float, default=10000.0)
    ap.add_argument("--fees_fixed",  type=float, default=3.0)
    ap.add_argument("--slip_bps",    type=float, default=0.0)
    ap.add_argument("--cooldown_days", type=int, default=0)
    ap.add_argument("--s50_extra", type=str, default="")
    ap.add_argument("--s51_extra", type=str, default="")
    ap.add_argument("--s52_extra", type=str, default="")
    args = ap.parse_args()

    common = [
        "--unit_capital", str(args.unit_capital),
        "--fees_fixed",   str(args.fees_fixed),
        "--slip_bps",     str(args.slip_bps),
        "--cooldown_days",str(args.cooldown_days),
    ]

    # Run engines (record start times)
    t_s50 = _run("s50", S50, common, args.s50_extra.split() if args.s50_extra else [])
    t_s51 = _run("s51", S51, common, args.s51_extra.split() if args.s51_extra else [])
    t_s52 = _run("s52", S52, common, args.s52_extra.split() if args.s52_extra else [])

    # Resolve outputs (note: s52 searches both dirs)
    files = {
        "s50": {
            "dirs": [OUT30],
            "trades": _pick_latest_from_dirs([OUT30], "s50", "trades", t_s50),
            "by":     _pick_latest_from_dirs([OUT30], "s50", "summary_by_ticker", t_s50),
            "cap":    _pick_latest_from_dirs([OUT30], "s50", "summary_capital_by_ticker", t_s50),
        },
        "s51": {
            "dirs": [OUT30],
            "trades": _pick_latest_from_dirs([OUT30], "s51", "trades", t_s51),
            "by":     _pick_latest_from_dirs([OUT30], "s51", "summary_by_ticker", t_s51),
            "cap":    _pick_latest_from_dirs([OUT30], "s51", "summary_capital_by_ticker", t_s51),
        },
        "s52": {
            "dirs": [OUT30_S52, OUT30],  # <- search both
            "trades": _pick_latest_from_dirs([OUT30_S52, OUT30], "s52", "trades", t_s52),
            "by":     _pick_latest_from_dirs([OUT30_S52, OUT30], "s52", "summary_by_ticker", t_s52),
            "cap":    _pick_latest_from_dirs([OUT30_S52, OUT30], "s52", "summary_capital_by_ticker", t_s52),
        },
    }

    # Diagnostics
    for tag in ("s50","s51","s52"):
        print(f"\n[INFO] {tag} search dirs = {', '.join(map(str, files[tag]['dirs']))}")
        print(f"       trades: {files[tag]['trades']}")
        print(f"       by:     {files[tag]['by']}")
        print(f"       cap:    {files[tag]['cap']}")

    # Guardrails
    for tag in ("s50","s51","s52"):
        if files[tag]["by"] is None:
            raise SystemExit(f"[ERR] {tag}: summary_by_ticker not found in any of: {', '.join(map(str, files[tag]['dirs']))}.")
        if files[tag]["trades"] is None:
            raise SystemExit(f"[ERR] {tag}: trades not found in any of: {', '.join(map(str, files[tag]['dirs']))}.")

    # Build comparison
    s50_by = _load_by_ticker(files["s50"]["by"], "s50")
    s51_by = _load_by_ticker(files["s51"]["by"], "s51")
    s52_by = _load_by_ticker(files["s52"]["by"], "s52")

    comp = s50_by.merge(s51_by, on="ticker", how="outer").merge(s52_by, on="ticker", how="outer")

    # Optional extras
    for tag in ("s50","s51","s52"):
        cap_path = files[tag]["cap"]
        if cap_path:
            comp = comp.merge(_load_cap_by_ticker(cap_path, tag), on="ticker", how="left")

    ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M")
    out_csv = OUTCMP / f"compare_by_ticker_{ts}.csv"
    comp.to_csv(out_csv, index=False)
    print(f"\n[OK] Wrote comparison → {out_csv}\n")

if __name__ == "__main__":
    main()