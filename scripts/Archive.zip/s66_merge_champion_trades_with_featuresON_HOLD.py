#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
s66_merge_champion_trades_with_features.py

Merge champion trades with:
  (A) ETF DAILY features from s30 → data_enriched/prices_enriched.parquet (prefixed: self_*)
  (B) Macro/FX DAILY context from s31 → data_enriched/macro_forex_enriched.parquet (wide: SPY_*, GLD_*, DXY_*, ...; includes SPY_vermeulen_color if present)
  (C) Optional 30‑minute context from s32 → data_enriched/30min/{TICKER}.parquet (prefixed: m30_*)

Joins:
  A: left join on (ticker, entry_date)
  B: merge_asof (backward) on entry_date (handles weekends/holidays)
  C: merge_asof (backward) on entry_dt (nearest 30m bar at/just before entry)

Outputs:
  dataset/ml/s66_ml_rows_<timestamp>.parquet
  dataset/ml/s66_ml_rows_<timestamp>.csv
  dataset/ml/s66_feature_columns_<timestamp>.txt
"""

from pathlib import Path
from datetime import datetime, timezone
import argparse, json, os, re, sys
import numpy as np
import pandas as pd
from joblib import Parallel, delayed
from zoneinfo import ZoneInfo

# ---------- perf hygiene ----------
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("VECLIB_MAXIMUM_THREADS", "1")
os.environ.setdefault("NUMEXPR_NUM_THREADS", "1")

# ---------- project-aware imports ----------
SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
from common.paths import P  # ROOT, DATA_ENRICHED, PARAM_RESULTS, CONFIG_DIR, etc.

PARAM_RESULTS = P.PARAM_RESULTS
TRADES_DIR    = PARAM_RESULTS / "trades"
CONFIG        = P.CONFIG_DIR / "s60_parameters.json"
A_TICKER_D    = P.DATA_ENRICHED / "prices_enriched.parquet"
B_MACRO_FX    = P.DATA_ENRICHED / "macro_forex_enriched.parquet"
C_30M_DIR     = P.DATA_ENRICHED / "30min"
OUT_DIR       = P.ROOT / "dataset" / "ml"
OUT_DIR.mkdir(parents=True, exist_ok=True)

# ---------- utils ----------
def _ts() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%d_%H%M")

def _latest_csv(dirpath: Path, prefix: str) -> Path:
    cands = sorted(dirpath.glob(f"{prefix}*.csv"))
    if not cands:
        raise SystemExit(f"[ERR] No files matching {prefix}*.csv in {dirpath}")
    return cands[-1]

def _load_param_keys(config_path: Path) -> list[str]:
    with open(config_path, "r") as f:
        cfg = json.load(f)
    return list(cfg.keys())

def _find_ranked_csvs(param_dir: Path, needle: str) -> list[Path]:
    out = []
    for p in param_dir.glob("param_results_*_*.csv"):
        n = p.name
        if n.startswith("param_results_ALL_"): 
            continue
        if n.endswith("_ALL.csv"):
            continue
        if needle and needle not in n:
            continue
        out.append(p)
    return out

def _parse_ticker_suffix(path: Path) -> tuple[str, str]:
    body = path.name[len("param_results_"):-len(".csv")]
    if "_" not in body:
        return body, "UNKNOWN"
    tkr, suf = body.split("_", 1)
    return tkr, suf

def _extract_seed(suffix: str) -> str:
    m = re.search(r"seed(\d+)", suffix)
    return f"seed{m.group(1)}" if m else "seed?"

def _row_matches_params(row: pd.Series, keys: list[str], target: dict) -> bool:
    for k in keys:
        tv = target.get(k, np.nan)
        rv = row.get(k, np.nan)
        if (pd.isna(tv) and pd.isna(rv)):
            continue
        if isinstance(tv, str) or isinstance(rv, str):
            if str(tv) != str(rv):
                return False
            continue
        try:
            if pd.isna(rv) and pd.isna(tv):
                continue
            if pd.isna(rv) or pd.isna(tv):
                return False
            if float(rv).is_integer() and float(tv).is_integer():
                if int(rv) != int(tv): return False
            else:
                if not np.isclose(float(rv), float(tv), rtol=1e-10, atol=1e-12):
                    return False
        except Exception:
            if str(rv) != str(tv):
                return False
    return True

def _to_utc(series, market_tz: str | None = None) -> pd.Series:
    s = pd.to_datetime(series, errors="coerce")
    tz = (market_tz or os.environ.get("MARKET_TZ") or "Europe/London")
    try:
        if s.dt.tz is None:
            s = s.dt.tz_localize(ZoneInfo(tz), nonexistent="shift_forward", ambiguous="NaT").dt.tz_convert("UTC")
        else:
            s = s.dt.tz_convert("UTC")
    except Exception:
        s = pd.to_datetime(series, errors="coerce").dt.tz_localize(ZoneInfo(tz), nonexistent="shift_forward", ambiguous="NaT").dt.tz_convert("UTC")
    return s

def _coalesce_x_y(df: pd.DataFrame) -> pd.DataFrame:
    cols = df.columns.tolist()
    for c in [c for c in cols if c.endswith("_x")]:
        base = c[:-2]
        y = base + "_y"
        if y in df.columns:
            df[base] = df[c].where(df[c].notna(), df[y])
            df = df.drop(columns=[c, y])
    # drop exact duplicate names (keep first)
    seen = set()
    keep = []
    for c in df.columns:
        if c not in seen:
            seen.add(c); keep.append(c)
    return df.loc[:, keep]

# ---------- loaders ----------
def _load_ticker_daily(path: Path, keep_base_ohlc: bool = True) -> tuple[pd.DataFrame, list[str]]:
    """
    Read prices_enriched.parquet, keep only daily features, and prefix with self_ to
    avoid collisions with macro tickers.
    """
    raw = pd.read_parquet(path)
    cols = list(raw.columns)
    lmap = {c.lower(): c for c in cols}

    # detect columns
    tcol = next((lmap[c] for c in ["ticker","symbol","tkr","asset","instrument","code"] if c in lmap), None)
    dcol = next((lmap[c] for c in ["datetime","dt","date","timestamp","time","ts","datetime_utc","time_utc"] if c in lmap), None)
    if not tcol or not dcol:
        raise SystemExit(f"[ERR] Could not detect ticker/datetime columns in {path}. Columns: {cols}")

    df = raw.rename(columns={tcol: "ticker", dcol: "datetime"}).copy()
    df["ticker"] = df["ticker"].astype(str)
    df["datetime"] = pd.to_datetime(df["datetime"], utc=True, errors="coerce")
    df["date"] = df["datetime"].dt.floor("D")

    daily = [c for c in df.columns if c.endswith("_d")]
    base_ohlc = [c for c in ["open","high","low","close","volume"] if c in df.columns] if keep_base_ohlc else []
    keep = ["ticker","date"] + daily + base_ohlc
    df = df[keep].drop_duplicates(subset=["ticker","date"])

    # prefix to self_
    rename = {c: (f"self_{c}" if c not in ("ticker","date") else c) for c in df.columns}
    df = df.rename(columns=rename)
    feature_cols = [c for c in df.columns if c not in ("ticker","date")]
    return df, feature_cols

def _macro_long_to_wide(df_long: pd.DataFrame) -> pd.DataFrame:
    # Normalize date/ticker
    dtcand = next((c for c in ["date","datetime","dt","day"] if c in df_long.columns), None)
    if not dtcand or "ticker" not in df_long.columns:
        return pd.DataFrame()
    out = df_long.rename(columns={dtcand: "date"}).copy()
    out["date"] = pd.to_datetime(out["date"], utc=True, errors="coerce").dt.floor("D")
    out["ticker"] = out["ticker"].astype(str)

    feat_cols = [c for c in out.columns if c not in ("date","ticker")]
    frames = []
    for feat in feat_cols:
        piv = out.pivot_table(index="date", columns="ticker", values=feat, aggfunc="last")
        piv = piv.rename(columns=lambda t: f"{t}_{feat}")
        frames.append(piv)
    wide = pd.concat(frames, axis=1).sort_index().reset_index()
    return wide

def _load_macro_fx(path: Path) -> pd.DataFrame | None:
    if not path.exists():
        print(f"[WARN] Macro/FX parquet missing: {path} (skipping)")
        return None
    m = pd.read_parquet(path)
    # already wide?
    if "date" in m.columns and "ticker" not in m.columns:
        m = m.copy()
        m["date"] = pd.to_datetime(m["date"], utc=True, errors="coerce").dt.floor("D")
        m = m.sort_values("date").drop_duplicates(subset=["date"])
        return m
    # try long → wide
    if "ticker" in m.columns and any(c in m.columns for c in ["date","datetime","dt","day"]):
        w = _macro_long_to_wide(m)
        if not w.empty:
            return w
    print(f"[WARN] Macro/FX parquet schema unexpected; columns={list(m.columns)[:20]}... Skipping macro.")
    return None

def _load_30m_for(ticker: str, m30_dir: Path) -> pd.DataFrame | None:
    f = m30_dir / f"{ticker}.parquet"
    if not f.exists():
        return None
    df = pd.read_parquet(f)
    # pick datetime col
    col = next((c for c in ["datetime","dt","time","timestamp","ts"] if c in df.columns), None)
    if not col:
        return None
    if col != "dt":
        df = df.rename(columns={col: "dt"})
    df["dt"] = pd.to_datetime(df["dt"], utc=True, errors="coerce")
    df = df.sort_values("dt")
    # add m30_ prefix
    rename = {c: (c if c.startswith("m30_") else f"m30_{c}") for c in df.columns if c != "dt"}
    df = df.rename(columns=rename)
    return df

# ---------- core merge ----------
def _merge_one_trade_block(tkr: str,
                           run_id: str,
                           trades_path: Path,
                           self_daily: pd.DataFrame,
                           macro_fx: pd.DataFrame | None,
                           m30_dir: Path | None) -> tuple[pd.DataFrame, str]:
    if not trades_path.exists():
        return pd.DataFrame(), "trades_file_missing"

    tr = pd.read_csv(trades_path)
    if tr is None or tr.empty:
        return pd.DataFrame(), "trades_empty"

    for c in ("entry_dt","exit_dt"):
        if c in tr.columns:
            tr[c] = _to_utc(tr[c])
        else:
            tr[c] = pd.NaT
    tr = tr.dropna(subset=["entry_dt"]).copy()
    if tr.empty:
        return pd.DataFrame(), "no_valid_entry_dt"

    tr["entry_date"] = tr["entry_dt"].dt.floor("D")
    tr["ticker"] = str(tkr)

    # (A) ETF self daily (prefixed)
    sd = self_daily[self_daily["ticker"] == tkr]
    if sd.empty:
        return pd.DataFrame(), "no_self_daily_for_ticker"
    tr = tr.merge(sd, left_on=["ticker","entry_date"], right_on=["ticker","date"], how="left").drop(columns=["date"])

    # (B) Macro/FX backward asof on date
    if macro_fx is not None and not macro_fx.empty:
        right = macro_fx.copy()
        if "date" not in right.columns:
            # attempt detect/rename
            c = next((c for c in ["datetime","dt","day"] if c in right.columns), None)
            if c: right = right.rename(columns={c: "date"})
        right["date"] = pd.to_datetime(right["date"], utc=True, errors="coerce").dt.floor("D")
        tr = pd.merge_asof(
            tr.sort_values("entry_date"),
            right.sort_values("date"),
            left_on="entry_date", right_on="date",
            direction="backward"
        )
        if "date" in tr.columns:
            tr = tr.drop(columns=["date"])

    # (C) 30m context
    if m30_dir is not None:
        m30 = _load_30m_for(tkr, m30_dir)
        if m30 is not None and not m30.empty:
            tr = pd.merge_asof(
                tr.sort_values("entry_dt"),
                m30.sort_values("dt"),
                left_on="entry_dt", right_on="dt",
                direction="backward"
            )
            if "dt" in tr.columns:
                tr = tr.drop(columns=["dt"])

    tr["run_id"] = run_id
    tr["seed"]   = _extract_seed(run_id)
    tr["trades_file"] = trades_path.name
    tr["y_ret_pct"] = pd.to_numeric(tr.get("ret_pct", np.nan), errors="coerce")

    tr = _coalesce_x_y(tr)
    return tr, ""

# ---------- main ----------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--param_dir",   default=str(P.PARAM_RESULTS))
    ap.add_argument("--trades_dir",  default=str(TRADES_DIR))
    ap.add_argument("--config",      default=str(CONFIG))
    ap.add_argument("--enriched",    default=str(A_TICKER_D))
    ap.add_argument("--macro",       default=str(B_MACRO_FX))
    ap.add_argument("--m30_dir",     default=str(C_30M_DIR))
    ap.add_argument("--filename_contains", default="_S6000")
    ap.add_argument("--n_jobs", type=int, default=6)
    ap.add_argument("--min_trades", type=int, default=0)
    ap.add_argument("--coverage_years_min", type=float, default=0.0)
    args = ap.parse_args()

    param_dir   = Path(args.param_dir)
    trades_dir  = Path(args.trades_dir)
    config_path = Path(args.config)
    enriched_pq = Path(args.enriched)
    macro_pq    = Path(args.macro)
    m30_dir     = Path(args.m30_dir) if args.m30_dir else None

    # champions & their parameter rows
    best_file = _latest_csv(param_dir, "s63_best_per_ticker_")
    print(f"[INFO] Champions file: {best_file}")
    best = pd.read_csv(best_file)
    if "coverage_years" in best.columns and args.coverage_years_min > 0:
        keep = best["coverage_years"] >= args.coverage_years_min
        drop = best.loc[~keep, "ticker"].tolist()
        if drop: print(f"[INFO] Dropping low-coverage tickers (<{args.coverage_years_min} yrs): {drop}")
        best = best.loc[keep].copy()
    champions = sorted(set(best["ticker"].astype(str)))
    param_keys = _load_param_keys(config_path)
    champ_params = {
        str(r["ticker"]): {k: (None if pd.isna(r.get(k)) else r.get(k)) for k in param_keys}
        for _, r in best.iterrows()
    }

    # per‑ticker files
    ranked_files = _find_ranked_csvs(param_dir, args.filename_contains)
    if not ranked_files:
        raise SystemExit(f"[ERR] No ranked per‑ticker files match '{args.filename_contains}'")

    # (A) self daily
    print(f"[INFO] Loading ETF daily (self_*) from: {enriched_pq}")
    self_daily, self_cols = _load_ticker_daily(enriched_pq, keep_base_ohlc=True)
    pq_tickers = sorted(self_daily["ticker"].unique().tolist())
    missing = [t for t in champions if t not in pq_tickers]
    print(f"[PRE] Champions ({len(champions)}): {champions}")
    print(f"[PRE] Parquet tickers ({len(pq_tickers)}): {pq_tickers[:30]}{' ...' if len(pq_tickers)>30 else ''}")
    if missing:
        print(f"[WARN] Champions missing in prices_enriched: {missing}")

    # (B) macro/FX
    macro_fx = _load_macro_fx(macro_pq)
    if macro_fx is None or macro_fx.empty:
        print("[INFO] Proceeding WITHOUT macro/FX enrichment.")
    else:
        ex_cols = [c for c in macro_fx.columns if c != "date"][:12]
        print(f"[INFO] Macro/FX ready. Example cols: {ex_cols}")

    # gather merge tasks
    tasks = []
    for p in ranked_files:
        tkr, suf = _parse_ticker_suffix(p)
        if tkr not in champ_params:
            continue
        df = pd.read_csv(p)
        if df is None or df.empty:
            continue
        if args.min_trades and "num_trades" in df.columns:
            df = df[df["num_trades"] >= args.min_trades].copy()
            if df.empty: 
                continue
        for k in param_keys:
            if k not in df.columns:
                df[k] = np.nan
        target = champ_params[tkr]
        hits = df[df.apply(lambda r: _row_matches_params(r, param_keys, target), axis=1)]
        for _, row in hits.iterrows():
            tf = row.get("trades_file", "")
            if tf:
                tasks.append((tkr, suf, trades_dir / tkr / str(tf)))

    if not tasks:
        raise SystemExit("[ERR] No champion trades found across seeds. Check filters.")

    print(f"[INFO] Champion trade files to merge: {len(tasks)}")

    # merge in parallel
    reasons = {}
    def do_one(arg):
        tkr, suf, path = arg
        d, reason = _merge_one_trade_block(tkr, suf, path, self_daily, macro_fx, m30_dir)
        if d is None or d.empty:
            reasons.setdefault(reason or "empty_after_merge", []).append((tkr, path.name))
        return d

    blocks = Parallel(n_jobs=args.n_jobs, backend="loky")(delayed(do_one)(t) for t in tasks)
    non_empty = [b for b in blocks if b is not None and not b.empty]
    if not non_empty:
        print("[ERR] Merge produced no rows. Diagnostics:")
        for why, items in reasons.items():
            print(f"  - {why}: {len(items)} case(s). Examples: {items[:3]}")
        print("Hints:")
        print("  • Ensure champions’ tickers exist in prices_enriched.parquet.")
        print("  • Ensure datetime is UTC and 'entry_date' matches parquet 'date'.")
        print("  • If using 30m, ensure data_enriched/30min/{T}.parquet exists.")
        raise SystemExit(1)

    merged = pd.concat(non_empty, ignore_index=True)
    merged = _coalesce_x_y(merged)

    # order columns: ids + label + self_* + macro_* + m30_* + rest
    id_cols    = ["ticker","run_id","seed","trades_file","entry_dt","exit_dt","entry_date"]
    label_cols = ["y_ret_pct"]
    self_like  = [c for c in merged.columns if c.startswith("self_")]
    macro_like = [c for c in merged.columns if (c != "date" and re.match(r"^[A-Z0-9]{2,}_.+", c))]
    m30_like   = [c for c in merged.columns if c.startswith("m30_")]

    seen = set()
    def uniq(seq):
        out = []
        for x in seq:
            if x not in seen:
                out.append(x); seen.add(x)
        return out

    keep = uniq([c for c in id_cols if c in merged.columns]) \
         + uniq([c for c in label_cols if c in merged.columns]) \
         + uniq(sorted(self_like)) + uniq(sorted(macro_like)) + uniq(sorted(m30_like))
    merged = merged[keep + [c for c in merged.columns if c not in keep]]

    # summary
    print(f"[SUMMARY] rows={len(merged):,}  tickers={merged['ticker'].nunique()}  "
          f"self={len(self_like)}  macro={len(macro_like)}  m30={len(m30_like)}")

    ts = _ts()
    out_parquet = OUT_DIR / f"s66_ml_rows_{ts}.parquet"
    out_csv     = OUT_DIR / f"s66_ml_rows_{ts}.csv"
    merged.to_parquet(out_parquet, index=False)
    merged.to_csv(out_csv, index=False)
    feat_list_path = OUT_DIR / f"s66_feature_columns_{ts}.txt"
    with open(feat_list_path, "w") as f:
        for c in [c for c in merged.columns if c not in id_cols + label_cols]:
            f.write(f"{c}\n")

    print(f"[OK] Wrote ML rows (parquet) → {out_parquet}")
    print(f"[OK] Wrote ML rows (csv)     → {out_csv}")
    print(f"[OK] Feature list            → {feat_list_path}")

if __name__ == "__main__":
    main()