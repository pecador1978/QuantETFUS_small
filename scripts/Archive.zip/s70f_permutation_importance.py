#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
s70f_permutation_importance.py — permutation-based feature importance for the calibrated classifier.

- Loads latest models/classifier_*.pkl (saved by s70).
- Uses exact preprocessing indices if available (masked_idx), else maps by names.
- Runs permutation importance on TEST (per-RAW-feature).
- Saves CSV (+ PNG if --plot).
- Optional grouped importances with --group simple.

Extra columns added:
- lb95  : 95% lower bound = mean - 1.96*std  (keep if > 0 to be conservative)
- zscore: mean / std (NaN if std==0)
- importance_pct_of_pos: share (%) of total positive importance (means clipped at 0)
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from pathlib import Path
from datetime import datetime, timezone
import sys
import numpy as np
import pandas as pd
import joblib

from sklearn.metrics import roc_auc_score, log_loss, brier_score_loss, accuracy_score, f1_score
from sklearn.inspection import permutation_importance
from sklearn.base import BaseEstimator

# ---- project-aware paths ----
SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
from common.paths import P  # ROOT, etc.


# ---------- utils ----------
def _ts() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%d_%H%M")


def _latest_model() -> Path | None:
    cands = sorted((P.ROOT / "models").glob("classifier_*.pkl"))
    return cands[-1] if cands else None


def load_test(path: Path | None = None) -> pd.DataFrame:
    path = path or (P.ROOT / "data_final_training" / "test.csv")
    if not path.exists():
        raise SystemExit(f"[ERR] TEST split not found: {path}")
    return pd.read_csv(path)


# ---------- estimator wrapper ----------
@dataclass
class WrappedEstimator(BaseEstimator):
    """
    Accepts RAW features (as given to permutation_importance), but internally:
      raw -> pre.transform -> select masked cols -> model.predict(_proba)
    """
    pre: object
    model: object
    masked_idx: np.ndarray
    masked_names: list[str]
    needs_proba: bool = True

    def fit(self, X=None, y=None):
        return self

    def _transform_mask(self, X):
        Z_full = self.pre.transform(X)
        Z = Z_full[:, self.masked_idx]
        try:
            return pd.DataFrame(Z, columns=self.masked_names)
        except Exception:
            return Z

    def predict_proba(self, X):
        Z_df = self._transform_mask(X)
        if hasattr(self.model, "predict_proba"):
            return self.model.predict_proba(Z_df)
        if hasattr(self.model, "decision_function"):
            s = self.model.decision_function(Z_df)
            p1 = 1.0 / (1.0 + np.exp(-s))
            p0 = 1.0 - p1
            return np.c_[p0, p1]
        yhat = self.model.predict(Z_df).astype(float)
        return np.c_[1.0 - yhat, yhat]

    def predict(self, X):
        if self.needs_proba and hasattr(self.model, "predict_proba"):
            proba = self.predict_proba(X)[:, 1]
            return (proba >= 0.5).astype(int)
        Z_df = self._transform_mask(X)
        return self.model.predict(Z_df)


def make_scorer(metric: str):
    m = metric.lower()
    if m == "roc_auc":
        def _score(est, X, y): return roc_auc_score(y, est.predict_proba(X)[:, 1])
        return _score, True
    if m == "log_loss":
        def _score(est, X, y): return -log_loss(y, np.clip(est.predict_proba(X)[:, 1], 1e-6, 1-1e-6))
        return _score, True
    if m == "brier":
        def _score(est, X, y): return -brier_score_loss(y, est.predict_proba(X)[:, 1])
        return _score, True
    if m == "accuracy":
        def _score(est, X, y): return accuracy_score(y, est.predict(X))
        return _score, False
    if m == "f1":
        def _score(est, X, y): return f1_score(y, est.predict(X), zero_division=0)
        return _score, False
    raise SystemExit(f"[ERR] Unsupported --metric '{metric}'. Use: roc_auc, log_loss, brier, accuracy, f1.")


# ---------- grouping ----------
def simple_group_name(feat: str) -> str:
    f = feat
    if f == "ticker":
        return "ticker"
    if f.startswith("m30_"):
        return "m30"
    if "bb_" in f:
        return "bollinger"
    if "macd" in f:
        return "macd"
    if "stoch" in f:
        return "stoch"
    if "rsi" in f:
        return "rsi"
    if "atr" in f:
        return "atr"
    if "adx" in f:
        return "adx"
    if "ema" in f or "sma" in f:
        return "moving_avg"
    if "_RATIO_" in f:
        return "ratios"
    return "other"


def group_importances(df: pd.DataFrame, mode: str) -> pd.DataFrame:
    if mode == "none":
        return df
    if mode == "simple":
        g = df.copy()
        g["group"] = g["feature"].map(simple_group_name)
        agg = g.groupby("group", as_index=False).agg(
            importance_mean=("importance_mean", "sum"),
            importance_std=("importance_std", lambda s: float(np.sqrt(np.sum(np.asarray(s) ** 2))))
        )
        # same convenience columns for groups
        agg["lb95"] = agg["importance_mean"] - 1.96 * agg["importance_std"]
        pos = agg["importance_mean"].clip(lower=0)
        tot = float(pos.sum())
        agg["importance_pct_of_pos"] = np.where(tot > 0, 100.0 * pos / tot, 0.0)
        return agg.sort_values("importance_mean", ascending=False).reset_index(drop=True)
    raise SystemExit(f"[ERR] Unsupported --group '{mode}'. Use: none, simple.")


# ---------- main ----------
def main():
    ap = argparse.ArgumentParser(description="Permutation importance on calibrated classifier (TEST split).")
    ap.add_argument("--test", type=str, default=None, help="Path to test.csv (default: data_final_training/test.csv)")
    ap.add_argument("--metric", type=str, default="roc_auc", choices=["roc_auc", "log_loss", "brier", "accuracy", "f1"])
    ap.add_argument("--n_repeats", type=int, default=10)
    ap.add_argument("--random_state", type=int, default=42)
    ap.add_argument("--top_k", type=int, default=25)
    ap.add_argument("--plot", action="store_true")
    ap.add_argument("--dpi", type=int, default=120)
    ap.add_argument("--group", type=str, default="none", choices=["none", "simple"],
                    help="Aggregate importances by groups (default: none).")
    args = ap.parse_args()

    models_dir = P.ROOT / "models"
    models_dir.mkdir(parents=True, exist_ok=True)

    # ---- load bundle ----
    bundle_path = _latest_model()
    if not bundle_path:
        raise SystemExit("[ERR] No models/classifier_*.pkl found.")
    bundle = joblib.load(bundle_path)
    pre = bundle["pre"]
    model = bundle["model"]
    saved_masked_names = list(bundle.get("feature_names", []))
    pre_full_names = bundle.get("pre_full_names", None)
    masked_idx = bundle.get("masked_idx", None)

    # ---- load TEST ----
    test_path = Path(args.test) if args.test else (P.ROOT / "data_final_training" / "test.csv")
    df_test = load_test(test_path)

    if "ret_trade" not in df_test.columns:
        raise SystemExit("[ERR] 'ret_trade' missing from test.csv.")
    y_true = (pd.to_numeric(df_test["ret_trade"], errors="coerce") > 0.0).astype(int).values

    # If TEST has a single class, switch to log_loss (AUC would fail)
    if len(np.unique(y_true)) < 2 and args.metric == "roc_auc":
        print("[WARN] TEST has a single class — switching metric to log_loss for permutation importance.")
        args.metric = "log_loss"

    # features (mirror s70 drop)
    DROP_ALWAYS = {"ret_trade", "pnl_eur", "entry_px", "exit_px", "entry_dt", "exit_dt", "trade_id", "num_fills", "legs"}
    CAT_KEEP = ["ticker"]
    num_cols = [c for c in df_test.select_dtypes(include=[np.number]).columns if c not in DROP_ALWAYS]
    cat_cols = [c for c in CAT_KEEP if c in df_test.columns and c not in DROP_ALWAYS]
    feat_cols = num_cols + cat_cols
    X_raw = df_test[feat_cols].copy()
    for c in cat_cols:
        X_raw[c] = X_raw[c].astype("string").fillna("__NA__")

    # ---- reconstruct indices for transformed space ----
    try:
        pre_names_all = pre.get_feature_names_out().tolist()
    except Exception:
        raise SystemExit("[ERR] pre.get_feature_names_out() not available (need sklearn >=1.0).")

    masked_names = None
    if masked_idx is not None and pre_full_names is not None:
        if len(pre_full_names) == len(pre_names_all) and all(a == b for a, b in zip(pre_full_names, pre_names_all)):
            masked_idx = np.asarray(masked_idx, dtype=int)
            masked_names = [pre_names_all[i] for i in masked_idx]
        else:
            print("[WARN] pre_full_names differ from current pre.get_feature_names_out(); remapping by names.")
            masked_idx = None

    if masked_idx is None:
        pre_idx = {n: i for i, n in enumerate(pre_names_all)}
        idxs, missing = [], []
        for n in saved_masked_names:
            if n in pre_idx:
                idxs.append(pre_idx[n])
            elif f"num__{n}" in pre_idx:
                idxs.append(pre_idx[f"num__{n}"])
            elif n == "ticker":
                hits = [i for i, nm in enumerate(pre_names_all) if nm.startswith("cat__ticker_")]
                if hits:
                    idxs.extend(hits)
                else:
                    missing.append(n)
            else:
                missing.append(n)
        if missing:
            prev = ", ".join(missing[:10])
            raise SystemExit(f"[ERR] Could not map some saved features to pre names: {prev} ...")
        masked_idx = np.asarray(idxs, dtype=int)
        masked_names = [pre_names_all[i] for i in masked_idx]

    # ---- run permutation importance ON RAW FEATURES ----
    raw_feature_names = list(X_raw.columns)
    scorer, needs_proba = make_scorer(args.metric)
    est = WrappedEstimator(pre=pre, model=model, masked_idx=masked_idx,
                           masked_names=masked_names, needs_proba=needs_proba)

    print(f"[s70f] Running permutation importance on TEST ({args.metric}) …")
    print(f"[s70f] PI over RAW features: n_raw={len(raw_feature_names)} | transformed(masked)={len(masked_idx)}")

    result = permutation_importance(
        est, X_raw, y_true,
        scoring=scorer,
        n_repeats=args.n_repeats,
        random_state=args.random_state,
        n_jobs=-1
    )

    # Build per-RAW-feature importances
    imp = pd.DataFrame({
        "feature": raw_feature_names,
        "importance_mean": result.importances_mean,
        "importance_std": result.importances_std,
    })

    # Convenience columns
    imp["lb95"] = imp["importance_mean"] - 1.96 * imp["importance_std"]
    with np.errstate(divide="ignore", invalid="ignore"):
        imp["zscore"] = np.where(imp["importance_std"] > 0,
                                 imp["importance_mean"] / imp["importance_std"],
                                 np.nan)
    pos = imp["importance_mean"].clip(lower=0)
    total_pos = float(pos.sum())
    imp["importance_pct_of_pos"] = np.where(total_pos > 0, 100.0 * pos / total_pos, 0.0)

    imp = imp.sort_values("importance_mean", ascending=False).reset_index(drop=True)

    ts = _ts()
    out_csv = models_dir / f"permutation_importance_{ts}.csv"
    imp.to_csv(out_csv, index=False)
    print(f"[OK] Permutation importance → {out_csv}")

    # Optional grouped importances
    to_show = imp
    if args.group != "none":
        imp_grouped = group_importances(imp, args.group)
        out_csv_g = models_dir / f"permutation_importance_{args.group}_{ts}.csv"
        imp_grouped.to_csv(out_csv_g, index=False)
        print(f"[OK] Grouped ({args.group}) → {out_csv_g}")
        to_show = imp_grouped

    # Print top-K
    print("\nTop features/groups:")
    print(to_show.head(args.top_k).to_string(index=False))

    # Plot
    if args.plot:
        try:
            import matplotlib.pyplot as plt
            top = to_show.head(args.top_k)
            y = np.arange(len(top))[::-1]
            plt.figure(figsize=(10, max(4, 0.35 * len(top))))
            plt.barh(y, top["importance_mean"])
            if "importance_std" in top.columns:
                plt.errorbar(top["importance_mean"], y, xerr=top["importance_std"], fmt="none")
            plt.yticks(y, top[top.columns[0]])
            plt.xlabel(f"Permutation importance ({args.metric})")
            title = "Top " + ("groups" if args.group != "none" else "features")
            plt.title(title)
            plt.tight_layout()
            out_png = models_dir / f"permutation_importance_{'grouped_' if args.group!='none' else ''}{ts}.png"
            plt.savefig(out_png, dpi=args.dpi)
            plt.close()
            print(f"[OK] Plot → {out_png}")
        except Exception as e:
            print(f"[WARN] Could not plot: {e}")


if __name__ == "__main__":
    main()