#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
s72_reliability_audit_classifier.py — Reliability & per-slice eval for the *classifier*.

Reads the latest classifier outputs in models/:
  - classifier_test_predictions_*.csv   (must contain: y_true, y_prob; optional: y_pred, ticker, SPY_vermeulen_color, entry_dt)
  - classifier_metrics_*.json           (optional; used for default threshold)

Writes to models/:
  - calibration_deciles.csv             (mean_pred vs mean_true by prob decile)
  - threshold_sweep.csv                 (acc, prec, rec, f1, roc_auc, brier, log_loss for thresholds 0.1..0.9)
  - metrics_per_ticker.csv              (if ticker is present)
  - metrics_per_regime.csv              (if SPY_vermeulen_color present)
  - backtest_daily_topK.csv             (toy daily top-K selection if dates present)
  - feature_importances_latest.csv      (if model exposes feature_importances_)
"""

from __future__ import annotations
from pathlib import Path
import json
import numpy as np
import pandas as pd
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score, roc_auc_score,
    brier_score_loss, log_loss, confusion_matrix
)
import joblib
import re

ROOT   = Path(__file__).resolve().parents[1]
MODELS = ROOT / "models"

def _latest(glob_pat: str) -> Path | None:
    c = sorted(MODELS.glob(glob_pat))
    return c[-1] if c else None

def _safe_float(x, default=np.nan):
    try:
        return float(x)
    except Exception:
        return float(default)

def _metrics_bin(y_true, y_prob, thr: float):
    y_pred = (y_prob >= thr).astype(int)
    out = {
        "threshold": thr,
        "accuracy": accuracy_score(y_true, y_pred),
        "precision": precision_score(y_true, y_pred, zero_division=0),
        "recall": recall_score(y_true, y_pred, zero_division=0),
        "f1": f1_score(y_true, y_pred, zero_division=0),
    }
    # prob-based
    try:
        out["roc_auc"] = roc_auc_score(y_true, y_prob)
    except Exception:
        out["roc_auc"] = np.nan
    try:
        out["brier"] = brier_score_loss(y_true, y_prob)
    except Exception:
        out["brier"] = np.nan
    try:
        out["log_loss"] = log_loss(y_true, y_prob, labels=[0,1])
    except Exception:
        out["log_loss"] = np.nan

    tn, fp, fn, tp = confusion_matrix(y_true, y_pred).ravel()
    out["tn"], out["fp"], out["fn"], out["tp"] = int(tn), int(fp), int(fn), int(tp)
    return out

def _load_threshold_from_metrics() -> float:
    mpath = _latest("classifier_metrics_*.json")
    if not mpath:
        return 0.5
    with open(mpath, "r") as f:
        m = json.load(f)
    # Prefer decision_threshold (written by s70); fallback to 0.5
    return float(m.get("decision_threshold", 0.5))

def _unwrap_importance_from_latest_model():
    mpath = _latest("classifier_*.pkl")
    if not mpath:
        return None, "No classifier_*.pkl found."
    try:
        bundle = joblib.load(mpath)
        model = bundle.get("model", None)
        feat_names = bundle.get("feature_names", None)

        base = model
        # sklearn ≥1.6 uses estimator_; older versions used base_estimator_
        for attr in ("estimator_", "base_estimator_"):
            if hasattr(base, attr):
                base = getattr(base, attr)
                break

        if hasattr(base, "feature_importances_") and feat_names is not None:
            imp = pd.DataFrame({"feature": feat_names, "importance": base.feature_importances_}) \
                    .sort_values("importance", ascending=False)
            outp = MODELS / "feature_importances_latest.csv"
            imp.to_csv(outp, index=False)
            return outp, None
        return None, "Underlying estimator has no feature_importances_."
    except Exception as e:
        return None, f"Failed to load/unwrap model: {e}"

def main():
    preds_path = _latest("classifier_test_predictions_*.csv")
    if preds_path is None:
        raise SystemExit("[ERR] No classifier_test_predictions_*.csv in models/")

    print(f"[s72] Using predictions: {preds_path.name}")
    df = pd.read_csv(preds_path)

    need = {"y_true", "y_prob"}
    if not need.issubset(df.columns):
        raise SystemExit(f"[ERR] Predictions missing columns {need}. Got: {list(df.columns)[:12]} ...")

    # Default threshold (0.5 unless later you store tuned one in metrics json)
    thr = _load_threshold_from_metrics()

    # -------- Overall ----------
    y_true = pd.to_numeric(df["y_true"], errors="coerce").fillna(0).astype(int).values
    y_prob = pd.to_numeric(df["y_prob"], errors="coerce").fillna(0.5).clip(0,1).values

    overall = _metrics_bin(y_true, y_prob, thr)
    print("\n== Overall (Test) @ threshold {:.2f} ==".format(thr))
    print({k: (round(v,6) if isinstance(v, float) else v) for k,v in overall.items()
           if k not in ("tn","fp","fn","tp")})
    print("Confusion:", {k: overall[k] for k in ("tn","fp","fn","tp")})

    # -------- Calibration deciles ----------
    d = pd.DataFrame({"y_true": y_true, "y_prob": y_prob})
    d["decile"] = pd.qcut(d["y_prob"].rank(method="first"), 10, labels=False)
    cal = (d.groupby("decile")
             .agg(mean_pred=("y_prob","mean"),
                  mean_true=("y_true","mean"),
                  count=("y_true","size"))
             .reset_index())
    cal_path = MODELS / "calibration_deciles.csv"
    cal.to_csv(cal_path, index=False)
    print(f"\n== Calibration ==\nSaved deciles → {cal_path.name}")

    # -------- Threshold sweep ----------
    rows = []
    for t in np.round(np.linspace(0.10, 0.90, 17), 2):
        rows.append(_metrics_bin(y_true, y_prob, t))
    sweep = pd.DataFrame(rows)
    sweep_path = MODELS / "threshold_sweep.csv"
    sweep.to_csv(sweep_path, index=False)
    best_f1 = sweep.sort_values("f1", ascending=False).head(1).iloc[0].to_dict()
    print("\n== Threshold sweep ==")
    print(f"Saved → {sweep_path.name}")
    print(f"Best F1 at threshold={best_f1['threshold']:.2f}: F1={best_f1['f1']:.4f}, "
          f"acc={best_f1['accuracy']:.4f}, prec={best_f1['precision']:.4f}, rec={best_f1['recall']:.4f}")

    # -------- Per-slice (ticker / regime) ----------
    if "ticker" in df.columns:
        per_t = []
        for tkr, g in df.groupby("ticker"):
            yt = pd.to_numeric(g["y_true"], errors="coerce").fillna(0).astype(int).values
            yp = pd.to_numeric(g["y_prob"], errors="coerce").fillna(0.5).clip(0,1).values
            m  = _metrics_bin(yt, yp, thr)
            m.update({"ticker": tkr, "n": len(g)})
            per_t.append(m)
        per_t = pd.DataFrame(per_t).sort_values(["roc_auc","f1","accuracy"], ascending=False)
        per_t.to_csv(MODELS / "metrics_per_ticker.csv", index=False)
        print("\n== Per-ticker ==\nSaved → metrics_per_ticker.csv")

    if "SPY_vermeulen_color" in df.columns:
        per_r = []
        for rg, g in df.groupby("SPY_vermeulen_color"):
            yt = pd.to_numeric(g["y_true"], errors="coerce").fillna(0).astype(int).values
            yp = pd.to_numeric(g["y_prob"], errors="coerce").fillna(0.5).clip(0,1).values
            m  = _metrics_bin(yt, yp, thr)
            m.update({"SPY_vermeulen_color": rg, "n": len(g)})
            per_r.append(m)
        per_r = pd.DataFrame(per_r).sort_values(["roc_auc","f1","accuracy"], ascending=False)
        per_r.to_csv(MODELS / "metrics_per_regime.csv", index=False)
        print("== Per-regime ==\nSaved → metrics_per_regime.csv")

    # -------- Toy daily top-K backtest ----------
    date_col = next((c for c in ["entry_dt","date","dt","timestamp"] if c in df.columns), None)
    if date_col:
        tmp = df.copy()
        tmp[date_col] = pd.to_datetime(tmp[date_col], utc=True, errors="coerce")
        tmp["day"] = tmp[date_col].dt.floor("D")
        K = 3
        topk = (tmp.sort_values(["day","y_prob"], ascending=[True, False])
                   .groupby("day").head(K)
                   .groupby("day")["y_true"].sum())
        base = tmp.groupby("day")["y_true"].mean()
        out = pd.DataFrame({"topK_sum": topk, "all_mean": base}).fillna(0.0)
        out["edge"] = out["topK_sum"] - out["all_mean"]
        out.to_csv(MODELS / "backtest_daily_topK.csv", index=False)
        print("\n== Backtest (toy) ==\nSaved → backtest_daily_topK.csv")

    # -------- Feature importances (if available) ----------
    imp_path, imp_err = _unwrap_importance_from_latest_model()
    if imp_path:
        print(f"\n== Importances ==\nSaved → {imp_path.name}")
    else:
        print(f"\n== Importances ==\n{imp_err}")

    print("\n[OK] Classification reliability audit complete.")

if __name__ == "__main__":
    main()