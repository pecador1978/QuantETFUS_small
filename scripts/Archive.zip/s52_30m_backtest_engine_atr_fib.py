#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
s52_30m_backtest_engine_atr_fib.py — Daily ATR entries + Fibonacci exits (clone-friendly)

Entries (institutional style, daily -> intraday execution)
- Compute daily ATR(N) and prior day's close.
- Long entry level for next session: entry_level = prior_close - k_entry * ATR.
- Execute when a 30m bar's low <= entry_level.
  Optional confirmation: bar closes back above the level (--confirm_close_back_above).

Stops
- Initial stop = entry - atr_stop_mult * ATR (daily ATR of prior day).
- After T1 filled: raise stop to breakeven (entry price).

Targets (profits) — daily Fibonacci extensions (intraday execution by default)
- Find a recent daily swing Low->High prior to entry (configurable lookbacks).
- T1 = High + 0.618 * (High - Low)
- T2 = High + 1.000 * (High - Low)
- Optional: exit on daily close instead of intraday touch (--fib_exit_on_close)

Clone-friendly detection
- TARGET_BUCKET chosen from: ENV -> common.settings -> autodetect US dir -> EU default.
- Session (MARKET_TZ/OPEN/CLOSE) chosen from: ENV -> common.settings -> auto by repo/bucket -> EU default.
"""

from __future__ import annotations

import os
import sys
import argparse
import warnings
from datetime import datetime, timezone, time as dt_time, timedelta
from pathlib import Path
import pandas as pd
import numpy as np

# ---------- bootstrap project import path ----------
SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

# ---------- project-aware paths ----------
from common.paths import P  # type: ignore

# ---------- clone-friendly detection ----------
def _resolve_bucket() -> str:
    env_b = os.environ.get("TARGET_BUCKET", "").strip()
    if env_b:
        return env_b
    try:
        from common.settings import TARGET_BUCKET as SBUCKET  # type: ignore
        if SBUCKET:
            return str(SBUCKET)
    except Exception:
        pass
    if (P.DATA_RAW / "targeted_ETFs_US" / "30min").exists() or (P.DATA_RAW / "targeted_ETFs_US" / "daily").exists():
        return "targeted_ETFs_US"
    return "targeted_ETFs"

def _resolve_session(bucket: str) -> tuple[str, str, str]:
    tz = os.environ.get("MARKET_TZ", "").strip()
    op = os.environ.get("MARKET_OPEN", "").strip()
    cl = os.environ.get("MARKET_CLOSE", "").strip()
    if tz and op and cl:
        return tz, op, cl
    try:
        from common.settings import MARKET_TZ as STZ, MARKET_OPEN as SOPEN, MARKET_CLOSE as SCLOSE  # type: ignore
        if all([STZ, SOPEN, SCLOSE]):
            return str(STZ), str(SOPEN), str(SCLOSE)
    except Exception:
        pass
    repo_us = PROJECT_ROOT.name.endswith("US") or bucket == "targeted_ETFs_US"
    if repo_us:
        return "Europe/London", "08:00", "16:30"
    return "Europe/Madrid", "09:00", "17:30"

TARGET_BUCKET = _resolve_bucket()
MARKET_TZ, MARKET_OPEN, MARKET_CLOSE = _resolve_session(TARGET_BUCKET)

ROOT = P.ROOT
IN30 = P.DATA_RAW / TARGET_BUCKET / "30min"
IN1D = P.DATA_RAW / TARGET_BUCKET / "daily"
# IMPORTANT: write into the same folder as s50/s51 so s55 can find results
OUT  = ROOT / "backtest_results_30m"
OUT.mkdir(parents=True, exist_ok=True)

print(f"[s52] TARGET_BUCKET={TARGET_BUCKET} | MARKET_TZ={MARKET_TZ} | "
      f"MARKET_OPEN={MARKET_OPEN} | MARKET_CLOSE={MARKET_CLOSE}")
print(f"[s52] IN30={IN30}")
print(f"[s52] IN1D={IN1D}")

# ---------- helpers ----------
def _filter_session_local(df_utc: pd.DataFrame) -> pd.DataFrame:
    """Keep 30m bars whose local time (MARKET_TZ) is within [MARKET_OPEN, MARKET_CLOSE]."""
    if df_utc.empty:
        return df_utc
    df = df_utc.copy()
    local = df["datetime"].dt.tz_convert(MARKET_TZ)
    t = local.dt.time
    hh_o, mm_o = map(int, str(MARKET_OPEN).split(":"))
    hh_c, mm_c = map(int, str(MARKET_CLOSE).split(":"))
    mask = (t >= dt_time(hh_o, mm_o)) & (t <= dt_time(hh_c, mm_c))
    return df.loc[mask].reset_index(drop=True)

def _load_30min_any(ticker: str) -> pd.DataFrame:
    f_raw = IN30 / f"{ticker}_30min_raw.csv"
    f_alt = IN30 / f"{ticker}_30min.csv"
    f = f_raw if f_raw.exists() else f_alt
    if not f.exists():
        raise FileNotFoundError(f"30m file not found for {ticker} ({f_raw} / {f_alt})")
    df = pd.read_csv(f)
    df.columns = [c.strip().lower().replace(" ", "") for c in df.columns]
    dtcol = next((c for c in df.columns if "date" in c or "time" in c), None)
    if not dtcol:
        raise ValueError(f"No datetime column in {f}")
    df["datetime"] = pd.to_datetime(df[dtcol], utc=True, errors="coerce")
    for c in ("open","high","low","close"):
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")
    df = _filter_session_local(df)
    df["date"] = df["datetime"].dt.tz_convert(MARKET_TZ).dt.date
    return df.sort_values("datetime").reset_index(drop=True)

def _load_daily_any(ticker: str) -> pd.DataFrame:
    f_raw = IN1D / f"{ticker}_daily_raw.csv"
    f_alt = IN1D / f"{ticker}_daily.csv"
    f = f_raw if f_raw.exists() else f_alt
    if not f.exists():
        raise FileNotFoundError(f"Daily file not found for {ticker} ({f_raw} / {f_alt})")
    dfd = pd.read_csv(f)
    dfd.columns = [c.strip().lower().replace(" ", "") for c in dfd.columns]
    date_col = "date" if "date" in dfd.columns else "datetime"
    dfd["datetime"] = pd.to_datetime(dfd[date_col], utc=True, errors="coerce").dt.tz_convert(MARKET_TZ).dt.tz_localize(None)
    dfd["date"] = dfd["datetime"].dt.date
    for c in ("open","high","low","close","volume"):
        if c in dfd.columns:
            dfd[c] = pd.to_numeric(dfd[c], errors="coerce")
    return dfd.sort_values("datetime").reset_index(drop=True)

def _atr_manual(dfd: pd.DataFrame, n: int = 14) -> pd.Series:
    d = dfd.copy()
    d["H-L"]  = d["high"] - d["low"]
    d["H-PC"] = (d["high"] - d["close"].shift()).abs()
    d["L-PC"] = (d["low"] - d["close"].shift()).abs()
    d["TR"]   = d[["H-L","H-PC","L-PC"]].max(axis=1)
    return d["TR"].rolling(window=n).mean()

def _find_swing_low_high(dfd: pd.DataFrame, asof_date, low_lookback=50, high_lookback=20):
    """
    Find a recent swing Low->High entirely BEFORE asof_date.
    - Low = rolling min over low_lookback ending asof-1
    - High = rolling max over high_lookback ending asof-1
    If High occurs after Low (chronologically), use that pair; otherwise widen once.
    """
    dd = dfd[dfd["date"] < asof_date].copy()
    if dd.empty or len(dd) < max(low_lookback, high_lookback):
        return np.nan, np.nan

    dd = dd.set_index("datetime")
    low_window  = dd.iloc[-low_lookback:]
    high_window = dd.iloc[-high_lookback:]

    low_val  = low_window["low"].min()
    low_dt   = low_window["low"].idxmin()
    high_val = high_window["high"].max()
    high_dt  = high_window["high"].idxmax()

    if low_dt < high_dt:
        return float(low_val), float(high_val)

    # widen once
    dd2 = dfd[dfd["date"] < asof_date].copy().set_index("datetime")
    low_val2  = dd2.iloc[-(low_lookback*2):]["low"].min()
    low_dt2   = dd2.iloc[-(low_lookback*2):]["low"].idxmin()
    high_val2 = dd2.iloc[-(high_lookback*2):]["high"].max()
    high_dt2  = dd2.iloc[-(high_lookback*2):]["high"].idxmax()
    if low_dt2 < high_dt2:
        return float(low_val2), float(high_val2)

    return np.nan, np.nan

def apply_costs(px: float, side: str, slip_bps: float) -> float:
    if pd.isna(px) or px <= 0:
        return px
    adj = (slip_bps / 10000.0)
    return px * (1.0 + adj) if side == "buy" else px * (1.0 - adj)

def _apply_window_ts(df: pd.DataFrame, ts_col: str, start: str | None, end: str | None) -> pd.DataFrame:
    if start:
        df = df[df[ts_col] >= pd.to_datetime(start, utc=True, errors="coerce")]
    if end:
        df = df[df[ts_col] <= pd.to_datetime(end,   utc=True, errors="coerce")]
    return df

def _apply_window_date(df: pd.DataFrame, date_col: str, start: str | None, end: str | None) -> pd.DataFrame:
    if start:
        df = df[df[date_col] >= pd.to_datetime(start).date()]
    if end:
        df = df[df[date_col] <= pd.to_datetime(end).date()]
    return df

# ---------- core backtest ----------
def backtest_ticker(ticker: str, params: dict) -> pd.DataFrame:
    verbose = bool(params.get("verbose", False))
    if not verbose:
        warnings.filterwarnings("ignore", category=FutureWarning)

    df30 = _load_30min_any(ticker)
    dfd  = _load_daily_any(ticker)

    start = params.get("start_date"); end = params.get("end_date")
    if start or end:
        df30 = _apply_window_ts(df30, "datetime", start, end)
        dfd  = _apply_window_date(dfd, "date", start, end)
    if df30.empty or dfd.empty:
        return pd.DataFrame(columns=[
            "ticker","strategy","entry_dt","exit_dt","entry_px","exit_px",
            "qty","ret_pct","fee_eur","leg","target_rule","target_px",
            "stop_init_px","swing_low","swing_high","atr_used"
        ])

    # --- daily metrics ---
    atr_len = int(params.get("atr_len", 14))
    dfd["ATR"] = _atr_manual(dfd, atr_len)

    # Optional minimal daily trend sanity (can disable)
    if not bool(params.get("suppress_s50_filters", False)):
        dfd["ema20"] = dfd["close"].ewm(span=20, adjust=False).mean()
        dfd["ema44"] = dfd["close"].ewm(span=44, adjust=False).mean()
        dfd["daily_ok"] = (dfd["close"] > dfd["ema20"]) & (dfd["close"] > dfd["ema44"])
    else:
        dfd["daily_ok"] = True

    # Precompute prior close & ATR by calendar date
    daily_ref = dfd[["date","close","ATR","daily_ok","high","low"]].copy()
    daily_ref["prior_close"] = daily_ref["close"].shift(1)
    daily_ref["prior_ATR"]   = daily_ref["ATR"].shift(1)

    # intraday merge
    df30 = df30.merge(daily_ref[["date","prior_close","prior_ATR","daily_ok"]],
                      on="date", how="left")

    # compute entry level for each trading day (institutional)
    k_entry = float(params.get("k_entry", 2.0))  # 2.5 mirrors the trader’s quote
    df30["entry_level"] = df30["prior_close"] - k_entry * df30["prior_ATR"]

    confirm_close = bool(params.get("confirm_close_back_above", False))
    df30["entry_ok"] = False

    # choose first 30m bar per date that qualifies, then one entry per day
    entries = []
    for d, g in df30.groupby("date", sort=True):
        g = g.sort_values("datetime")
        if g["daily_ok"].iloc[0] is not True:
            continue
        pc = g["prior_close"].iloc[0]; pa = g["prior_ATR"].iloc[0]; lvl = g["entry_level"].iloc[0]
        if pd.isna(pc) or pd.isna(pa) or pd.isna(lvl):
            continue
        hit_idx = None
        for i, row in g.iterrows():
            touched = (row["low"] <= lvl)
            if confirm_close:
                touched = touched and (row["close"] >= lvl)
            if touched:
                hit_idx = i
                break
        if hit_idx is not None:
            entries.append(hit_idx)

    df30.loc[entries, "entry_ok"] = True

    # --- backtest loop with fib targets ---
    fib_exit_on_close = bool(params.get("fib_exit_on_close", False))
    low_lb  = int(params.get("swing_low_lookback", 50))
    high_lb = int(params.get("swing_high_lookback", 20))
    fib_w1 = float(params.get("fib_t1_weight", 0.50))
    fib_w2 = float(params.get("fib_t2_weight", 0.50))
    wsum = fib_w1 + fib_w2
    fib_w1, fib_w2 = (fib_w1/wsum, fib_w2/wsum) if wsum > 0 else (1.0, 0.0)

    atr_stop_mult = float(params.get("atr_stop_mult", 1.0))
    fees_fixed = float(params.get("fees_fixed", 3.0))
    slip_bps   = float(params.get("slip_bps", 0.0))
    cooldown_days = int(params.get("cooldown_days", 0))

    trades = []
    current = None
    next_allowed_date = None

    for _, row in df30.iterrows():
        d = row["date"]

        # ---- OPEN (one entry per day, ATR level touch) ----
        if current is None and bool(row["entry_ok"]) and (next_allowed_date is None or d >= next_allowed_date):
            level = float(row["entry_level"])
            # fill at level unless we gap through; then use bar open
            entry_raw = float(row["open"]) if row["open"] <= level else level
            if confirm_close and row["close"] < level:
                # need a close back above the level if confirmation is on
                continue
            entry_adj = apply_costs(entry_raw, "buy", slip_bps)

            pa = float(row["prior_ATR"]) if not pd.isna(row["prior_ATR"]) else np.nan
            if pd.isna(pa) or pa <= 0:
                continue

            # DAILY swing for Fibonacci targets
            swing_low, swing_high = _find_swing_low_high(dfd, d, low_lb, high_lb)
            if np.isnan(swing_low) or np.isnan(swing_high) or swing_high <= swing_low:
                continue

            move = (swing_high - swing_low)
            t1 = swing_high + 0.618 * move
            t2 = swing_high + 1.000 * move

            stop_raw = entry_raw - atr_stop_mult * pa

            current = {
                "EntryTime": row["datetime"],
                "EntryPxRaw": entry_raw,
                "EntryPxAdj": entry_adj,
                "StopRaw": stop_raw,
                "T1": float(t1),
                "T2": float(t2),
                "SwingLow": float(swing_low),
                "SwingHigh": float(swing_high),
                "ATR_used": float(pa),
                "T1_done": False,
                "T2_done": False,
                "T1_date": None,
                "remaining_qty": 1.0,
                "entry_fee_pending": True
            }
            continue

        # ---- MANAGE OPEN POSITION ----
        if current is not None:
            high = float(row["high"])
            low  = float(row["low"])
            epx_raw = float(current["EntryPxRaw"])
            epx_adj = float(current["EntryPxAdj"])

            # --- T1 (Fib 0.618 extension) ---
            if not current["T1_done"]:
                hit = (high >= current["T1"])
                if fib_exit_on_close:
                    day_close = dfd.loc[dfd["date"] == row["date"], "close"]
                    hit = (not day_close.empty) and (float(day_close.iloc[0]) >= current["T1"])
                if hit:
                    qty_leg = min(fib_w1, current["remaining_qty"])
                    if qty_leg > 0:
                        exit_adj = apply_costs(current["T1"], "sell", slip_bps)
                        ret = (exit_adj / epx_adj) - 1.0
                        fee_eur = fees_fixed * qty_leg
                        if current["entry_fee_pending"]:
                            fee_eur += fees_fixed * qty_leg
                            current["entry_fee_pending"] = False
                        trades.append({
                            "ticker": ticker,
                            "strategy": "s52",
                            "entry_dt": current["EntryTime"],
                            "exit_dt": row["datetime"],
                            "entry_px": epx_adj,
                            "exit_px": exit_adj,
                            "qty": qty_leg,
                            "ret_pct": ret,
                            "fee_eur": fee_eur,
                            "leg": "T1",
                            "target_rule": "fib_0.618",
                            "target_px": current["T1"],
                            "stop_init_px": current["StopRaw"],
                            "swing_low": current["SwingLow"],
                            "swing_high": current["SwingHigh"],
                            "atr_used": current["ATR_used"]
                        })
                        current["remaining_qty"] -= qty_leg
                    current["T1_done"] = True
                    current["T1_date"] = row["datetime"].date()
                    # raise stop to breakeven after T1
                    current["StopRaw"] = max(current["StopRaw"], epx_raw)
                    continue

            # --- T2 (Fib 1.000 extension) ---
            if current["T1_done"] and (not current["T2_done"]):
                hit = (high >= current["T2"])
                if fib_exit_on_close:
                    day_close = dfd.loc[dfd["date"] == row["date"], "close"]
                    hit = (not day_close.empty) and (float(day_close.iloc[0]) >= current["T2"])
                if hit:
                    qty_leg = current["remaining_qty"] if fib_w2 >= current["remaining_qty"] else fib_w2
                    if qty_leg > 0:
                        exit_adj = apply_costs(current["T2"], "sell", slip_bps)
                        ret = (exit_adj / epx_adj) - 1.0
                        fee_eur = fees_fixed * qty_leg
                        if current["entry_fee_pending"]:
                            fee_eur += fees_fixed * qty_leg
                            current["entry_fee_pending"] = False
                        trades.append({
                            "ticker": ticker,
                            "strategy": "s52",
                            "entry_dt": current["EntryTime"],
                            "exit_dt": row["datetime"],
                            "entry_px": epx_adj,
                            "exit_px": exit_adj,
                            "qty": qty_leg,
                            "ret_pct": ret,
                            "fee_eur": fee_eur,
                            "leg": "T2",
                            "target_rule": "fib_1.000",
                            "target_px": current["T2"],
                            "stop_init_px": current["StopRaw"],
                            "swing_low": current["SwingLow"],
                            "swing_high": current["SwingHigh"],
                            "atr_used": current["ATR_used"]
                        })
                    current = None
                    if cooldown_days > 0:
                        next_allowed_date = row["datetime"].date() + timedelta(days=cooldown_days)
                    continue

            # --- Protective stop ---
            stop_cand = current["StopRaw"]
            if low <= stop_cand:
                qty_leg = current["remaining_qty"]
                if qty_leg > 0:
                    exit_adj = apply_costs(stop_cand, "sell", slip_bps)
                    ret = (exit_adj / epx_adj) - 1.0
                    fee_eur = fees_fixed * qty_leg
                    if current["entry_fee_pending"]:
                        fee_eur += fees_fixed * qty_leg
                        current["entry_fee_pending"] = False
                    trades.append({
                        "ticker": ticker,
                        "strategy": "s52",
                        "entry_dt": current["EntryTime"],
                        "exit_dt": row["datetime"],
                        "entry_px": epx_adj,
                        "exit_px": exit_adj,
                        "qty": qty_leg,
                        "ret_pct": ret,
                        "fee_eur": fee_eur,
                        "leg": "StopExit",
                        "target_rule": "stop",
                        "target_px": stop_cand,
                        "stop_init_px": current["StopRaw"],
                        "swing_low": current["SwingLow"],
                        "swing_high": current["SwingHigh"],
                        "atr_used": current["ATR_used"]
                    })
                current = None
                if cooldown_days > 0:
                    next_allowed_date = row["datetime"].date() + timedelta(days=cooldown_days)
                continue

    return pd.DataFrame(trades)

# ---------- summaries ----------
def summarize_fills(trades: pd.DataFrame):
    if trades is None or trades.empty:
        agg = pd.DataFrame([{"tickers":0,"fills":0,"win_rate":0.0,"avg_ret":0.0,"median_ret":0.0,"avg_bars":0.0,"gross_ret":0.0}])
        by_tkr = pd.DataFrame(columns=["ticker","fills","mean","median"])
        return agg, by_tkr
    win = (trades["ret_pct"] > 0).mean()
    avg = trades["ret_pct"].mean()
    med = trades["ret_pct"].median()
    bars = max(0.0, (trades["exit_dt"] - trades["entry_dt"]).dt.total_seconds().mean() / (30*60))
    gross = (trades["ret_pct"] * trades["qty"]).sum()
    by_tkr = trades.groupby("ticker", as_index=False).apply(
        lambda g: pd.Series({
            "fills": len(g),
            "mean": (g["ret_pct"] * g["qty"]).sum() / max(g["qty"].sum(), 1e-12),
            "median": g["ret_pct"].median()
        }),
        include_groups=False
    ).reset_index(drop=True)
    agg = pd.DataFrame([{
        "tickers": trades["ticker"].nunique(),
        "fills": len(trades),
        "win_rate": win,
        "avg_ret": avg,
        "median_ret": med,
        "avg_bars": bars,
        "gross_ret": gross
    }])
    return agg, by_tkr

def summarize_trades_per_ticker(trades: pd.DataFrame, unit_capital: float) -> pd.DataFrame:
    if trades is None or trades.empty:
        return pd.DataFrame(columns=[
            "ticker","initial_capital","win_rate","total_return","num_trades","end_capital"
        ])
    tr = trades.copy()
    tr["trade_id"] = tr["ticker"].astype(str) + "|" + tr["entry_dt"].astype(str)
    trade_rows = tr.groupby(["ticker","trade_id"], as_index=False).apply(
        lambda g: pd.Series({
            "entry_dt": g["entry_dt"].iloc[0],
            "exit_dt": g["exit_dt"].max(),
            "ret_trade": (g["ret_pct"] * g["qty"]).sum()
                         - (g["fee_eur"].sum() / unit_capital if "fee_eur" in g else 0.0)
        }),
        include_groups=False
    ).reset_index(drop=True)
    out = []
    for tkr, g in trade_rows.sort_values("exit_dt").groupby("ticker"):
        cap = unit_capital
        wins = (g["ret_trade"] > 0).sum()
        for _, r in g.iterrows():
            cap *= (1.0 + r["ret_trade"])
        out.append({
            "ticker": tkr,
            "initial_capital": unit_capital,
            "win_rate": wins / max(len(g), 1),
            "total_return": (cap / unit_capital) - 1.0,
            "num_trades": len(g),
            "end_capital": cap
        })
    return pd.DataFrame(out)

def equity_curve(trades: pd.DataFrame, unit_capital: float) -> pd.DataFrame:
    if trades is None or trades.empty:
        return pd.DataFrame(columns=["date","equity"])
    tr = trades.sort_values("exit_dt").copy()
    fees = tr["fee_eur"] if "fee_eur" in tr.columns else 0.0
    tr["pnl"] = (tr["ret_pct"] * tr["qty"] * unit_capital) - fees
    tr["equity"] = unit_capital + tr["pnl"].cumsum()
    return tr[["exit_dt","equity"]].rename(columns={"exit_dt":"date"})

# ---------- main ----------
def main():
    ap = argparse.ArgumentParser()
    # Entry (daily ATR-based)
    ap.add_argument("--atr_len", type=int, default=14)
    ap.add_argument("--k_entry", type=float, default=2.5, help="ATR multiples for entry level (use 2.5 per trader quote)")
    ap.add_argument("--confirm_close_back_above", action="store_true", default=False,
                    help="Require 30m bar to CLOSE back above entry_level after wick-through")
    ap.add_argument("--suppress_s50_filters", action="store_true", default=False,
                    help="If set, skip daily EMA alignment checks (pure ATR entries)")
    # Stops
    ap.add_argument("--atr_stop_mult", type=float, default=1.0)
    # Fibonacci targets
    ap.add_argument("--swing_low_lookback", type=int, default=50)
    ap.add_argument("--swing_high_lookback", type=int, default=20)
    ap.add_argument("--fib_t1_weight", type=float, default=0.50)
    ap.add_argument("--fib_t2_weight", type=float, default=0.50)
    ap.add_argument("--fib_exit_on_close", action="store_true", default=False,
                    help="If set, require daily close >= target rather than intraday touch")
    # Costs/capital & misc
    ap.add_argument("--fees_fixed", type=float, default=3.0)
    ap.add_argument("--slip_bps", type=float, default=0.0)
    ap.add_argument("--unit_capital", type=float, default=10000.0)
    ap.add_argument("--cooldown_days", type=int, default=0)
    ap.add_argument("--start_date", type=str, default=None)
    ap.add_argument("--end_date", type=str, default=None)
    ap.add_argument("--verbose", action="store_true", default=False)
    args = ap.parse_args()

    params = dict(
        atr_len=args.atr_len, k_entry=args.k_entry,
        confirm_close_back_above=args.confirm_close_back_above,
        suppress_s50_filters=args.suppress_s50_filters,
        atr_stop_mult=args.atr_stop_mult,
        swing_low_lookback=args.swing_low_lookback,
        swing_high_lookback=args.swing_high_lookback,
        fib_t1_weight=args.fib_t1_weight, fib_t2_weight=args.fib_t2_weight,
        fib_exit_on_close=args.fib_exit_on_close,
        fees_fixed=args.fees_fixed, slip_bps=args.slip_bps,
        unit_capital=args.unit_capital, cooldown_days=args.cooldown_days,
        start_date=args.start_date, end_date=args.end_date,
        verbose=args.verbose
    )

    print(f"[s52] Scanning 30m inputs: {IN30}")
    files = sorted(list(IN30.glob("*_30min_raw.csv")) + list(IN30.glob("*_30min.csv")))
    print(f"[s52] Found {len(files)} file(s)")
    if not files:
        raise SystemExit(f"No 30m inputs in {IN30} — expected *_30min_raw.csv or *_30min.csv")

    all_trades = []
    for f in files:
        tkr = f.name.replace("_30min_raw.csv","").replace("_30min.csv","")
        try:
            tr = backtest_ticker(tkr, params)
            if tr is not None and not tr.empty:
                tr["ticker"] = tkr  # ensure ticker column
                all_trades.append(tr)
        except Exception as e:
            print(f"[WARN] {tkr}: {e}")

    if not all_trades:
        raise SystemExit("No trades generated.")

    trades = pd.concat(all_trades, ignore_index=True).sort_values("exit_dt").reset_index(drop=True)

    # summaries & outputs
    agg, by_tkr = summarize_fills(trades)
    curve = equity_curve(trades, unit_capital=args.unit_capital)
    cap_by_tkr = summarize_trades_per_ticker(trades, unit_capital=args.unit_capital)

    # --- outputs (prefixed in the shared OUT dir) ---
    prefix = "s52"
    ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M")

    trades.sort_values("exit_dt").to_csv(OUT / f"{prefix}_trades_{ts}.csv", index=False)
    curve.to_csv(OUT / f"{prefix}_equity_curve_{ts}.csv", index=False)
    agg.to_csv(OUT / f"{prefix}_summary_{ts}.csv", index=False)
    by_tkr.to_csv(OUT / f"{prefix}_summary_by_ticker_{ts}.csv", index=False)
    cap_by_tkr.to_csv(OUT / f"{prefix}_summary_capital_by_ticker_{ts}.csv", index=False)

    print(f"[OK] {prefix} Trades   → {OUT}/{prefix}_trades_{ts}.csv")
    print(f"[OK] {prefix} Curve    → {OUT}/{prefix}_equity_curve_{ts}.csv")
    print(f"[OK] {prefix} Summary  → {OUT}/{prefix}_summary_{ts}.csv")
    print(f"[OK] {prefix} ByTicker → {OUT}/{prefix}_summary_by_ticker_{ts}.csv")
    print(f"[OK] {prefix} Cap/Tkr  → {OUT}/{prefix}_summary_capital_by_ticker_{ts}.csv")

if __name__ == "__main__":
    main()