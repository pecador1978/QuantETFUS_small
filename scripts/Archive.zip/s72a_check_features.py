#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
s72a_check_features.py
Safety check for trained feature list (forbidden columns / fuzzy leakage tokens).

What’s new vs your previous version
-----------------------------------
- Adds REGEX-based fuzzy checks with token-ish boundaries (fewer false positives).
- Expanded default leakage patterns (exit/realized/target/shift/lead/next/etc.).
- Optional config file support (param_results/s70_config.json or --config):
    {
      "feature_guard": {
        "forbidden_exact":   ["my_label"],
        "forbidden_regex":   ["\\bmy_future_feature\\b"],
        "allowlist":         ["some_feature_to_allow"],
        "max_print":         40,             # override how many to print
        "treat_regex_as_error": true         # default True
      }
    }
- Allowlist to suppress known-safe names.
- Writes a JSON report alongside console output:
  <ROOT>/models/feature_guard_report_YYYYMMDD_HHMM.json
- Exit codes:
    0 = OK
    1 = forbidden found (exact or regex) and not allowlisted
    2 = feature_names file not found / other IO issues

Usage
-----
  python scripts/s72a_check_features.py
  python scripts/s72a_check_features.py --feats /path/to/classifier_feature_names_YYYYMMDD_HHMM.json
  python scripts/s72a_check_features.py --models_dir /path/to/models
  python scripts/s72a_check_features.py --config /path/to/s70_config.json
  python scripts/s72a_check_features.py --relax-regex   # treat regex hits as warnings (exit 0)
"""

from __future__ import annotations
import argparse, json, sys, re
from pathlib import Path
from datetime import datetime

# ---- project-aware paths (expects common.paths.P) ----
SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parent
sys.path.insert(0, str(PROJECT_ROOT))
try:
    from common.paths import P  # has ROOT
except Exception:
    class _P:  # fallback: assume repo root is parent of scripts/
        ROOT = PROJECT_ROOT
    P = _P()

# ------------------ Defaults (can be extended via config) ------------------

# Hard blocks (after prefix-stripping)
FORBIDDEN_EXACT_DEFAULT = {
    "ret_trade", "pnl_eur", "entry_px", "exit_px", "exit_dt", "trade_id", "num_fills", "legs"
}

# Regex patterns with token-ish boundaries (compiled later)
FORBIDDEN_REGEX_DEFAULT = [
    # P&L / realized / returns
    r"\b(pnl|p&l)\b",
    r"\b(close[_]?pnl|closing[_]?pnl|realiz(?:ed|e)?[_]?pnl|realised[_]?pnl)\b",
    r"\b(realiz(?:ed|e)?|realised|unrealiz(?:ed|e)?|unrealised)\b",
    r"\b(loss|profit|gain)\b",
    r"\bret_trade\b",
    r"(^|_)ret(_|$)",          # safer than plain "return"
    # exit / post-entry info
    r"\bexit(_?(dt|time|px|price))?\b",
    r"\bexittime\b|\bexitprice\b",
    # label-ish / lookahead clues
    r"\b(label|target|ground[_ ]?truth)\b",
    r"\b(future|ahead|lead|shift|t\+?1|next(_|$))",
]

# ---------------------------------------------------------------------------

def _ts() -> str:
    return datetime.utcnow().strftime("%Y%m%d_%H%M")

def _latest_feats_json(models_dir: Path) -> Path | None:
    cands = sorted(models_dir.glob("classifier_feature_names_*.json"))
    return cands[-1] if cands else None

def _strip_prefix(name: str) -> str:
    # remove ColumnTransformer prefixes and OHE ticker prefix
    s = name
    if s.startswith("num__"): s = s[len("num__"):]
    if s.startswith("cat__"): s = s[len("cat__"):]
    if s.startswith("ticker_"): s = s[len("ticker_"):]
    return s

def _load_config(explicit: str | None) -> dict:
    # precedence: --config > param_results/s70_config.json > root/s70_config.json (optional)
    paths = []
    if explicit:
        paths.append(Path(explicit))
    paths.append(P.ROOT / "param_results" / "s70_config.json")
    paths.append(P.ROOT / "s70_config.json")
    for p in paths:
        if p and p.exists():
            try:
                with open(p, "r") as f:
                    cfg = json.load(f)
                fg = cfg.get("feature_guard", {})
                fg["_config_path"] = str(p)
                return fg
            except Exception:
                # ignore malformed config, treat as no config
                return {}
    return {}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--feats", type=str, default=None, help="Path to classifier_feature_names_*.json")
    ap.add_argument("--models_dir", type=str, default=str(P.ROOT / "models"),
                    help="Models dir to search latest feature file (default: <ROOT>/models)")
    ap.add_argument("--config", type=str, default=None,
                    help="Path to s70_config.json (optional). Defaults: param_results/s70_config.json if present.")
    ap.add_argument("--relax-regex", action="store_true",
                    help="Treat regex hits as warnings (do not fail the check).")
    ap.add_argument("--show", type=int, default=None,
                    help="How many offenders to print per category (overrides config).")
    args = ap.parse_args()

    models_dir = Path(args.models_dir)
    feats_path = Path(args.feats) if args.feats else _latest_feats_json(models_dir)
    if not feats_path or not feats_path.exists():
        print(f"[ERR] Feature names JSON not found. Looked in: {models_dir}")
        sys.exit(2)

    # Load features
    with open(feats_path, "r") as f:
        feat_names = json.load(f)
    total_feats = len(feat_names)

    # Load config (optional)
    cfg = _load_config(args.config)
    forbidden_exact = set(FORBIDDEN_EXACT_DEFAULT) | set(cfg.get("forbidden_exact", []))
    regex_list = list(FORBIDDEN_REGEX_DEFAULT) + list(cfg.get("forbidden_regex", []))
    allowlist = set(cfg.get("allowlist", []))
    treat_regex_as_error = bool(cfg.get("treat_regex_as_error", True)) and (not args.relax_regex)
    max_print = int(cfg.get("max_print", 20))
    if args.show is not None:
        max_print = max(1, int(args.show))

    # Compile regex
    try:
        forbidden_regex = [re.compile(pat, re.IGNORECASE) for pat in regex_list]
    except re.error as e:
        print(f"[WARN] Bad regex in config/defaults: {e}. Falling back to substring contains for that pattern.")
        forbidden_regex = []
        for pat in regex_list:
            try:
                forbidden_regex.append(re.compile(pat, re.IGNORECASE))
            except re.error:
                # store as sentinel for substring handling
                forbidden_regex.append(pat)

    offenders_exact: list[str] = []
    offenders_regex: list[tuple[str, str]] = []  # (feature, pattern)

    # Scan
    for raw in feat_names:
        base = _strip_prefix(raw)
        if base in allowlist or raw in allowlist:
            continue

        base_low = base.lower()
        raw_low = raw.lower()

        # exact after prefix-strip
        if base in forbidden_exact:
            offenders_exact.append(raw)
            continue

        # regex (preferred). If a pattern failed to compile, 'pattern' is a string → fallback to substring
        for pat in forbidden_regex:
            if isinstance(pat, re.Pattern):
                if pat.search(raw_low) or pat.search(base_low):
                    offenders_regex.append((raw, pat.pattern))
            else:
                # substring fallback
                if pat.lower() in raw_low or pat.lower() in base_low:
                    offenders_regex.append((raw, pat))

    # Deduplicate regex offenders & remove those already in exact
    offenders_regex = [(f, p) for (f, p) in offenders_regex if f not in offenders_exact]
    # Normalize + unique by feature
    seen = set()
    uniq_regex = []
    for f, p in offenders_regex:
        if f not in seen:
            seen.add(f)
            uniq_regex.append((f, p))
    offenders_regex = uniq_regex

    # Reporting
    print(f"[INFO] Checking: {feats_path.name}")
    if "_config_path" in cfg:
        print(f"[INFO] Using config: {cfg['_config_path']}")
    print(f"[INFO] Total features: {total_feats}")
    print(f"[INFO] Allowlist size: {len(allowlist)}")
    print(f"[INFO] Regex strict mode: {'ON (will error)' if treat_regex_as_error else 'RELAXED (warn only)'}")

    ok = True

    if offenders_exact:
        ok = False
        print(f"\n[LEAK BLOCK] Exact-forbidden features detected ({len(offenders_exact)}):")
        for x in sorted(offenders_exact)[:max_print]:
            print("  -", x)
        if len(offenders_exact) > max_print:
            print(f"  ... and {len(offenders_exact)-max_print} more")
    else:
        print("\n[OK] No exact-forbidden features found.")

    if offenders_regex:
        header = "[LEAK?] Suspicious features (regex)" if treat_regex_as_error else "[WARN] Suspicious features (regex)"
        print(f"\n{header} detected ({len(offenders_regex)}):")
        for x, pat in sorted(offenders_regex, key=lambda t: t[0])[:max_print]:
            print(f"  - {x}    (match: /{pat}/)")
        if len(offenders_regex) > max_print:
            print(f"  ... and {len(offenders_regex)-max_print} more")
        if treat_regex_as_error:
            ok = False
    else:
        print("\n[OK] No regex-based suspicious features found.")

    # Write JSON report (for CI/logging)
    report = {
        "feature_file": str(feats_path),
        "total_features": total_feats,
        "config_used": cfg.get("_config_path", None),
        "allowlist_size": len(allowlist),
        "forbidden_exact": sorted(list(forbidden_exact)),
        "forbidden_regex": regex_list,
        "offenders_exact_count": len(offenders_exact),
        "offenders_exact_sample": sorted(offenders_exact)[:max_print],
        "offenders_regex_count": len(offenders_regex),
        "offenders_regex_sample": [{"feature": f, "pattern": p} for (f, p) in offenders_regex[:max_print]],
        "treat_regex_as_error": treat_regex_as_error,
        "result_ok": bool(ok),
        "timestamp_utc": _ts(),
    }
    try:
        out_dir = P.ROOT / "models"
        out_dir.mkdir(parents=True, exist_ok=True)
        out_json = out_dir / f"feature_guard_report_{_ts()}.json"
        with open(out_json, "w") as f:
            json.dump(report, f, indent=2)
        print(f"\n[OK] Wrote report → {out_json}")
    except Exception as e:
        print(f"\n[WARN] Could not write report JSON: {e}")

    # Exit code
    if ok:
        print("\n[RESULT] feature_guard_ok=True")
        sys.exit(0)
    else:
        print("\n[RESULT] feature_guard_ok=False")
        sys.exit(1)

if __name__ == "__main__":
    main()