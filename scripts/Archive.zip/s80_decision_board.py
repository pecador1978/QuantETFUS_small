#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
s80_decision_board.py — Operator-facing BUY / DO NOTHING table (one row per ticker).

Inputs (auto, in priority):
1) param_results/final_signals_<ts>.csv            (preferred; from s74)
2) param_results/live_signals_<ts>.csv             (new; from s76)
3) param_results/s70_results_with_guidance_<ts>.csv (fallback; from s70)

Optional:
- param_results/s70b_per_ticker_thresholds_<ts>.csv   (per-ticker thr)
- models/classifier_metrics_<ts>.json                 (global thr)

Outputs:
- param_results/final_decisions_<ts>.csv            (technical, one-row-per-ticker)
- param_results/final_decisions_pretty_<ts>.csv     (operator board)
"""

from __future__ import annotations
from pathlib import Path
from datetime import datetime, timezone
import sys, json
import pandas as pd
import numpy as np

# project-aware paths
SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
from common.paths import P  # noqa: E402

def _ts() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%d_%H%M")

def _latest(base: Path, pat: str) -> Path | None:
    c = sorted(base.glob(pat))
    return c[-1] if c else None

def load_live() -> pd.DataFrame:
    pr = P.ROOT / "param_results"

    # 1) s74
    p = _latest(pr, "final_signals_*.csv")
    if p:
        print(f"[INFO] Using s74 file → {p.name}")
        return pd.read_csv(p)

    # 2) s76 (new)
    p = _latest(pr, "live_signals_*.csv")
    if p:
        print(f"[INFO] Using s76 live file → {p.name}")
        return pd.read_csv(p)

    # 3) s70
    p = _latest(pr, "s70_results_with_guidance_*.csv")
    if p:
        print(f"[INFO] Using s70 live file → {p.name}")
        return pd.read_csv(p)

    raise SystemExit(f"[ERR] No live file found in {pr} (looked for final_signals_*, live_signals_*, s70_results_with_guidance_*).")

def load_thr_map() -> dict[str, float]:
    pr = P.ROOT / "param_results"
    p = _latest(pr, "s70b_per_ticker_thresholds_*.csv")
    if not p:
        print("[INFO] No per-ticker thresholds (s70b).")
        return {}
    df = pd.read_csv(p)
    thr_col = "thr_star" if "thr_star" in df.columns else (
        "thr_star_val" if "thr_star_val" in df.columns else None
    )
    if not thr_col:
        print("[WARN] s70b file missing thr_star; ignoring.")
        return {}
    m = (df[["ticker", thr_col]]
         .dropna()
         .groupby("ticker")[thr_col]
         .last()
         .to_dict())
    print(f"[INFO] Loaded {len(m)} per-ticker thresholds.")
    return m

def load_global_thr() -> float:
    md = P.ROOT / "models"
    p = _latest(md, "classifier_metrics_*.json")
    if not p:
        print("[INFO] No metrics json; global threshold = 0.50")
        return 0.50
    try:
        d = json.loads(p.read_text())
        t = float(d.get("decision_threshold", 0.50))
        print(f"[INFO] Global threshold → {t:.2f}")
        return t
    except Exception:
        print("[WARN] Could not parse metrics; global threshold = 0.50")
        return 0.50

def coerce_dt_cols(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    # Normalize column names we might see
    # (keep original if already present)
    for alt, std in [
        ("when", "entry_dt"),
        ("timestamp", "entry_dt"),
        ("time", "entry_dt"),
    ]:
        if alt in df.columns and "entry_dt" not in df.columns:
            df = df.rename(columns={alt: "entry_dt"})

    if "entry_dt" in df.columns:
        df["entry_dt"] = pd.to_datetime(df["entry_dt"], errors="coerce", utc=True)
    if "date" in df.columns:
        df["date"] = pd.to_datetime(df["date"], errors="coerce", utc=True)
    return df

def pick_latest_per_ticker(df: pd.DataFrame) -> pd.DataFrame:
    df = coerce_dt_cols(df)

    # build a sortable timestamp
    if "entry_dt" in df.columns and df["entry_dt"].notna().any():
        df["_when"] = df["entry_dt"]
    elif "date" in df.columns and df["date"].notna().any():
        df["_when"] = df["date"]
    else:
        df["_when"] = pd.Series(range(len(df)), index=df.index)

    latest = (df
              .sort_values(["ticker", "_when"])
              .groupby("ticker", as_index=False)
              .tail(1)
              .reset_index(drop=True)
              .drop(columns=["_when"]))
    return latest

def has_usable_strategy_signal(df: pd.DataFrame) -> bool:
    if "signal" not in df.columns:
        return False
    # consider usable if at least one non-empty string present
    sig = df["signal"].astype(str).str.strip()
    return sig.notna().any() and (sig != "" ).any()

def decide_row(r, thr_map, gthr, strategy_mode: bool) -> tuple[str, float]:
    tkr = str(r.get("ticker"))
    ml_ok = bool(r.get("ml_usable", False))
    q = str(r.get("quality", "")).strip()
    prob = float(r.get("y_prob", np.nan)) if "y_prob" in r else np.nan
    ypred = r.get("y_pred", np.nan)

    thr = float(thr_map.get(tkr, gthr))

    if strategy_mode:
        # Require strategy Buy; then apply ML gate if ml_usable
        sig = str(r.get("signal", "")).strip()
        if sig == "Buy":
            if ml_ok:
                buy = (not np.isnan(prob)) and (prob >= thr)
            else:
                # No ML gate; rely on quality if available
                buy = (q != "No Go")
        else:
            buy = False
        return ("BUY" if buy else "DO NOTHING", thr if ml_ok else np.nan)

    # ML-only mode (typical for live_signals_* which has no real strategy 'signal')
    if not ml_ok:
        return ("DO NOTHING", np.nan)

    if not pd.isna(ypred):
        buy = (int(ypred) == 1)
    else:
        buy = (not np.isnan(prob)) and (prob >= thr)
    return ("BUY" if buy else "DO NOTHING", thr)

def icon(decision: str, ml_ok: bool, quality: str) -> str:
    if decision == "BUY":
        return "✅" if (ml_ok and quality in ("High Confidence", "Medium (OK)")) else "🟡"
    return "⏸️"

def main():
    df_all = load_live()
    thr_map = load_thr_map()
    gthr = load_global_thr()

    # Ensure expected cols
    if "ticker" not in df_all.columns:
        raise SystemExit("[ERR] Input is missing 'ticker' column.")
    if "ml_usable" not in df_all.columns:
        df_all["ml_usable"] = False
    if "quality" not in df_all.columns:
        df_all["quality"] = ""

    # Latest row per ticker
    df = pick_latest_per_ticker(df_all)

    # Mode: strategy-aware vs ML-only
    strategy_mode = has_usable_strategy_signal(df)

    # Decisions
    dec_thr = df.apply(lambda r: decide_row(r, thr_map, gthr, strategy_mode), axis=1)
    dec, thr_used = zip(*dec_thr)
    df["decision"] = dec
    df["threshold_used"] = thr_used

    # Operator-friendly fields
    if "y_prob" in df.columns:
        df["ML Probability"] = df["y_prob"].astype(float).round(2)
    else:
        df["ML Probability"] = np.nan
    df["Signal (Strategy)"] = df["signal"] if "signal" in df.columns else ""
    df["Decision Icon"] = [icon(d, bool(m), str(q)) for d, m, q in
                           zip(df["decision"], df["ml_usable"], df.get("quality",""))]

    # Sort: BUY first by prob desc
    if "ML Probability" in df.columns:
        df["decision_order"] = np.where(df["decision"] == "BUY", 0, 1)
        df = df.sort_values(["decision_order", "ML Probability"], ascending=[True, False]).drop(columns=["decision_order"])
    else:
        df = df.sort_values(["decision", "ticker"])

    pr = P.ROOT / "param_results"
    pr.mkdir(parents=True, exist_ok=True)
    ts = _ts()

    # Technical output (one row per ticker)
    tech_cols = [c for c in [
        "entry_dt","date","ticker","signal","y_prob","y_pred","ml_usable",
        "quality","action_guidance","threshold_used","decision"
    ] if c in df.columns]
    out_full = pr / f"final_decisions_{ts}.csv"
    df[tech_cols].to_csv(out_full, index=False)
    print(f"[OK] Decisions (per ticker) → {out_full}")

    # Pretty board
    pretty_cols = []
    for c in ("entry_dt","date"):
        if c in df.columns: pretty_cols.append(c); break
    pretty_cols += [c for c in (
        "ticker","Signal (Strategy)","ML Probability","quality","Decision Icon","decision","action_guidance"
    ) if c in df.columns]

    out_pretty = pr / f"final_decisions_pretty_{ts}.csv"
    df[pretty_cols].rename(columns={"quality":"Quality","action_guidance":"Action Guidance"}).to_csv(out_pretty, index=False)
    print(f"[OK] Operator board → {out_pretty}")

    print("\n[Decision counts]")
    print(df["decision"].value_counts(dropna=False).to_string())

if __name__ == "__main__":
    main()