#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
s74_make_signals.py
Create a daily "signals to consider" watchlist from s70 predictions
(optionally applying per-ticker thresholds from s70b).

Outputs (to <ROOT>/param_results):
  - s74_signals_global_<ts>.csv       # using the global threshold found in preds
  - s74_signals_per_ticker_<ts>.csv   # using per-ticker thresholds when available
  - (console) a short summary preview

Usage:
  python scripts/s74_make_signals.py               # default: split=test
  python scripts/s74_make_signals.py --split val   # or train/val/test
  python scripts/s74_make_signals.py --min-prob 0.6 --topk 5
  python scripts/s74_make_signals.py --quality High --quality "Medium (OK)"
"""

from __future__ import annotations
from pathlib import Path
from datetime import datetime, timezone
import argparse, sys
import numpy as np
import pandas as pd

# project-aware paths
SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
from common.paths import P  # ROOT, etc.

MODELS = P.ROOT / "models"
PARAMS = P.ROOT / "param_results"

def _ts() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%d_%H%M")

def _latest(globpat: str, base: Path) -> Path | None:
    cands = sorted(base.glob(globpat))
    return cands[-1] if cands else None

def _load_preds(split: str) -> tuple[pd.DataFrame, float, Path]:
    fp = _latest(f"classifier_{split}_predictions_*.csv", MODELS)
    if not fp:
        raise SystemExit(f"[ERR] Missing predictions for {split} in {MODELS}")
    df = pd.read_csv(fp)

    # basic cols
    need_any = {"ticker", "y_true"}
    if not need_any.issubset(df.columns):
        raise SystemExit(f"[ERR] {fp} missing {need_any - set(df.columns)}")

    # probabilities preferred
    if "y_prob" in df.columns:
        df["y_prob"] = pd.to_numeric(df["y_prob"], errors="coerce").fillna(0.5).astype(float)
    else:
        # fall back to y_pred as a degenerate prob if needed
        if "y_pred" not in df.columns:
            raise SystemExit(f"[ERR] {fp} needs 'y_prob' or 'y_pred'")
        df["y_prob"] = df["y_pred"].astype(float)

    # discover global threshold
    thr = 0.50
    if "threshold_used" in df.columns:
        try:
            vals = pd.to_numeric(df["threshold_used"], errors="coerce").dropna().unique()
            if len(vals) == 1:
                thr = float(vals[0])
        except Exception:
            pass
    return df, thr, fp

def _load_per_ticker_thresholds() -> dict[str, float]:
    f = _latest("s70b_per_ticker_thresholds_*.csv", PARAMS)
    if not f:
        return {}
    tdf = pd.read_csv(f)
    # accept these column names in priority order
    for c in ["thr_star", "thr_best", "thr_opt", "thr_val_star"]:
        if c in tdf.columns:
            tdf = tdf.loc[np.isfinite(tdf[c]), ["ticker", c]].copy()
            return dict(zip(tdf["ticker"].astype(str), tdf[c].astype(float)))
    return {}

def _attach_quality_flags(df: pd.DataFrame) -> pd.DataFrame:
    # merge per_ticker_quality if present
    qf = PARAMS / "per_ticker_quality.csv"
    if qf.exists():
        q = pd.read_csv(qf)[["ticker", "quality"]]
        df = df.merge(q, on="ticker", how="left")
    else:
        df["quality"] = np.nan

    # ml_usable default: High/Medium OK, else False
    df["ml_usable"] = df["quality"].isin(["High Confidence", "Medium (OK)"])

    # whitelist override if present
    wl_file = PARAMS / "s70_whitelist.csv"
    if wl_file.exists():
        try:
            wl = pd.read_csv(wl_file)[["ticker"]].drop_duplicates()
            wl["ml_usable"] = True
            df = df.drop(columns=["ml_usable"]).merge(wl, on="ticker", how="left")
            df["ml_usable"] = df["ml_usable"].fillna(False).astype(bool)
            print(f"[INFO] Applied whitelist override → {wl_file}")
        except Exception as e:
            print(f"[WARN] Failed to apply whitelist override: {e}")
    return df

def _make_signals(df: pd.DataFrame,
                  thr_global: float,
                  thr_map: dict[str, float] | None,
                  quality_filters: list[str] | None,
                  min_prob: float | None,
                  topk: int | None) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Return (signals_global, signals_per_ticker)."""

    df = df.copy()
    df = _attach_quality_flags(df)

    # apply optional quality filter
    if quality_filters:
        df = df[df["quality"].isin(quality_filters)].copy()

    # global rule
    g = df.copy()
    g["thr_used"] = float(thr_global)
    g["y_pred_rule"] = (g["y_prob"] >= g["thr_used"]).astype(int)
    g["decision_rule"] = "global"

    # per-ticker rule (fallback to global if missing)
    if thr_map:
        p = df.copy()
        p["thr_used"] = p["ticker"].astype(str).map(thr_map).astype(float)
        # fill missing with global
        p["thr_used"] = p["thr_used"].where(np.isfinite(p["thr_used"]), float(thr_global))
        p["decision_rule"] = np.where(
            p["ticker"].astype(str).isin(thr_map.keys()), "per_ticker", "global_fallback"
        )
        p["y_pred_rule"] = (p["y_prob"] >= p["thr_used"]).astype(int)
    else:
        p = g.copy()
        p["decision_rule"] = "global"  # no per-ticker thresholds available

    # optional min probability cutoff (post-threshold)
    def _post_filter(d):
        out = d[(d["y_pred_rule"] == 1) & (d["ml_usable"] == True)].copy()
        if min_prob is not None:
            out = out[out["y_prob"] >= float(min_prob)]
        # pick a few columns if available
        cols = [c for c in ["date","entry_dt","ticker","signal","y_prob","thr_used","decision_rule","quality"] if c in out.columns]
        if not cols:
            cols = ["ticker","y_prob","thr_used","decision_rule","quality"]
        out = out[cols].sort_values(["y_prob","ticker"], ascending=[False, True])
        if topk is not None and topk > 0:
            # top-K per ticker (by y_prob)
            out = (out.sort_values(["ticker","y_prob"], ascending=[True, False])
                     .groupby("ticker", as_index=False)
                     .head(int(topk)))
        return out

    sig_g = _post_filter(g)
    sig_p = _post_filter(p)
    return sig_g, sig_p

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--split", choices=["train","val","test"], default="test")
    ap.add_argument("--min-prob", type=float, default=None, help="Optional extra filter: keep signals with y_prob >= this.")
    ap.add_argument("--topk", type=int, default=None, help="Optional: take top-K per ticker.")
    ap.add_argument("--quality", action="append", default=None,
                    help='Quality filter(s). E.g. --quality "High Confidence" --quality "Medium (OK)"')
    args = ap.parse_args()

    df, thr_global, src = _load_preds(args.split)
    print(f"[INFO] Using {args.split.upper()} predictions from {src}")
    print(f"[INFO] Global threshold detected in file: {thr_global:.2f}")

    thr_map = _load_per_ticker_thresholds()
    if thr_map:
        print(f"[INFO] Found per-ticker thresholds: {len(thr_map)} tickers.")
    else:
        print("[INFO] No per-ticker thresholds found (run s70b_make_per_ticker_thresholds.py to create them).")

    sig_g, sig_p = _make_signals(
        df=df,
        thr_global=thr_global,
        thr_map=thr_map if thr_map else None,
        quality_filters=args.quality,
        min_prob=args.min_prob,
        topk=args.topk,
    )

    PARAMS.mkdir(parents=True, exist_ok=True)
    ts = _ts()
    out_g = PARAMS / f"s74_signals_global_{ts}.csv"
    out_p = PARAMS / f"s74_signals_per_ticker_{ts}.csv"
    sig_g.to_csv(out_g, index=False)
    sig_p.to_csv(out_p, index=False)

    print(f"\n[OK] Signals (global rule)     → {out_g}")
    print(f"[OK] Signals (per-ticker rule) → {out_p}")

    # quick console preview
    def _preview(name, d):
        if d.empty:
            print(f"\n[{name}] No signals after filters.")
            return
        cols = [c for c in ["date","entry_dt","ticker","signal","y_prob","thr_used","decision_rule","quality"] if c in d.columns]
        print(f"\n[{name}] Top 15 by prob")
        print(d.sort_values("y_prob", ascending=False).head(15)[cols].to_string(index=False))

    _preview("GLOBAL", sig_g)
    _preview("PER-TICKER", sig_p)

if __name__ == "__main__":
    main()