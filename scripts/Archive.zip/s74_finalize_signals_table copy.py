#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
s74_finalize_signals_table.py
Produce the live trading table:
- shows signals for ALL tickers
- uses ML only where `ml_usable==True`
- when ML is usable, applies *per-ticker thresholds* from s70b; otherwise falls back to global.

Inputs
------
<ROOT>/param_results/s70_results_with_guidance_<ts>.csv  (latest; produced by s70)
<ROOT>/param_results/s70b_per_ticker_thresholds_<ts>.csv (latest; produced by s70b)  [optional but recommended]

Behavior
--------
- Loads the latest s70 live CSV.
- Loads latest per-ticker thresholds (thr_star) if present and merges by `ticker`.
- Determines an applied threshold per row:
    applied_thr = thr_star (if available & ml_usable) else global_thr
  where global_thr is taken from live file `threshold_used` if present, otherwise 0.50.
- For rows with ml_usable == False:
    * leaves original `signal` intact
    * nulls ML display columns (`y_prob_display`, `y_pred_display`)
- For rows with ml_usable == True:
    * copies `y_prob` → `y_prob_display`
    * sets `y_pred_display` from proba vs applied threshold
- Adds audit columns:
    threshold_used_global, threshold_used_ticker, threshold_used_applied

Outputs
-------
- <ROOT>/param_results/final_signals_<ts>.csv
- (best-effort) Parquet alongside the CSV
- Console summary of row counts by ml_usable
"""

from __future__ import annotations

import sys
from pathlib import Path
from datetime import datetime, timezone

import numpy as np
import pandas as pd

# ---- project-aware paths ----
SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
from common.paths import P  # ROOT, etc.


def _ts() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%d_%H%M")


def _latest(pattern: str, base: Path) -> Path | None:
    files = sorted(base.glob(pattern))
    return files[-1] if files else None


def main():
    param_dir = P.ROOT / "param_results"

    # 1) Load latest live file from s70
    live_path = _latest("s70_results_with_guidance_*.csv", param_dir)
    if not live_path:
        raise SystemExit("[ERR] No s70 live file found in param_results (s70_results_with_guidance_*.csv).")
    print(f"[INFO] Using live file: {live_path}")

    live = pd.read_csv(live_path)

    # Defensive: ensure needed columns exist
    needed_prob = "y_prob" in live.columns
    if not needed_prob:
        raise SystemExit("[ERR] y_prob column missing in live file (needed for thresholding).")

    if "ml_usable" not in live.columns:
        # default to False if missing
        live["ml_usable"] = False
    live["ml_usable"] = live["ml_usable"].fillna(False).astype(bool)

    # Grab global threshold if present, else 0.50
    global_thr = 0.50
    if "threshold_used" in live.columns and pd.api.types.is_numeric_dtype(live["threshold_used"]):
        # if threshold_used varied per row, take the mode; else pick first non-null
        ser = live["threshold_used"].dropna().astype(float)
        if not ser.empty:
            try:
                global_thr = float(ser.mode().iloc[0])
            except Exception:
                global_thr = float(ser.iloc[0])
    print(f"[INFO] Global decision threshold (fallback): {global_thr:.2f}")

    # 2) Load latest per-ticker thresholds (optional)
    thr_path = _latest("s70b_per_ticker_thresholds_*.csv", param_dir)
    thr_df = None
    if thr_path:
        try:
            thr_df = pd.read_csv(thr_path)
            # Expected columns: ticker, thr_star (plus metrics)
            # Backward-compat: sometimes the column might be named slightly differently
            if "ticker" not in thr_df.columns:
                raise ValueError("ticker column not found in s70b thresholds file.")
            if "thr_star" not in thr_df.columns:
                # try alternative names
                cand = [c for c in thr_df.columns if "thr" in c and "star" in c]
                if cand:
                    thr_df = thr_df.rename(columns={cand[0]: "thr_star"})
                else:
                    raise ValueError("thr_star column not found in s70b thresholds file.")
            thr_df = thr_df[["ticker", "thr_star"]].copy()
            print(f"[INFO] Using per-ticker thresholds: {thr_path}")
        except Exception as e:
            print(f"[WARN] Failed to read thresholds file {thr_path}: {e}")
            thr_df = None
    else:
        print("[INFO] No per-ticker thresholds file found; will use global threshold only.")

    # 3) Merge thresholds
    if thr_df is not None:
        live = live.merge(thr_df, on="ticker", how="left")  # thr_star may be NaN for some tickers
    else:
        live["thr_star"] = np.nan

    # 4) Determine applied threshold per row
    # Only use per-ticker threshold if ML is usable for that row and thr_star is present
    live["threshold_used_global"] = global_thr
    live["threshold_used_ticker"] = pd.to_numeric(live["thr_star"], errors="coerce")

    def _pick_thr(row):
        if bool(row.get("ml_usable", False)) and pd.notna(row.get("threshold_used_ticker", np.nan)):
            return float(row["threshold_used_ticker"])
        return float(row["threshold_used_global"])

    live["threshold_used_applied"] = live.apply(_pick_thr, axis=1)

    # 5) Build display columns using the applied threshold (only when ML is usable)
    # y_prob_display always mirrors y_prob when ml_usable==True; otherwise NaN
    live["y_prob_display"] = np.where(live["ml_usable"], live["y_prob"], np.nan)

    # y_pred_pt = 1{ y_prob >= applied_threshold }
    live["y_pred_pt"] = (live["y_prob"] >= live["threshold_used_applied"]).astype("Int64")

    # y_pred_display = y_pred_pt when ML usable; otherwise NaN
    live["y_pred_display"] = np.where(live["ml_usable"], live["y_pred_pt"], np.nan)

    # 6) Sort nicely if we have timestamps (date or entry_dt), then ticker
    sort_cols = [c for c in ["date", "entry_dt", "ticker"] if c in live.columns]
    if sort_cols:
        live = live.sort_values(sort_cols).reset_index(drop=True)

    # 7) Save outputs
    out_dir = param_dir
    out_dir.mkdir(parents=True, exist_ok=True)
    out_csv = out_dir / f"final_signals_{_ts()}.csv"
    live.to_csv(out_csv, index=False)
    print(f"[OK] Final table → {out_csv}")

    try:
        out_parq = out_csv.with_suffix(".parquet")
        live.to_parquet(out_parq, index=False)
    except Exception:
        pass

    # 8) Summary
    try:
        counts = live["ml_usable"].value_counts(dropna=False).rename_axis("ml_usable").reset_index(name="n")
        print("\n[ml_usable counts]")
        print(counts.to_string(index=False))
        # Little sanity on how many rows actually used per-ticker threshold:
        used_pt = int(((live["ml_usable"]) & (pd.notna(live["threshold_used_ticker"]))).sum())
        print(f"\n[INFO] Rows using per-ticker threshold: {used_pt}")
    except Exception:
        pass


if __name__ == "__main__":
    main()