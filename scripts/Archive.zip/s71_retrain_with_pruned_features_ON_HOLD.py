#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
s71_retrain_with_pruned_features.py — Retrain on pruned features (quota-based).

What’s new vs the previous version
----------------------------------
- Supports per-group quotas so we don’t over-prune self/intraday features:
    --quota "self:250,m30:80,ratios:120,macro_sector:80,vol:30,other:40,categorical:1"
- Optional --pos-only to require positive lower-bound (lb95>0) when PI CSV comes from s70f.
- Still supports the legacy --topk or --pi-thresh modes if you prefer.

Inputs
------
- Latest permutation importance CSV under models/:
    * Prefer: s70f output (has columns: feature, importance_mean, importance_std, lb95, zscore, importance_pct_of_pos)
    * Else:   classical s71 output (feature, importance_mean, importance_std)
- TRAIN/VAL/TEST at data_final_training/{train,val,test}.csv

Outputs
-------
- Pruned splits: data_final_training_pruned/<ts>/{train,val,test}.csv
- feature_manifest.csv listing the kept features
- Calls s70 on the pruned splits (same args as before), writes all the usual s70 artifacts.
"""

from __future__ import annotations

import argparse
import re
from pathlib import Path
from datetime import datetime, timezone
import sys
import numpy as np
import pandas as pd
import subprocess
import json

# ---- project-aware paths ----
SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
from common.paths import P  # ROOT, etc.

# ---------------- utils ----------------
def _ts() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%d_%H%M")

def _latest(path: Path, pattern: str) -> Path | None:
    cands = sorted(path.glob(pattern))
    return cands[-1] if cands else None

def _load_pi(pi_csv: Path | None) -> pd.DataFrame:
    if pi_csv is None:
        # Prefer explicit "latest" symlink if present
        pi_csv = (P.ROOT / "models" / "permutation_importance_latest.csv")
        if not pi_csv.exists():
            # Fall back to newest timestamped file
            pi_csv = _latest(P.ROOT / "models", "permutation_importance_*.csv")
            if not pi_csv:
                raise SystemExit("[ERR] No permutation importance CSV found under models/.")
    df = pd.read_csv(pi_csv)
    if "feature" not in df.columns or "importance_mean" not in df.columns:
        raise SystemExit(f"[ERR] PI file missing required columns: {pi_csv}")
    # Normalize optional columns
    if "importance_std" not in df.columns:
        df["importance_std"] = np.nan
    if "lb95" not in df.columns:
        df["lb95"] = np.nan
    return df

# ---------------- grouping ----------------
_SECTOR_MACRO_TOKENS = set("""
XLV XLF XLK XLE XLY XLP XLU XLI XLB XLRE XLC
SPY QQQ DIA IWM
GLD SLV GDX GDXJ
HYG LQD IEI TLT
DBC USO UNG
UUP DXY
KRE SMH XLP XLF XLK XLE
""".split())

def _group_for_feature(name: str) -> str:
    f = str(name)
    if f == "ticker":
        return "categorical"
    if f.startswith("m30_"):
        return "m30"
    if "_RATIO_" in f:
        return "ratios"
    if any(tok in f for tok in ("VIX", "VVIX", "VIX3M", "VIX9D")):
        return "vol"
    # quick token check at start (e.g., XLV_macd_...)
    first_token = f.split("_", 1)[0]
    if first_token in _SECTOR_MACRO_TOKENS or any(tok in f for tok in _SECTOR_MACRO_TOKENS):
        return "macro_sector"
    # TA-ish names on the instrument itself
    if any(key in f for key in ("rsi", "macd", "ema", "sma", "adx", "atr", "stoch", "bb")):
        return "self"
    return "other"

def _apply_quota(df_pi: pd.DataFrame, quotas: dict[str, int], pos_only: bool) -> list[str]:
    df = df_pi.copy()
    df["group"] = df["feature"].map(_group_for_feature)

    if pos_only and "lb95" in df.columns and df["lb95"].notna().any():
        df = df[df["lb95"] > 0.0].copy()
        if df.empty:
            print("[WARN] --pos-only filtered everything; ignoring the filter.")
            df = df_pi.copy()
            df["group"] = df["feature"].map(_group_for_feature)

    keep = []
    for g, k in quotas.items():
        block = df[df["group"] == g].sort_values("importance_mean", ascending=False)
        if k > 0 and not block.empty:
            keep.extend(block.head(k)["feature"].tolist())

    # de-dup but preserve order
    seen = set(); ordered = []
    for f in keep:
        if f not in seen:
            seen.add(f); ordered.append(f)
    return ordered

# ---------------- pruning core ----------------
DROP_ALWAYS = {
    "ret_trade", "pnl_eur", "entry_px", "exit_px", "entry_dt", "exit_dt", "trade_id", "num_fills", "legs"
}
CAT_KEEP = ["ticker"]

def _prune_and_write_splits(selected_feats: list[str], out_dir: Path) -> tuple[Path, Path, Path, int]:
    out_dir.mkdir(parents=True, exist_ok=True)

    def load_split(name: str) -> pd.DataFrame:
        p = P.ROOT / "data_final_training" / f"{name}.csv"
        if not p.exists():
            raise SystemExit(f"[ERR] Missing split file: {p}")
        return pd.read_csv(p)

    train = load_split("train")
    val   = load_split("val")
    test  = load_split("test")

    # Available numeric features among selected
    def select_columns(df: pd.DataFrame) -> pd.DataFrame:
        # Always keep required meta/label columns if present
        meta_cols = [c for c in DROP_ALWAYS if c in df.columns]
        cat_cols  = [c for c in CAT_KEEP if c in df.columns]
        # Keep only the selected numeric columns that exist in this split
        present = [c for c in selected_feats if c in df.columns]
        cols = meta_cols + cat_cols + present
        # also keep "signal" / "date" if they exist, harmless for s70
        for extra in ("signal", "date"):
            if extra in df.columns:
                cols.append(extra)
        # De-dup columns while preserving order
        final_cols = []
        seen = set()
        for c in cols:
            if c not in seen:
                final_cols.append(c); seen.add(c)
        return df[final_cols].copy()

    tr = select_columns(train)
    va = select_columns(val)
    te = select_columns(test)

    # Write pruned
    tr.to_csv(out_dir / "train.csv", index=False)
    va.to_csv(out_dir / "val.csv", index=False)
    te.to_csv(out_dir / "test.csv", index=False)

    # Manifest
    manifest = pd.DataFrame({"kept_feature": selected_feats})
    manifest.to_csv(out_dir / "feature_manifest.csv", index=False)

    return out_dir / "train.csv", out_dir / "val.csv", out_dir / "test.csv", len(selected_feats)

def _parse_quota(qstr: str) -> dict[str, int]:
    quotas: dict[str, int] = {}
    for part in qstr.split(","):
        part = part.strip()
        if not part:
            continue
        if ":" not in part:
            raise SystemExit(f"[ERR] Bad quota token '{part}'. Expected form 'group:n'.")
        g, n = part.split(":", 1)
        g = g.strip()
        try:
            quotas[g] = int(n)
        except ValueError:
            raise SystemExit(f"[ERR] Non-integer quota for '{g}': '{n}'")
    return quotas

# ---------------- main ----------------
def main():
    ap = argparse.ArgumentParser()
    # New: quota-based selection
    ap.add_argument("--quota", type=str, default=None,
        help="Comma-separated quotas per group, e.g. 'self:250,m30:80,ratios:120,macro_sector:80,vol:30,other:40,categorical:1'")
    ap.add_argument("--pos-only", action="store_true",
        help="If PI CSV has 'lb95', require lb95>0 when selecting features.")
    # Legacy selection modes
    sel = ap.add_mutually_exclusive_group(required=False)
    sel.add_argument("--topk", type=int, help="Global Top-K by importance_mean (legacy).")
    sel.add_argument("--pi-thresh", type=float, help="Keep features with importance_mean >= thresh (legacy).")
    ap.add_argument("--pi-csv", type=str, default=None, help="Path to permutation importance CSV. Default: latest in models/.")
    ap.add_argument("--decision-threshold", type=float, default=0.50, help="Global decision threshold for s70 (default 0.50).")
    ap.add_argument("--model", type=str, default="lgbm", choices=["lgbm","hgb"], help="Base model for s70 retrain.")
    ap.add_argument("--min-abs-corr", type=float, default=0.0, help="Pass-through to s70.")
    ap.add_argument("--drop-all-nan-cols", action="store_true", help="Pass-through to s70.")
    ap.add_argument("--extra-keep", type=str, default="", help="Comma-separated features to always keep (e.g., 'ticker').")
    ap.add_argument("--dry-run", action="store_true", help="Select & preview features but do not retrain.")
    args = ap.parse_args()

    df_pi = _load_pi(Path(args.pi_csv) if args.pi_csv else None)

    # Selection
    selected: list[str] = []

    if args.quota:
        quotas = _parse_quota(args.quota)
        selected = _apply_quota(df_pi, quotas, pos_only=args.pos_only)
        mode_desc = f"quota-based ({args.quota}){' + pos-only' if args.pos_only else ''}"
    elif args.topk:
        selected = (df_pi.sort_values("importance_mean", ascending=False)
                         .head(args.topk)["feature"].tolist())
        mode_desc = f"topk={args.topk}"
    elif args.pi_thresh is not None:
        selected = df_pi[df_pi["importance_mean"] >= float(args.pi_thresh)]["feature"].tolist()
        mode_desc = f"pi-thresh>={args.pi_thresh}"
    else:
        raise SystemExit("[ERR] Provide either --quota or one of (--topk, --pi-thresh).")

    # add always-keep
    if args.extra_keep:
        for t in [t.strip() for t in args.extra_keep.split(",") if t.strip()]:
            if t not in selected:
                selected.append(t)

    ts = _ts()
    out_dir = P.ROOT / "data_final_training_pruned" / ts
    tr_p, va_p, te_p, n_feats = _prune_and_write_splits(selected, out_dir)

    print(f"[OK] Pruned splits → {out_dir}")
    print(f"[INFO] Selected features: {n_feats} (manifest: {out_dir / 'feature_manifest.csv'})")
    print(f"[INFO] Selection mode: {mode_desc}")

    if args.dry_run:
        print("[DRY-RUN] Skipping retrain. You can retrain later pointing s70 to the pruned splits.")
        return

    # ---- call s70 on pruned splits ----
    cmd = [
        str(P.ROOT / "venv" / "bin" / "python"),
        str(P.ROOT / "scripts" / "s70_train_model_classifier_calibrated.py"),
        "--train", str(tr_p),
        "--val",   str(va_p),
        "--test",  str(te_p),
        "--model", args.model,
        "--min_abs_corr", str(args.min_abs_corr),
        "--threshold", "0.0",
        "--decision_threshold", str(args.decision_threshold),
    ]
    if args.drop_all_nan_cols:
        cmd.append("--drop_all_nan_cols")

    print("[s71] Calling trainer:\n ", " ".join(cmd), "\n")
    # Run in the same environment
    subprocess.run(cmd, check=True)
    print("[OK] s70 completed on pruned features.\n\n[DONE] s71: retrain with quota-based pruned features complete.")

if __name__ == "__main__":
    main()