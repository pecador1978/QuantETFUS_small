#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
s70b_threshold_sweep.py
Sweep decision thresholds on latest prediction CSVs written by s70 and report metrics.

Finds:
  <ROOT>/models/classifier_{train,val,test}_predictions_*.csv

Outputs:
  - Prints best-by-F1 and a small table around your current threshold
  - Saves full sweep to <ROOT>/param_results/s70_threshold_sweep_<ts>.csv
"""

from __future__ import annotations
from pathlib import Path
from datetime import datetime, timezone
import sys, re
import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score

# project-aware paths
SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
from common.paths import P

MODELS = P.ROOT / "models"
OUTDIR = P.ROOT / "param_results"

PATS = {
    "train": re.compile(r"classifier_train_predictions_(\d{8}_\d{4})\.csv$"),
    "val":   re.compile(r"classifier_val_predictions_(\d{8}_\d{4})\.csv$"),
    "test":  re.compile(r"classifier_test_predictions_(\d{8}_\d{4})\.csv$"),
}

def _ts(): return datetime.now(timezone.utc).strftime("%Y%m%d_%H%M")

def _latest(split: str) -> Path | None:
    pat = PATS[split]
    best = None; best_ts = ""
    for p in MODELS.glob(f"classifier_{split}_predictions_*.csv"):
        m = pat.search(p.name)
        if not m: continue
        ts = m.group(1)
        if ts > best_ts:
            best_ts, best = ts, p
    return best

def _load(fp: Path) -> pd.DataFrame:
    df = pd.read_csv(fp)
    if "y_prob" in df.columns and "y_score" not in df.columns:
        df = df.rename(columns={"y_prob":"y_score"})
    need = {"y_true","y_score"}
    if not need.issubset(df.columns):
        missing = need - set(df.columns)
        raise SystemExit(f"[ERR] {fp} missing {missing}")
    return df[["y_true","y_score"]].copy()

def _metrics_at(y, s, thr):
    yhat = (s >= thr).astype(int)
    out = dict(
        threshold=float(thr),
        n=len(y),
        accuracy=accuracy_score(y, yhat),
        precision=precision_score(y, yhat, zero_division=0),
        recall=recall_score(y, yhat, zero_division=0),
        f1=f1_score(y, yhat, zero_division=0),
    )
    return out

def main():
    files = {k: _latest(k) for k in ["train","val","test"]}
    miss = [k for k,v in files.items() if v is None]
    if miss:
        raise SystemExit(f"[ERR] Missing prediction CSVs for: {', '.join(miss)} in {MODELS}")

    df_te = _load(files["test"])
    y = df_te["y_true"].astype(int).values
    s = df_te["y_score"].astype(float).values

    # fixed grid; you can refine around interesting ranges
    grid = np.concatenate([np.linspace(0.50, 0.99, 50), np.array([0.999])])
    rows = [_metrics_at(y, s, thr) for thr in grid]
    sweep = pd.DataFrame(rows)

    # quick summaries
    best_f1 = sweep.sort_values("f1", ascending=False).head(1)
    around = sweep[(sweep["threshold"]>=0.55)&(sweep["threshold"]<=0.95)].iloc[::6]

    print("\n[TEST] Best-by-F1:")
    print(best_f1.to_string(index=False))
    print("\n[TEST] Thresholds (0.55→0.95 step ~0.08):")
    print(around.to_string(index=False))

    OUTDIR.mkdir(parents=True, exist_ok=True)
    outp = OUTDIR / f"s70_threshold_sweep_{_ts()}.csv"
    sweep.to_csv(outp, index=False)
    print(f"\n[OK] Saved full sweep → {outp}")

if __name__ == "__main__":
    main()