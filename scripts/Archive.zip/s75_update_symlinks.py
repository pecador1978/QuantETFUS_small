#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
s75_update_symlinks.py
Create/refresh stable *_latest symlinks for key outputs so dashboards & Excel
can always point at "current" artifacts without changing paths.

What it does
------------
- Scans known folders (models/, param_results/) for known patterns.
- Picks the most recent file (by modification time) for each pattern.
- Creates a sibling symlink named *_latest.<ext> pointing to that file.
- If symlink creation is not supported, falls back to copying the file.

Usage
-----
python scripts/s75_update_symlinks.py
python scripts/s75_update_symlinks.py --dry-run
python scripts/s75_update_symlinks.py --verbose
python scripts/s75_update_symlinks.py --models_dir /path/to/models --param_dir /path/to/param_results

Notes
-----
- Safe to run repeatedly.
- On macOS/Linux symlinks work by default; if not, we copy instead.
"""

from __future__ import annotations

import argparse
import os
import shutil
import sys
from pathlib import Path
from typing import Iterable, Optional, Tuple, List

# ---------- project-aware paths ----------
SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

# Prefer project-local common; shared as fallback
try:
    from common.paths import P
except Exception:
    class _PFallback:
        ROOT = PROJECT_ROOT
        MODELS_DIR = PROJECT_ROOT / "models"
        PARAM_RESULTS = PROJECT_ROOT / "param_results"
    P = _PFallback()

DEFAULT_MODELS_DIR = Path(getattr(P, "MODELS_DIR", P.ROOT / "models"))
DEFAULT_PARAM_DIR  = Path(getattr(P, "PARAM_RESULTS", P.ROOT / "param_results"))


def newest(glob_paths: Iterable[Path]) -> Optional[Path]:
    """Return the most recently modified file among iterable (files only)."""
    cand: List[Tuple[float, Path]] = []
    for p in glob_paths:
        if p.is_file():
            try:
                cand.append((p.stat().st_mtime, p))
            except FileNotFoundError:
                pass
    if not cand:
        return None
    cand.sort(key=lambda t: t[0], reverse=True)
    return cand[0][1]


def safe_replace(dst: Path, create_fn):
    """Atomically replace dst with an artifact created by create_fn(tmp)."""
    dst.parent.mkdir(parents=True, exist_ok=True)
    tmp = dst.with_suffix(dst.suffix + ".tmp")
    if tmp.exists() or tmp.is_symlink():
        tmp.unlink()
    create_fn(tmp)
    if dst.exists() or dst.is_symlink():
        dst.unlink()
    tmp.rename(dst)


def make_symlink(src: Path, link_path: Path):
    """Create a relative symlink link_path -> src (relative to link dir)."""
    rel = os.path.relpath(src, start=link_path.parent)
    os.symlink(rel, link_path)


def make_copy(src: Path, dst: Path):
    """Copy file src -> dst (metadata preserved)."""
    shutil.copy2(src, dst)


def ensure_latest(target: Optional[Path], link_path: Path, dry: bool, verbose: bool) -> str:
    """Ensure link_path points to target (symlink or copy)."""
    if target is None:
        return f"[MISS] No match for {link_path.name}"
    if dry:
        return f"[PLAN] {link_path} -> {target.name}"

    def _create(tmp_path: Path):
        try:
            make_symlink(target, tmp_path)
        except Exception:
            make_copy(target, tmp_path)

    safe_replace(link_path, _create)
    if verbose:
        try:
            if link_path.is_symlink():
                real = os.readlink(link_path)
                return f"[OK] symlink {link_path.name} -> {real}"
        except Exception:
            pass
    return f"[OK] {link_path.name} -> {target.name}"


def plan_patterns(models_dir: Path, param_dir: Path) -> list[tuple[Path, str, str]]:
    """
    Returns a list of (directory, glob_pattern, link_name) to process.
    Add or tweak patterns here as you add scripts.
    """
    md = models_dir
    pr = param_dir

    patterns: list[tuple[Path, str, str]] = [
        # ---- MODELS ----
        (md, "classifier_*.pkl",                        "classifier_latest.pkl"),
        (md, "classifier_feature_names_*.json",         "classifier_feature_names_latest.json"),
        (md, "classifier_feature_importances_base_*.csv", "classifier_feature_importances_base_latest.csv"),

        # Predictions per split
        (md, "classifier_train_predictions_*.csv",      "classifier_train_predictions_latest.csv"),
        (md, "classifier_val_predictions_*.csv",        "classifier_val_predictions_latest.csv"),
        (md, "classifier_test_predictions_*.csv",       "classifier_test_predictions_latest.csv"),

        # Permutation importance
        (md, "permutation_importance_*.csv",            "permutation_importance_latest.csv"),

        # Per-ticker split metrics
        (md, "per_ticker_metrics_train_*.csv",          "per_ticker_metrics_train_latest.csv"),
        (md, "per_ticker_metrics_val_*.csv",            "per_ticker_metrics_val_latest.csv"),
        (md, "per_ticker_metrics_test_*.csv",           "per_ticker_metrics_test_latest.csv"),
        (md, "per_ticker_metrics_ALL_*.csv",            "per_ticker_metrics_ALL_latest.csv"),

        # Reliability artifacts
        (md, "calibration_deciles.csv",                 "calibration_deciles_latest.csv"),
        (md, "threshold_sweep.csv",                     "threshold_sweep_latest.csv"),
        (md, "metrics_per_ticker.csv",                  "metrics_per_ticker_latest.csv"),
        (md, "metrics_per_regime.csv",                  "metrics_per_regime_latest.csv"),
        (md, "backtest_daily_topK.csv",                 "backtest_daily_topK_latest.csv"),

        # ---- PARAM_RESULTS ----
        (pr, "s70_results_with_guidance_*.csv",         "s70_results_with_guidance_latest.csv"),
        (pr, "s70_results_with_guidance_*.parquet",     "s70_results_with_guidance_latest.parquet"),
        (pr, "s70_split_metrics_summary_*.csv",         "s70_split_metrics_summary_latest.csv"),
        (pr, "s70b_per_ticker_thresholds_*.csv",        "s70b_per_ticker_thresholds_latest.csv"),
        (pr, "s70b_overall_summary_*.csv",              "s70b_overall_summary_latest.csv"),
        (pr, "per_ticker_quality.csv",                  "per_ticker_quality_latest.csv"),

        # Final table + operator cuts
        (pr, "final_signals_*.csv",                     "final_signals_latest.csv"),
        (pr, "operator_ml_picks_*.csv",                 "operator_ml_picks_latest.csv"),
        (pr, "operator_counts_by_ticker_*.csv",         "operator_counts_by_ticker_latest.csv"),

        # Live + operator/decision boards
        (pr, "live_signals_*.csv",                   "live_signals_latest.csv"),
        (pr, "operator_today_ML_*.csv",              "operator_today_ML_latest.csv"),
        (pr, "final_decisions_*.csv",                "final_decisions_latest.csv"),
        (pr, "final_decisions_pretty_*.csv",         "final_decisions_pretty_latest.csv"),

        # s68 split meta
        (pr, "s68_split_report.csv",                    "s68_split_report_latest.csv"),
        (pr, "s68_unique_key_counts.csv",               "s68_unique_key_counts_latest.csv"),
    ]
    return patterns


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry-run", action="store_true", help="Show what would be updated")
    ap.add_argument("--verbose", action="store_true", help="Print extra details")
    ap.add_argument("--models_dir", default=str(DEFAULT_MODELS_DIR), help="Override models directory")
    ap.add_argument("--param_dir",  default=str(DEFAULT_PARAM_DIR),  help="Override param_results directory")
    args = ap.parse_args()

    models_dir = Path(args.models_dir)
    param_dir  = Path(args.param_dir)

    patterns = plan_patterns(models_dir, param_dir)
    results: list[str] = []

    for base_dir, glob_pat, link_name in patterns:
        base_dir = Path(base_dir)
        link_path = base_dir / link_name
        matches = list(base_dir.glob(glob_pat))
        latest = newest(matches)
        results.append(ensure_latest(latest, link_path, dry=args.dry_run, verbose=args.verbose))

    print("\n".join(results))


if __name__ == "__main__":
    main()