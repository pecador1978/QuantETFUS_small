#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
s76_score_live_universe.py
Score "today/now" for each ticker using the latest calibrated classifier bundle.

Defaults:
- Uses per-ticker thresholds (from s70b_per_ticker_thresholds_*.csv) when available.
- Falls back to a global threshold read from the latest classifier_metrics_*.json
  (or --decision-threshold CLI override, else 0.50).

Outputs:
- param_results/live_signals_<ts>.csv
- param_results/operator_today_ML_<ts>.csv

Usage
-----
python scripts/s76_score_live_universe.py
    [--decision-threshold 0.50]        # optional global override
    [--force-global]                   # ignore per-ticker thresholds
    [--limit 9999]                     # debug: only first N tickers
"""

from __future__ import annotations
from pathlib import Path
from datetime import datetime, timezone
import sys
import json
import numpy as np
import pandas as pd
import joblib

# ---------- project paths ----------
SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
from common.paths import P  # ROOT, DATA_ENRICHED, PARAM_RESULTS, etc.


# ---------- helpers ----------
def _ts() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%d_%H%M")


def _latest(path: Path, pattern: str) -> Path | None:
    cands = sorted(path.glob(pattern))
    return cands[-1] if cands else None


def _safe_predict_proba(model, X):
    if hasattr(model, "predict_proba"):
        return model.predict_proba(X)[:, 1]
    if hasattr(model, "decision_function"):
        s = model.decision_function(X)
        return 1.0 / (1.0 + np.exp(-s))
    # fallback: predict 0/1
    return model.predict(X).astype(float)


def _load_whitelist() -> pd.DataFrame | None:
    wl = P.ROOT / "param_results" / "s70_whitelist.csv"
    if wl.exists():
        try:
            df = pd.read_csv(wl)
            if "ml_usable" not in df.columns:
                df["ml_usable"] = True
            return df[["ticker", "ml_usable"]].drop_duplicates()
        except Exception:
            pass
    return None


def _load_quality() -> pd.DataFrame | None:
    q = P.ROOT / "param_results" / "per_ticker_quality.csv"
    if q.exists():
        try:
            df = pd.read_csv(q)
            # normalize
            cols = {c.lower(): c for c in df.columns}
            cn = {c: c.lower() for c in df.columns}
            df = df.rename(columns=cn)
            keep = [c for c in df.columns if c in {"ticker", "quality"}]
            df = df[keep].copy()
            df["quality"] = df["quality"].astype(str)
            return df.rename(columns={"ticker": "ticker", "quality": "quality"})
        except Exception:
            pass
    return None


def _guidance_for(q: str) -> str:
    mapping = {
        "High Confidence": "Trust both signal + ML projection. Trade with confidence.",
        "Medium (OK)":     "Signal + ML OK, but expect higher variance. Use smaller size.",
        "Risky":           "Signal only. Ignore ML projection. Rely on chart reading.",
        "No Go":           "Signal only. Manual confirmation required."
    }
    return mapping.get(q, "")


def _load_per_ticker_thresholds() -> pd.DataFrame | None:
    """
    Produced by s70b_make_per_ticker_thresholds.py:
      param_results/s70b_per_ticker_thresholds_*.csv
    Must contain: ['ticker','thr_star'].
    """
    pr = _latest(P.ROOT / "param_results", "s70b_per_ticker_thresholds_*.csv")
    if pr and pr.exists():
        try:
            df = pd.read_csv(pr)
            if {"ticker", "thr_star"}.issubset(df.columns):
                out = df[["ticker", "thr_star"]].dropna().copy()
                out["ticker"] = out["ticker"].astype(str)
                return out
        except Exception:
            pass
    return None


def _load_global_thr_from_metrics(default_fallback: float = 0.50) -> float:
    """
    Read the most recent models/classifier_metrics_*.json and return decision_threshold.
    """
    p = _latest(P.ROOT / "models", "classifier_metrics_*.json")
    if not p:
        print(f"[INFO] No metrics json; global threshold = {default_fallback:.2f}")
        return float(default_fallback)
    try:
        d = json.loads(p.read_text())
        t = float(d.get("decision_threshold", default_fallback))
        print(f"[INFO] Global threshold (from metrics) → {t:.2f}")
        return t
    except Exception:
        print(f"[WARN] Could not parse {p.name}; global threshold = {default_fallback:.2f}")
        return float(default_fallback)


# ---------- main ----------
def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--decision-threshold", type=float, default=None,
                    help="Global threshold override. If omitted, read from latest metrics, else 0.50.")
    ap.add_argument("--force-global", action="store_true",
                    help="Ignore per-ticker thresholds; use global threshold for all tickers.")
    ap.add_argument("--limit", type=int, default=None,
                    help="Debug: only score first N tickers.")
    args = ap.parse_args()

    # 1) Load latest model bundle
    bundle_path = _latest(P.ROOT / "models", "classifier_*.pkl")
    if not bundle_path:
        raise SystemExit("[ERR] No model bundle found in models/classifier_*.pkl. Run s70 first.")
    bundle = joblib.load(bundle_path)
    pre    = bundle["pre"]
    model  = bundle["model"]
    num_cols = list(bundle.get("num_cols", []))
    cat_cols = list(bundle.get("cat_cols", []))
    raw_cols_needed = num_cols + cat_cols

    # 2) Discover tickers via 30m enriched cache
    m30_dir = P.ROOT / "data_enriched" / "30min"
    if not m30_dir.exists():
        raise SystemExit(f"[ERR] {m30_dir} not found. Run the 30m enrichment first.")
    parquets = sorted(m30_dir.glob("*.parquet"))
    if not parquets:
        raise SystemExit(f"[ERR] No parquet files in {m30_dir}.")
    if args.limit:
        parquets = parquets[: args.limit]

    # 3) Load optional artifacts
    whitelist = _load_whitelist()       # s70_whitelist.csv
    quality   = _load_quality()         # per_ticker_quality.csv
    thr_df    = None if args.force_global else _load_per_ticker_thresholds()

    # global threshold: CLI > metrics.json > 0.50
    gthr = float(args.decision_threshold) if args.decision_threshold is not None else _load_global_thr_from_metrics(0.50)

    # 4) Build latest-row dataframe across tickers
    rows = []
    missing_cols = set()
    for pq in parquets:
        ticker = pq.stem
        try:
            dfp = pd.read_parquet(pq)
            if dfp.empty:
                continue
            last = dfp.iloc[[-1]].copy()
            last["ticker"] = str(ticker)

            # ensure trained columns exist/order
            for m in (c for c in raw_cols_needed if c not in last.columns):
                if m in cat_cols:
                    last[m] = "__NA__"
                else:
                    last[m] = np.nan
                    missing_cols.add(m)
            last = last[raw_cols_needed].copy()
            for c in cat_cols:
                last[c] = last[c].astype("string").fillna("__NA__")

            rows.append(last)
        except Exception as e:
            print(f"[WARN] Failed to read {ticker}: {e}")

    if not rows:
        raise SystemExit("[ERR] No rows to score.")
    X_raw = pd.concat(rows, ignore_index=True)

    # 5) Predict proba / label
    Z = pre.transform(X_raw)
    proba = _safe_predict_proba(model, Z)

    if thr_df is not None and not thr_df.empty:
        # per-ticker with fallback to global
        df = X_raw.copy()
        df["ticker"] = df["ticker"].astype(str)
        df["y_prob"] = proba
        df = df.merge(thr_df, on="ticker", how="left")
        df["thr_used"] = df["thr_star"].fillna(gthr).astype(float)
        df["decision_rule"] = np.where(df["thr_star"].notna(), "per_ticker", "global_fallback")
        df["y_pred"] = (df["y_prob"] >= df["thr_used"]).astype(int)
    else:
        # pure global
        df = X_raw.copy()
        df["y_prob"] = proba
        df["thr_used"] = float(gthr)
        df["decision_rule"] = "global"
        df["y_pred"] = (df["y_prob"] >= df["thr_used"]).astype(int)

    # 6) Merge quality + whitelist and set ml_usable + guidance
    if quality is not None:
        df = df.merge(quality, on="ticker", how="left")
    else:
        df["quality"] = pd.NA

    if whitelist is not None:
        df = df.merge(whitelist, on="ticker", how="left")
        df["ml_usable"] = df["ml_usable"].fillna(False).astype(bool)
    else:
        df["ml_usable"] = True

    df["action_guidance"] = df["quality"].map(_guidance_for)

    # Optional: original 'signal' not present in live source; keep placeholder
    if "signal" not in df.columns:
        df["signal"] = pd.NA

    # 7) Save outputs
    out_dir = P.ROOT / "param_results"
    out_dir.mkdir(parents=True, exist_ok=True)
    ts = _ts()

    show = [c for c in [
        "ticker","y_prob","y_pred","thr_used","decision_rule","ml_usable","quality","action_guidance"
    ] if c in df.columns]
    live_csv = out_dir / f"live_signals_{ts}.csv"
    df_out = df[show].copy()
    df_out.to_csv(live_csv, index=False)
    print(f"[OK] Live signals → {live_csv}")

    # shortlist: ML usable & predicted 1
    short = df_out[(df_out["ml_usable"] == True) & (df_out["y_pred"] == 1)].copy()
    short = short.sort_values(by="y_prob", ascending=False)
    op_csv = out_dir / f"operator_today_ML_{ts}.csv"
    short.to_csv(op_csv, index=False)
    print(f"[OK] Operator shortlist → {op_csv}  (rows={len(short)})")

    # 8) Console hints
    if "decision_rule" in df_out.columns:
        print("\n[decision_rule coverage]")
        try:
            print(df_out["decision_rule"].value_counts(dropna=False).to_string())
        except Exception:
            pass

    if missing_cols:
        ex = list(sorted(missing_cols))[:10]
        print(f"\n[NOTE] {len(missing_cols)} trained columns were missing from live rows (filled NaN).")
        print(f"       e.g.: {ex} ...")


if __name__ == "__main__":
    main()