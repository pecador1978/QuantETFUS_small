#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
s51_liquidity_sweep_engine.py — Liquidity-sweep entries, ATR stop, Fibonacci exits (clone-friendly)

Concept
-------
- Entry (LONG): market sweeps below the prior N-day swing low (stop-hunt), then reclaims it.
  We detect: (i) a 30m bar's low < prior_swing_low, and (ii) a later 30m bar closes back above
  (prior_swing_low * (1 + reclaim_buffer_pct)) with optional daily filters (EMA/RSI).
- Protective stop: ATR-based (e.g., entry - atr_stop_mult * ATR).
- Profit-taking: Fibonacci targets from latest swing leg (extension or retracement).
  Partial exits follow weights that auto-normalize to sum to 1.0.

Clone-friendly
--------------
- Auto-resolves TARGET_BUCKET and MARKET_TZ/OPEN/CLOSE from env -> settings -> repo layout.
- Reads 30m from: P.DATA_RAW/<TARGET_BUCKET>/30min/{TICKER}_30min_raw.csv (or *_30min.csv)
- Reads daily from: P.DATA_RAW/<TARGET_BUCKET>/daily/{TICKER}_daily_raw.csv (or *_daily.csv)

Outputs
-------
- P.ROOT/backtest_results_30m/s51_trades_<ts>.csv
- P.ROOT/backtest_results_30m/s51_equity_curve_<ts>.csv
- P.ROOT/backtest_results_30m/s51_summary_<ts>.csv
- P.ROOT/backtest_results_30m/s51_summary_by_ticker_<ts>.csv
- P.ROOT/backtest_results_30m/s51_summary_capital_by_ticker_<ts>.csv
"""

from __future__ import annotations

import os
import sys
import argparse
import warnings
from datetime import datetime, timezone, time as dt_time, timedelta
from pathlib import Path

import numpy as np
import pandas as pd
from ta.trend import EMAIndicator
from ta.momentum import RSIIndicator

# ---- bootstrap project import path ----
SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

# ---- project-aware paths ----
from common.paths import P  # dynamic project paths

# ---- clone-friendly detection ----
def _resolve_bucket() -> str:
    # 1) ENV
    env_b = os.environ.get("TARGET_BUCKET", "").strip()
    if env_b:
        return env_b
    # 2) settings
    try:
        from common.settings import TARGET_BUCKET as SBUCKET  # type: ignore
        if SBUCKET:
            return str(SBUCKET)
    except Exception:
        pass
    # 3) detect US
    if (P.DATA_RAW / "targeted_ETFs_US" / "30min").exists() or (P.DATA_RAW / "targeted_ETFs_US" / "daily").exists():
        return "targeted_ETFs_US"
    # 4) EU fallback
    return "targeted_ETFs"

def _resolve_session(bucket: str) -> tuple[str, str, str]:
    # 1) ENV
    tz   = os.environ.get("MARKET_TZ", "")
    opn  = os.environ.get("MARKET_OPEN", "")
    cls  = os.environ.get("MARKET_CLOSE", "")
    if tz and opn and cls:
        return tz, opn, cls
    # 2) settings
    try:
        from common.settings import MARKET_TZ as STZ, MARKET_OPEN as SOPEN, MARKET_CLOSE as SCLOSE  # type: ignore
        if all([STZ, SOPEN, SCLOSE]):
            return str(STZ), str(SOPEN), str(SCLOSE)
    except Exception:
        pass
    # 3) repo/bucket heuristic
    repo_us = PROJECT_ROOT.name.endswith("US") or bucket == "targeted_ETFs_US"
    if repo_us:
        return "Europe/London", "08:00", "16:30"
    # 4) EU default
    return "Europe/Madrid", "09:00", "17:30"

TARGET_BUCKET = _resolve_bucket()
MARKET_TZ, MARKET_OPEN, MARKET_CLOSE = _resolve_session(TARGET_BUCKET)

ROOT = P.ROOT
IN30 = P.DATA_RAW / TARGET_BUCKET / "30min"
IN1D = P.DATA_RAW / TARGET_BUCKET / "daily"
OUT  = ROOT / "backtest_results_30m"
OUT.mkdir(parents=True, exist_ok=True)

print(f"[s51] TARGET_BUCKET={TARGET_BUCKET} | MARKET_TZ={MARKET_TZ} "
      f"| MARKET_OPEN={MARKET_OPEN} | MARKET_CLOSE={MARKET_CLOSE}")
print(f"[s51] IN30={IN30}")
print(f"[s51] IN1D={IN1D}")

# ---------------- helpers ----------------
def _filter_session_local(df_utc: pd.DataFrame) -> pd.DataFrame:
    """Keep bars whose local time is within [MARKET_OPEN, MARKET_CLOSE]."""
    if df_utc.empty:
        return df_utc
    df = df_utc.copy()
    local = df["datetime"].dt.tz_convert(MARKET_TZ)
    t = local.dt.time
    hh_o, mm_o = map(int, str(MARKET_OPEN).split(":"))
    hh_c, mm_c = map(int, str(MARKET_CLOSE).split(":"))
    mask = (t >= dt_time(hh_o, mm_o)) & (t <= dt_time(hh_c, mm_c))
    return df.loc[mask].reset_index(drop=True)

def _load_30min_any(ticker: str) -> pd.DataFrame:
    f_raw = IN30 / f"{ticker}_30min_raw.csv"
    f_alt = IN30 / f"{ticker}_30min.csv"
    f = f_raw if f_raw.exists() else f_alt
    if not f.exists():
        raise FileNotFoundError(f"30m not found for {ticker} ({f_raw} / {f_alt})")
    df = pd.read_csv(f)
    cols = [c.strip().lower().replace(" ", "") for c in df.columns]
    df.columns = cols
    dtcol = next((c for c in df.columns if "date" in c or "time" in c), None)
    if not dtcol:
        raise ValueError(f"No datetime column in {f}")
    df["datetime"] = pd.to_datetime(df[dtcol], utc=True, errors="coerce")
    for c in ("open","high","low","close"):
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")
    df = df.dropna(subset=["datetime","close"])
    df = _filter_session_local(df)
    df["date"] = df["datetime"].dt.tz_convert(MARKET_TZ).dt.date
    return df.sort_values("datetime").reset_index(drop=True)

def _load_daily_any(ticker: str) -> pd.DataFrame:
    f_raw = IN1D / f"{ticker}_daily_raw.csv"
    f_alt = IN1D / f"{ticker}_daily.csv"
    f = f_raw if f_raw.exists() else f_alt
    if not f.exists():
        raise FileNotFoundError(f"Daily not found for {ticker} ({f_raw} / {f_alt})")
    dfd = pd.read_csv(f)
    cols = [c.strip().lower().replace(" ", "") for c in dfd.columns]
    dfd.columns = cols
    date_col = "date" if "date" in dfd.columns else "datetime"
    dfd["datetime"] = pd.to_datetime(dfd[date_col], utc=True, errors="coerce")
    dfd["datetime_local"] = dfd["datetime"].dt.tz_convert(MARKET_TZ).dt.tz_localize(None)
    dfd["date"] = dfd["datetime_local"].dt.date
    for c in ("open","high","low","close"):
        if c in dfd.columns:
            dfd[c] = pd.to_numeric(dfd[c], errors="coerce")
    dfd = dfd.dropna(subset=["date","close"]).sort_values("datetime_local")
    # Daily indicators for filters/stop sizing
    dfd["ATR"] = _atr_manual(dfd, 14)
    dfd["ema5"]  = EMAIndicator(dfd["close"], window=5).ema_indicator()
    dfd["ema20"] = EMAIndicator(dfd["close"], window=20).ema_indicator()
    dfd["ema44"] = EMAIndicator(dfd["close"], window=44).ema_indicator()
    dfd["RSI"] = RSIIndicator(dfd["close"], window=14).rsi()
    return dfd.reset_index(drop=True)

def _atr_manual(dfd: pd.DataFrame, n: int = 14) -> pd.Series:
    dfd = dfd.copy()
    dfd["H-L"]  = dfd["high"] - dfd["low"]
    dfd["H-PC"] = (dfd["high"] - dfd["close"].shift()).abs()
    dfd["L-PC"] = (dfd["low"] - dfd["close"].shift()).abs()
    dfd["TR"]   = dfd[["H-L","H-PC","L-PC"]].max(axis=1)
    return dfd["TR"].rolling(window=n, min_periods=1).mean()

def apply_costs(px: float, side: str, slip_bps: float) -> float:
    if pd.isna(px) or px <= 0:
        return px
    adj = (slip_bps / 10000.0)
    return px * (1.0 + adj) if side == "buy" else px * (1.0 - adj)

def _parse_float_list(s: str) -> list[float]:
    vals = []
    for x in str(s).split(","):
        x = x.strip()
        if not x:
            continue
        try:
            vals.append(float(x))
        except Exception:
            pass
    return vals

def _normalize_weights(ws: list[float], n_levels: int) -> list[float]:
    if not ws:
        ws = [1.0]
    if len(ws) < n_levels:
        ws = ws + [0.0]*(n_levels-len(ws))
    ws = ws[:n_levels]
    s = sum(max(w,0.0) for w in ws)
    if s <= 0:
        return [1.0] + [0.0]*(n_levels-1)
    return [max(w,0.0)/s for w in ws]

def _latest_swing_leg(dfd: pd.DataFrame, lookback: int) -> tuple[float,float]:
    """Return (swing_low, swing_high) within last lookback+1 days (completed window)."""
    d = dfd.tail(lookback+1).copy()
    if d.empty:
        return (np.nan, np.nan)
    return float(d["low"].min()), float(d["high"].max())

def _fib_targets(entry: float, side: str, swing_lo: float, swing_hi: float,
                 levels: list[float], mode: str) -> list[float]:
    if any(pd.isna([entry, swing_lo, swing_hi])):
        return []
    leg = max(swing_hi - swing_lo, 1e-9)
    if mode == "retracement":
        leg *= 0.5
    tgs = []
    if side == "long":
        for f in levels:
            tgs.append(entry + f * leg)
    else:
        for f in levels:
            tgs.append(entry - f * leg)
    return tgs

# ---------------- core (long-only sweeps) ----------------
def backtest_ticker(ticker: str, params: dict) -> pd.DataFrame:
    verbose = bool(params.get("verbose", False))
    if not verbose:
        warnings.filterwarnings("ignore", category=FutureWarning)

    # load data
    df30 = _load_30min_any(ticker)
    dfd  = _load_daily_any(ticker)

    # windowing
    start = params.get("start_date")
    end   = params.get("end_date")
    if start:
        df30 = df30[df30["datetime"] >= pd.to_datetime(start, utc=True, errors="coerce")]
        dfd  = dfd[dfd["date"] >= pd.to_datetime(start).date()]
    if end:
        df30 = df30[df30["datetime"] <= pd.to_datetime(end, utc=True, errors="coerce")]
        dfd  = dfd[dfd["date"] <= pd.to_datetime(end).date()]

    if df30.empty or dfd.empty:
        return pd.DataFrame(columns=["ticker","entry_dt","exit_dt","entry_px","exit_px","qty","ret_pct","fee_eur","leg"])

    # intraday EMA for context (can help filter trash)
    df30["EMA275"] = EMAIndicator(df30["close"], window=275).ema_indicator()

    # daily filters
    ema_align = bool(params.get("ema_alignment_filter", True))
    rsi_filter = bool(params.get("rsi_filter_enabled", True))
    rsi_thr = float(params.get("rsi_entry_threshold", 60.0))
    entry_buffer_pct = float(params.get("entry_buffer_pct", 0.0)) / 100.0
    reclaim_buffer_pct = float(params.get("reclaim_buffer_pct", 0.05)) / 100.0

    # ATR & stop
    atr_len = int(params.get("atr_length", 14))
    atr_mult = float(params.get("atr_stop_mult", 1.0))

    # Fib exits
    fib_mode = str(params.get("fib_mode", "extension"))
    fib_lvls = _parse_float_list(params.get("fib_levels", "0.618,1.0,1.272,1.618"))
    fib_wraw = _parse_float_list(params.get("fib_weights", "0.6,0.3,0.1"))
    fib_lookback = int(params.get("fib_swing_lookback", 10))
    fib_weights = _normalize_weights(fib_wraw, len(fib_lvls))

    # cooldown
    cooldown_days = int(params.get("cooldown_days", 0))
    next_allowed_date = None

    # costs
    fees_fixed = float(params.get("fees_fixed", 3.0))
    slip_bps   = float(params.get("slip_bps", 0.0))

    # precompute per-day refs
    daily_ref = dfd.set_index("date")[["ATR","ema5","ema20","ema44","RSI","close"]]
    # yesterday swing low for sweep (prior swing, not including today)
    dfd["swing_low_N"] = dfd["low"].rolling(fib_lookback, min_periods=1).min().shift(1)
    dfd["swing_high_N"] = dfd["high"].rolling(fib_lookback, min_periods=1).max().shift(1)
    day_refs = dfd.set_index("date")[["swing_low_N","swing_high_N"]]

    records = []
    open_positions = []  # each: dict(entry_dt, entry_px, qty_remaining, stop, fib_targets, fib_weights, open_date)

    # sweep + reclaim detection per day
    for d, daybars in df30.groupby("date", sort=True):
        if next_allowed_date is not None and d < next_allowed_date:
            continue
        if d not in day_refs.index or d not in daily_ref.index:
            continue

        # daily filters
        ema_ok = True
        rsi_ok = True
        if ema_align:
            rowd = daily_ref.loc[d]
            ema_ok = (rowd["ema5"] > rowd["ema20"]) and (rowd["ema20"] > rowd["ema44"])
        if rsi_filter:
            rowd = daily_ref.loc[d]
            rsi_ok = rowd["RSI"] < rsi_thr

        if not (ema_ok and rsi_ok):
            # still need to manage existing open positions (from earlier day)
            pass

        prior_low = day_refs.loc[d, "swing_low_N"]
        prior_high = day_refs.loc[d, "swing_high_N"]
        if pd.isna(prior_low) or pd.isna(prior_high):
            # manage open only
            prior_low = None

        # detect sweep below prior_low then reclaim
        swept = False
        reclaim_trigger = None

        if prior_low is not None:
            # any 30m bar makes a lower low than prior_low?
            min_low = float(daybars["low"].min())
            if min_low < float(prior_low):
                swept = True
                # find first bar that CLoses back above prior_low * (1+reclaim_buffer)
                reclaim_line = float(prior_low) * (1.0 + reclaim_buffer_pct)
                post = daybars[daybars["close"] >= reclaim_line]
                if not post.empty:
                    reclaim_trigger = post.iloc[0]

        # ENTRY (long): need swept + reclaim + daily filters (if enabled)
        if swept and reclaim_trigger is not None and (ema_ok and rsi_ok):
            entry_bar = reclaim_trigger
            entry_raw = float(entry_bar["close"])
            entry = apply_costs(entry_raw, "buy", slip_bps)

            # stop via ATR
            atr = float(daily_ref.loc[d, "ATR"])
            stop = entry_raw - (atr_mult * max(atr, 1e-9))

            # swing anchors and fib targets
            swing_lo, swing_hi = _latest_swing_leg(dfd[dfd["date"] <= d], fib_lookback)
            targets = _fib_targets(entry_raw, "long", swing_lo, swing_hi, fib_lvls, fib_mode)
            weights = _normalize_weights(fib_weights, len(targets)) if targets else [1.0]

            # immediate intraday fills (targets hit later in the same day)
            remaining = 1.0
            entry_fee_pending = True
            later = daybars[daybars["datetime"] >= entry_bar["datetime"]]

            if targets:
                for tg, w in zip(targets, weights):
                    if remaining <= 1e-12:
                        break
                    # check same-bar or later intraday bars: high >= tg
                    hit = later[later["high"] >= tg]
                    if not hit.empty:
                        hitbar = hit.iloc[0]
                        qty = min(w, remaining)
                        exit_px = apply_costs(tg, "sell", slip_bps)
                        ret = (exit_px / entry) - 1.0
                        fee = fees_fixed * qty
                        if entry_fee_pending:
                            fee += fees_fixed * qty
                            entry_fee_pending = False
                        records.append({
                            "ticker": ticker,
                            "entry_dt": entry_bar["datetime"],
                            "exit_dt": hitbar["datetime"],
                            "entry_px": entry,
                            "exit_px": exit_px,
                            "qty": qty,
                            "ret_pct": ret,
                            "fee_eur": fee,
                            "leg": f"FIB_{tg:.3f}",
                        })
                        remaining -= qty

            # if anything remains → carry to future bars
            if remaining > 1e-12:
                open_positions.append({
                    "ticker": ticker,
                    "entry_dt": entry_bar["datetime"],
                    "entry_px": entry,
                    "qty": remaining,
                    "stop": stop,
                    "open_date": d,
                    "targets": targets,
                    "weights": _normalize_weights(weights, len(targets)) if targets else [1.0],
                    "fees_pending": fees_fixed * remaining if entry_fee_pending else 0.0
                })
                if cooldown_days > 0:
                    next_allowed_date = d + timedelta(days=cooldown_days)
        # else: no new entries that day

        # --------- manage open positions through today's remaining bars ---------
        if open_positions:
            new_open = []
            for pos in open_positions:
                qty = float(pos["qty"])
                if qty <= 1e-12:
                    continue

                # scan through today's bars AFTER today's open (and after entry if same day)
                scan = daybars[daybars["datetime"] >
                               (pos["entry_dt"] if pos["open_date"] == d else daybars["datetime"].min())]

                closed = False
                for _, b in scan.iterrows():
                    # stop first
                    if b["low"] <= pos["stop"]:
                        exit_px = apply_costs(pos["stop"], "sell", slip_bps)
                        ret = (exit_px / pos["entry_px"]) - 1.0
                        records.append({
                            "ticker": ticker,
                            "entry_dt": pos["entry_dt"],
                            "exit_dt": b["datetime"],
                            "entry_px": pos["entry_px"],
                            "exit_px": exit_px,
                            "qty": qty,
                            "ret_pct": ret,
                            "fee_eur": pos.get("fees_pending", 0.0),
                            "leg": "StopExit"
                        })
                        closed = True
                        break

                    # fib targets (in order)
                    tgs = pos.get("targets", [])
                    wts = pos.get("weights", [])
                    if tgs:
                        for i, (tg, w) in enumerate(zip(tgs, wts)):
                            if w <= 0 or qty <= 1e-12:
                                continue
                            if b["high"] >= tg:
                                q_leg = min(w, qty)
                                exit_px = apply_costs(tg, "sell", slip_bps)
                                ret = (exit_px / pos["entry_px"]) - 1.0
                                records.append({
                                    "ticker": ticker,
                                    "entry_dt": pos["entry_dt"],
                                    "exit_dt": b["datetime"],
                                    "entry_px": pos["entry_px"],
                                    "exit_px": exit_px,
                                    "qty": q_leg,
                                    "ret_pct": ret,
                                    "fee_eur": 0.0,
                                    "leg": f"FIB_{i+1}"
                                })
                                qty -= q_leg
                        if qty <= 1e-12:
                            closed = True
                            break
                # end intraday loop

                if not closed:
                    # keep it open to next day
                    pos["qty"] = qty
                    pos["fees_pending"] = 0.0  # fees already charged
                    new_open.append(pos)

            open_positions = new_open

    # --------- flush any still-open positions at the very last available bar ---------
    if open_positions:
        # find last available 30m bar across the dataset
        lastbar = df30.tail(1).iloc[0]
        new_records = []
        for pos in open_positions:
            qty = float(pos["qty"])
            if qty <= 1e-12:
                continue
            exit_px = float(lastbar["close"])
            ret = (exit_px / pos["entry_px"]) - 1.0
            new_records.append({
                "ticker": ticker,
                "entry_dt": pos["entry_dt"],
                "exit_dt": lastbar["datetime"],
                "entry_px": pos["entry_px"],
                "exit_px": exit_px,
                "qty": qty,
                "ret_pct": ret,
                "fee_eur": 0.0,
                "leg": "EOD"
            })
        if new_records:
            records.extend(new_records)

    if not records:
        return pd.DataFrame(columns=["ticker","entry_dt","exit_dt","entry_px","exit_px","qty","ret_pct","fee_eur","leg"])
    return pd.DataFrame(records).sort_values("exit_dt").reset_index(drop=True)

# ---------------- summaries ----------------
def summarize_fills(trades: pd.DataFrame):
    if trades is None or trades.empty:
        agg = pd.DataFrame([{
            "tickers": 0, "fills": 0, "win_rate": 0.0, "avg_ret": 0.0,
            "median_ret": 0.0, "avg_bars": 0.0, "gross_ret": 0.0
        }])
        by_tkr = pd.DataFrame(columns=["ticker","fills","mean","median"])
        return agg, by_tkr

    win = (trades["ret_pct"] > 0).mean()
    avg = trades["ret_pct"].mean()
    med = trades["ret_pct"].median()
    bars = max(0.0, (trades["exit_dt"] - trades["entry_dt"]).dt.total_seconds().mean() / (30*60))
    gross = (trades["ret_pct"] * trades["qty"]).sum()

    by_tkr = trades.groupby("ticker", as_index=False).apply(
        lambda g: pd.Series({
            "fills": len(g),
            "mean": (g["ret_pct"] * g["qty"]).sum() / max(g["qty"].sum(), 1e-12),
            "median": g["ret_pct"].median()
        }),
        include_groups=False
    ).reset_index(drop=True)

    agg = pd.DataFrame([{
        "tickers": trades["ticker"].nunique(),
        "fills": len(trades),
        "win_rate": win,
        "avg_ret": avg,
        "median_ret": med,
        "avg_bars": bars,
        "gross_ret": gross
    }])
    return agg, by_tkr

def summarize_trades_per_ticker(trades: pd.DataFrame, unit_capital: float) -> pd.DataFrame:
    if trades is None or trades.empty:
        return pd.DataFrame(columns=["ticker","initial_capital","win_rate","total_return","num_trades","end_capital"])
    tr = trades.copy()
    tr["trade_id"] = tr["ticker"].astype(str) + "|" + tr["entry_dt"].astype(str)
    trade_rows = tr.groupby(["ticker","trade_id"], as_index=False).apply(
        lambda g: pd.Series({
            "entry_dt": g["entry_dt"].iloc[0],
            "exit_dt": g["exit_dt"].max(),
            "ret_trade": (g["ret_pct"] * g["qty"]).sum()
                         - (g["fee_eur"].sum() / unit_capital if "fee_eur" in g else 0.0)
        }),
        include_groups=False
    ).reset_index(drop=True)

    out = []
    for tkr, g in trade_rows.sort_values("exit_dt").groupby("ticker"):
        cap = unit_capital
        wins = 0
        for _, r in g.iterrows():
            if r["ret_trade"] > 0:
                wins += 1
            cap *= (1.0 + r["ret_trade"])
        out.append({
            "ticker": tkr,
            "initial_capital": unit_capital,
            "win_rate": wins / max(len(g), 1),
            "total_return": (cap / unit_capital) - 1.0,
            "num_trades": len(g),
            "end_capital": cap
        })
    return pd.DataFrame(out)

def equity_curve(trades: pd.DataFrame, unit_capital: float) -> pd.DataFrame:
    if trades is None or trades.empty:
        return pd.DataFrame(columns=["date","equity"])
    tr = trades.sort_values("exit_dt").copy()
    fees = tr["fee_eur"] if "fee_eur" in tr.columns else 0.0
    tr["pnl"] = (tr["ret_pct"] * tr["qty"] * unit_capital) - fees
    tr["equity"] = unit_capital + tr["pnl"].cumsum()
    return tr[["exit_dt","equity"]].rename(columns={"exit_dt": "date"})

# ---------------- main ----------------
def main():
    ap = argparse.ArgumentParser()
    # window
    ap.add_argument("--start_date", type=str, default=None)
    ap.add_argument("--end_date", type=str, default=None)
    # daily filters
    ap.add_argument("--ema_alignment_filter", action="store_true", default=True)
    ap.add_argument("--rsi_filter_enabled", action="store_true", default=True)
    ap.add_argument("--rsi_entry_threshold", type=float, default=60.0)
    # entry buffers
    ap.add_argument("--entry_buffer_pct", type=float, default=0.0, help="extra % above EMA275 for 30m context (not enforced as filter)")
    ap.add_argument("--reclaim_buffer_pct", type=float, default=0.05, help="percent above prior swing for reclaim trigger")
    # ATR stop
    ap.add_argument("--atr_length", type=int, default=14)
    ap.add_argument("--atr_stop_mult", type=float, default=1.0)
    # Fibonacci exits
    ap.add_argument("--fib_mode", default="extension", choices=["off","extension","retracement"])
    ap.add_argument("--fib_levels", default="0.618,1.0")
    ap.add_argument("--fib_weights", default="0.5, 0.5")
    ap.add_argument("--fib_swing_lookback", type=int, default=10)
    # costs/capital
    ap.add_argument("--fees_fixed", type=float, default=3.0)
    ap.add_argument("--slip_bps", type=float, default=0.0)
    ap.add_argument("--unit_capital", type=float, default=10000.0)
    # behavior
    ap.add_argument("--cooldown_days", type=int, default=0)
    ap.add_argument("--verbose", action="store_true", default=False)
    args = ap.parse_args()

    params = vars(args)

    print(f"[s51] Scanning 30m inputs: {IN30}")
    files = sorted(list(IN30.glob("*_30min_raw.csv")) + list(IN30.glob("*_30min.csv")))
    print(f"[s51] Found {len(files)} file(s)")
    if not files:
        raise SystemExit(f"No 30m inputs in {IN30} — expected *_30min_raw.csv or *_30min.csv")

    all_trades = []
    for f in files:
        tkr = f.name.replace("_30min_raw.csv","").replace("_30min.csv","")
        try:
            tr = backtest_ticker(tkr, params)
            if tr is not None and not tr.empty:
                all_trades.append(tr)
        except Exception as e:
            print(f"[WARN] {tkr}: {e}")

    if not all_trades:
        raise SystemExit("No trades generated.")

    trades = pd.concat(all_trades, ignore_index=True).sort_values("exit_dt").reset_index(drop=True)

    # summaries & outputs
    agg, by_tkr = summarize_fills(trades)
    curve = equity_curve(trades, unit_capital=args.unit_capital)
    cap_by_tkr = summarize_trades_per_ticker(trades, unit_capital=args.unit_capital)

    ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M")
    (OUT / f"s51_trades_{ts}.csv").write_text("")  # touch parent dir if needed
    trades.to_csv(OUT / f"s51_trades_{ts}.csv", index=False)
    curve.to_csv(OUT / f"s51_equity_curve_{ts}.csv", index=False)
    agg.to_csv(OUT / f"s51_summary_{ts}.csv", index=False)
    by_tkr.to_csv(OUT / f"s51_summary_by_ticker_{ts}.csv", index=False)
    cap_by_tkr.to_csv(OUT / f"s51_summary_capital_by_ticker_{ts}.csv", index=False)

    print(f"[OK] s51 Trades   → {OUT}/s51_trades_{ts}.csv")
    print(f"[OK] s51 Curve    → {OUT}/s51_equity_curve_{ts}.csv")
    print(f"[OK] s51 Summary  → {OUT}/s51_summary_{ts}.csv")
    print(f"[OK] s51 ByTicker → {OUT}/s51_summary_by_ticker_{ts}.csv")
    print(f"[OK] s51 Cap/Tkr  → {OUT}/s51_summary_capital_by_ticker_{ts}.csv")

if __name__ == "__main__":
    main()