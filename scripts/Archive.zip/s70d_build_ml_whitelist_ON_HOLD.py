#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
s70d_build_ml_whitelist.py
Select ~10–12 tickers to trust ML on, based on TEST metrics and Quality.

Inputs:
- models/per_ticker_metrics_test_*.csv   (from s73_eval_per_ticker.py)
  Expected columns: ['ticker','n','roc_auc', ...] or ['ticker','n','test_auc', ...]
- param_results/per_ticker_quality.csv   (from s69_quality_check.py)
  Expected columns: ['ticker','quality']

Logic (defaults you can tweak below):
- Keep tickers with:
    * quality in {"High Confidence","Medium (OK)"}
    * n_test >= 60
- Rank by test AUC (desc). If fewer than TARGET_COUNT, fill with the next-best
  tickers (still requiring n_test >= MIN_N) regardless of quality label.
- Cap at TARGET_COUNT (default 12).
- Write whitelist + blacklist to param_results/.
"""

from __future__ import annotations
from pathlib import Path
import sys
import re
import pandas as pd
import numpy as np

# ---------------- You can tweak these ----------------
TARGET_COUNT = 12        # desired whitelist size
MIN_N       = 60         # minimum test sample per ticker
GOOD_Q      = {"High Confidence", "Medium (OK)"}  # quality allowed
# -----------------------------------------------------

ROOT = Path(__file__).resolve().parent.parent
MODELS = ROOT / "models"
PARAM_RESULTS = ROOT / "param_results"

def _latest_test_metrics() -> Path:
    cands = sorted(MODELS.glob("per_ticker_metrics_test_*.csv"))
    if not cands:
        print("[ERR] No per_ticker_metrics_test_*.csv found. Run s73_eval_per_ticker.py first.", file=sys.stderr)
        sys.exit(1)
    return cands[-1]

def _load_metrics(fp: Path) -> pd.DataFrame:
    df = pd.read_csv(fp)
    # try to normalize column names
    cols = {c.lower(): c for c in df.columns}
    # prefer 'roc_auc' but accept 'test_auc'
    auc_col = None
    for c in ["roc_auc", "test_auc", "auc"]:
        if c in cols:
            auc_col = cols[c]
            break
    if auc_col is None:
        raise SystemExit("[ERR] Could not find AUC column in test metrics (roc_auc/test_auc/auc).")

    # 'n' column could be named 'n' or similar
    n_col = cols.get("n", None)
    if n_col is None:
        raise SystemExit("[ERR] Could not find 'n' column in test metrics.")

    tick_col = cols.get("ticker", None)
    if tick_col is None:
        raise SystemExit("[ERR] Could not find 'ticker' column in test metrics.")

    out = df[[tick_col, n_col, auc_col]].copy()
    out.columns = ["ticker", "n_test", "test_auc"]
    # drop aggregate rows like "__ALL__ (weighted)"
    out = out[~out["ticker"].str.contains("__ALL__", na=False)]
    return out

def _load_quality() -> pd.DataFrame:
    qf = PARAM_RESULTS / "per_ticker_quality.csv"
    if not qf.exists():
        raise SystemExit(f"[ERR] Missing {qf}. Run s69_quality_check.py first.")
    q = pd.read_csv(qf)[["ticker","quality"]].copy()
    return q

def main():
    test_fp = _latest_test_metrics()
    print(f"[INFO] Using TEST metrics: {test_fp.name}")
    test_df = _load_metrics(test_fp)
    qual_df = _load_quality()

    df = test_df.merge(qual_df, on="ticker", how="left")

    # primary pool: good quality + min n
    pool_good = df[(df["quality"].isin(GOOD_Q)) & (df["n_test"] >= MIN_N)].copy()
    pool_good = pool_good.sort_values(["test_auc","n_test"], ascending=[False, False])

    chosen = pool_good.head(TARGET_COUNT).copy()

    # if not enough, fill with next-best by AUC (still respecting MIN_N)
    if len(chosen) < TARGET_COUNT:
        remaining = df[~df["ticker"].isin(chosen["ticker"])].copy()
        remaining = remaining[remaining["n_test"] >= MIN_N]
        remaining = remaining.sort_values(["test_auc","n_test"], ascending=[False, False])
        need = TARGET_COUNT - len(chosen)
        chosen = pd.concat([chosen, remaining.head(need)], ignore_index=True)

    chosen["ml_usable"] = True
    # blacklist = all others
    blacklist = df[~df["ticker"].isin(chosen["ticker"])].copy()
    blacklist["ml_usable"] = False

    PARAM_RESULTS.mkdir(parents=True, exist_ok=True)
    wl_fp = PARAM_RESULTS / "s70_whitelist.csv"
    bl_fp = PARAM_RESULTS / "s70_blacklist.csv"
    chosen.to_csv(wl_fp, index=False)
    blacklist.to_csv(bl_fp, index=False)

    print(f"[OK] Whitelist → {wl_fp} ({len(chosen)} tickers)")
    print(f"[OK] Blacklist → {bl_fp} ({len(blacklist)} tickers)")
    print("\n[Whitelist preview]")
    print(chosen[["ticker","quality","n_test","test_auc"]].to_string(index=False))

if __name__ == "__main__":
    main()