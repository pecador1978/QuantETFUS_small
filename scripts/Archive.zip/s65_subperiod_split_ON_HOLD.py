#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
s65_subperiod_split.py
Compute sub-period returns for each seed using the trades already produced by s62.

Default mode = "champions":
  1) Reads latest s63_best_per_ticker_*.csv (champion params per ticker).
  2) Scans ranked per-ticker files (param_results_{TICKER}_{SUFFIX}.csv) matching a filename filter
     (e.g., contains "_S6000" so we only ingest those seed runs).
  3) For each ticker, finds rows whose parameter columns MATCH the champion params,
     collects their trades_file names (each belongs to a seed/run).
  4) Loads each trades CSV and computes per-window sub-period return using per-fill PnL:
        pnl = sum( ret_pct * qty * UNIT_CAPITAL - fee_eur ), over fills with exit_dt inside the window (UTC)
        subperiod_return = pnl / UNIT_CAPITAL
  5) Outputs:
        s65_subperiod_by_seed_{TS}.csv
            (ticker, seed/run_id, window_label, subperiod_return, n_fills, source_files, params...)
        s65_champions_subperiod_summary_{TS}.csv
            (ticker, window_label, mean_return, std_return, n_seeds)

Notes
- We force both window edges and exit_dt to be tz-aware UTC to avoid tz-naive/aware comparison errors.
- Optional coverage filter: drop tickers with < coverage_min_years based on prices_enriched.parquet (if available).

Paths are resolved via common.paths.P so this works in QuantETF and QuantETFUS.
"""

from pathlib import Path
from datetime import datetime, timezone
import argparse
import json
import os
import sys
import pandas as pd
import numpy as np

# --- force single-threaded math to avoid oversubscription ---
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("VECLIB_MAXIMUM_THREADS", "1")
os.environ.setdefault("NUMEXPR_NUM_THREADS", "1")

# ---- import shared paths (project‑aware)
SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parent  # .../scripts -> project root
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
from common.paths import P  # ROOT, PARAM_RESULTS, CONFIG_DIR, DATA_ENRICHED, etc.

# ---- project-aware paths
PARAM_RESULTS   = P.PARAM_RESULTS
TRADES_DIR      = PARAM_RESULTS / "trades"
CONFIG          = P.CONFIG_DIR / "s60_parameters.json"
ENRICHED_PARQUET= P.DATA_ENRICHED / "prices_enriched.parquet"

UNIT_CAPITAL = 10_000.0  # must match s50/s60/s62

# ------------ helpers ------------
def _latest_csv(dirpath: Path, prefix: str) -> Path:
    cands = sorted(dirpath.glob(f"{prefix}*.csv"))
    if not cands:
        raise SystemExit(f"[ERR] No files matching {prefix}*.csv in {dirpath}")
    return cands[-1]

def _timestamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%d_%H%M")

def _load_param_keys(config_path: Path) -> list[str]:
    with open(config_path, "r") as f:
        cfg = json.load(f)
    return list(cfg.keys())

def _to_utc_ts(x):
    """Return a pandas.Timestamp tz-aware in UTC."""
    ts = pd.to_datetime(x, errors="coerce")
    if ts is pd.NaT:
        return ts
    if ts.tzinfo is None:
        return ts.tz_localize("UTC")
    return ts.tz_convert("UTC")

def _parse_windows(spec: str):
    """
    spec example:
      "2016-01-01:2018-12-31,2019-01-01:2020-12-31,2021-01-01:2022-12-31,2023-01-01:2024-12-31"
    Returns: [{"label":"2016-2018","start":Timestamp(UTC),"end":Timestamp(UTC)}, ...]
    """
    out = []
    for chunk in [s.strip() for s in spec.split(",") if s.strip()]:
        if ":" not in chunk:
            raise SystemExit(f"[ERR] Bad window chunk '{chunk}'. Use START:END, comma separated.")
        s, e = chunk.split(":", 1)
        sdt = _to_utc_ts(s)
        edt = _to_utc_ts(e)
        label = f"{sdt.year}-{edt.year}"
        out.append({"label": label, "start": sdt, "end": edt})
    return out

def _find_ranked_per_ticker_csvs(param_dir: Path, filename_contains: str):
    # param_results_{TICKER}_{SUFFIX}.csv (ranked)
    files = []
    for p in param_dir.glob("param_results_*_*.csv"):
        name = p.name
        if name.startswith("param_results_ALL_"):
            continue
        if name.endswith("_ALL.csv"):
            continue
        if filename_contains and (filename_contains not in name):
            continue
        files.append(p)
    return files

def _parse_ticker_suffix(path: Path):
    base = path.name
    assert base.startswith("param_results_") and base.endswith(".csv")
    body = base[len("param_results_"):-len(".csv")]
    if "_" not in body:
        return body, "UNKNOWN"
    tkr, suffix = body.split("_", 1)
    return tkr, suffix

def _row_matches_params(row: pd.Series, pkeys: list[str], target: dict) -> bool:
    # treat NaN == NaN; numeric comparison tolerant for floats
    for k in pkeys:
        tv = target.get(k, np.nan)
        rv = row.get(k, np.nan)
        if (pd.isna(tv) and pd.isna(rv)):
            continue
        # strings?
        if isinstance(tv, str) or isinstance(rv, str):
            if str(tv) != str(rv):
                return False
            continue
        # numeric-ish
        try:
            if pd.isna(rv) and pd.isna(tv):
                continue
            if pd.isna(rv) or pd.isna(tv):
                return False
            if float(rv).is_integer() and float(tv).is_integer():
                if int(rv) != int(tv):
                    return False
            else:
                if not np.isclose(float(rv), float(tv), rtol=1e-10, atol=1e-12):
                    return False
        except Exception:
            if str(rv) != str(tv):
                return False
    return True

def _pnl_from_trades(trades: pd.DataFrame) -> float:
    # expects ret_pct, qty, fee_eur
    if trades is None or trades.empty:
        return 0.0
    for col in ["ret_pct", "qty", "fee_eur"]:
        if col not in trades.columns:
            trades[col] = 0.0
    trades["ret_pct"] = pd.to_numeric(trades["ret_pct"], errors="coerce").fillna(0.0)
    trades["qty"] = pd.to_numeric(trades["qty"], errors="coerce").fillna(0.0)
    trades["fee_eur"] = pd.to_numeric(trades["fee_eur"], errors="coerce").fillna(0.0)
    pnl = (trades["ret_pct"] * trades["qty"] * UNIT_CAPITAL - trades["fee_eur"]).sum()
    return float(pnl)

def _coverage_years_from_parquet(parquet_path: Path) -> dict[str, float]:
    """Return {ticker: coverage_years} based on first/last timestamp in prices_enriched.parquet (UTC)."""
    if not parquet_path.exists():
        return {}
    try:
        df = pd.read_parquet(parquet_path)
    except Exception as e:
        print(f"[WARN] Could not read parquet for coverage ({e}); skipping coverage filter.")
        return {}
    # Expect columns: ticker, dt (or datetime-like). Adjust if needed.
    time_col = None
    for c in ["dt", "datetime", "timestamp", "date"]:
        if c in df.columns:
            time_col = c
            break
    if time_col is None:
        print("[WARN] No time column found in parquet; skipping coverage filter.")
        return {}
    df[time_col] = pd.to_datetime(df[time_col], utc=True, errors="coerce")
    df = df.dropna(subset=[time_col])
    g = df.groupby("ticker")[time_col].agg(["min", "max"]).reset_index()
    cov = {}
    for _, r in g.iterrows():
        first = r["min"]
        last  = r["max"]
        years = (last - first).days / 365.25
        cov[str(r["ticker"])] = float(years)
    return cov

# ------------ main ------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--param_dir", type=str, default=str(PARAM_RESULTS),
                    help="Where per-ticker ranked CSVs live (from s62).")
    ap.add_argument("--trades_dir", type=str, default=str(TRADES_DIR),
                    help="Where per-seed trades are (s62 wrote them into param_results/trades/{ticker}/...).")
    ap.add_argument("--config", type=str, default=str(CONFIG),
                    help="Path to s60_parameters.json to know which columns form the param set.")
    ap.add_argument("--windows", type=str,
                    default="2016-01-01:2018-12-31,2019-01-01:2020-12-31,2021-01-01:2022-12-31,2023-01-01:2024-12-31",
                    help="Comma-separated subperiods 'YYYY-MM-DD:YYYY-MM-DD,...' (interpreted in UTC).")
    ap.add_argument("--filename_contains", type=str, default="_S6000",
                    help="Only ingest ranked files whose names contain this substring (e.g. '_S6000' or '_S6000-per_ticker').")
    ap.add_argument("--mode", choices=["champions","all"], default="champions",
                    help="champions = use s63_best_per_ticker latest to select 1 combo per ticker; all = use all ranked rows.")
    ap.add_argument("--limit_rows_per_ticker", type=int, default=0,
                    help="(mode=all only) cap rows per ticker for speed (0 = no cap).")
    ap.add_argument("--coverage_min_years", type=float, default=0.0,
                    help="If >0, drop tickers with coverage < this many years (based on prices_enriched.parquet if available).")
    args = ap.parse_args()

    param_dir  = Path(args.param_dir)
    trades_dir = Path(args.trades_dir)
    config_path= Path(args.config)

    if not param_dir.exists():
        raise SystemExit(f"[ERR] param_dir missing: {param_dir}")
    if not trades_dir.exists():
        raise SystemExit(f"[ERR] trades_dir missing: {trades_dir}")
    if not config_path.exists():
        raise SystemExit(f"[ERR] config file missing: {config_path}")

    param_keys = _load_param_keys(config_path)
    windows = _parse_windows(args.windows)  # tz-aware UTC window edges

    # ranked per-ticker files
    ranked_files = _find_ranked_per_ticker_csvs(param_dir, args.filename_contains)
    if not ranked_files:
        raise SystemExit(f"[ERR] No ranked per-ticker files found with filter '{args.filename_contains}'.")

    # --- optional coverage filter ---
    coverage_years = {}
    if args.coverage_min_years > 0:
        coverage_years = _coverage_years_from_parquet(ENRICHED_PARQUET)
        tickers_found = sorted({_parse_ticker_suffix(p)[0] for p in ranked_files})
        drop = [t for t in tickers_found if coverage_years.get(t, 0.0) < args.coverage_min_years]
        if drop:
            print(f"[INFO] Dropping {len(drop)} tickers for low coverage (< {args.coverage_min_years} yrs): {drop}")
        ranked_files = [p for p in ranked_files if _parse_ticker_suffix(p)[0] not in drop]
        kept = sorted({_parse_ticker_suffix(p)[0] for p in ranked_files})
        sample_cov = {t: round(coverage_years.get(t, 0.0), 2) for t in kept[:10]}
        print(f"[INFO] Tickers selected (after coverage filter if applied): {len(kept)}")
        print(f"       Sample coverage_years: {sample_cov}")

    # decide which rows to analyze
    rows_to_analyze = []  # list of dicts: {ticker, run_id, combo_id, trades_file, params{...}}
    if args.mode == "champions":
        best_file = _latest_csv(param_dir, "s63_best_per_ticker_")
        print(f"[INFO] Champions mode. Using: {best_file.name}")
        best = pd.read_csv(best_file)
        champ_by_ticker = {}
        for _, r in best.iterrows():
            tkr = str(r["ticker"])
            champ_by_ticker[tkr] = {k: (None if pd.isna(r.get(k)) else r.get(k)) for k in param_keys}

        for p in ranked_files:
            tkr, suffix = _parse_ticker_suffix(p)
            if tkr not in champ_by_ticker:
                continue
            champ_params = champ_by_ticker[tkr]
            df = pd.read_csv(p)
            if df is None or df.empty:
                continue
            for k in param_keys:
                if k not in df.columns:
                    df[k] = np.nan
            hits = df[df.apply(lambda row: _row_matches_params(row, param_keys, champ_params), axis=1)]
            if hits.empty:
                continue
            for _, row in hits.iterrows():
                trades_file = row.get("trades_file", "")
                combo_id = row.get("combo_id", None)
                run_id = suffix
                if not trades_file:
                    continue
                rows_to_analyze.append({
                    "ticker": tkr,
                    "run_id": run_id,
                    "combo_id": int(combo_id) if pd.notna(combo_id) else None,
                    "trades_file": str(trades_file),
                    "params": champ_params
                })
    else:
        print("[INFO] All-rows mode.")
        for p in ranked_files:
            tkr, suffix = _parse_ticker_suffix(p)
            df = pd.read_csv(p)
            if df is None or df.empty:
                continue
            for k in param_keys:
                if k not in df.columns:
                    df[k] = np.nan
            if args.limit_rows_per_ticker > 0:
                df = df.head(args.limit_rows_per_ticker).copy()
            for _, row in df.iterrows():
                trades_file = row.get("trades_file", "")
                if not trades_file:
                    continue
                rows_to_analyze.append({
                    "ticker": tkr,
                    "run_id": suffix,
                    "combo_id": int(row["combo_id"]) if "combo_id" in row and pd.notna(row["combo_id"]) else None,
                    "trades_file": str(trades_file),
                    "params": {k: row.get(k, np.nan) for k in param_keys}
                })

    if not rows_to_analyze:
        raise SystemExit("[ERR] Nothing to analyze (no trades_file references found).")

    print(f"[INFO] Rows to analyze (unique ticker/run/combos): {len(rows_to_analyze)}")

    # compute subperiod PnL
    out_rows = []
    for item in rows_to_analyze:
        tkr = item["ticker"]
        run_id = item["run_id"]
        trades_path = TRADES_DIR / tkr / item["trades_file"]
        if not trades_path.exists():
            print(f"[WARN] Missing trades: {trades_path.name} for {tkr} ({run_id}); skipping.")
            continue
        tr = pd.read_csv(trades_path)
        if tr is None or tr.empty:
            continue
        if "exit_dt" not in tr.columns:
            print(f"[WARN] No exit_dt in {trades_path.name}; skipping.")
            continue

        # Force exit_dt to tz-aware UTC
        tr["exit_dt"] = pd.to_datetime(tr["exit_dt"], utc=True, errors="coerce")
        tr = tr.dropna(subset=["exit_dt"]).copy()

        for w in windows:
            mask = (tr["exit_dt"] >= w["start"]) & (tr["exit_dt"] <= w["end"])
            tr_w = tr.loc[mask].copy()
            pnl = _pnl_from_trades(tr_w)
            subret = pnl / UNIT_CAPITAL
            row_out = {
                "ticker": tkr,
                "run_id": run_id,
                "window_label": w["label"],
                "start": w["start"].date(),
                "end": w["end"].date(),
                "subperiod_return": subret,
                "fills": int(len(tr_w)),
                "trades_file": trades_path.name,
            }
            for k, v in item["params"].items():
                row_out[k] = v
            out_rows.append(row_out)

    if not out_rows:
        raise SystemExit("[ERR] No sub-period rows produced.")

    df_seed = pd.DataFrame(out_rows)

    # summary across seeds per ticker & window
    grp = df_seed.groupby(["ticker", "window_label"], as_index=False)
    df_sum = grp.agg(
        mean_return=("subperiod_return", "mean"),
        std_return=("subperiod_return", "std"),
        n_seeds=("subperiod_return", "count"),
        mean_fills=("fills", "mean"),
    )
    df_sum["std_return"] = df_sum["std_return"].fillna(0.0)

    ts = _timestamp()
    out_seed = PARAM_RESULTS / f"s65_subperiod_by_seed_{ts}.csv"
    out_sum  = PARAM_RESULTS / f"s65_champions_subperiod_summary_{ts}.csv"

    df_seed.to_csv(out_seed, index=False)
    df_sum.sort_values(["ticker","window_label"]).to_csv(out_sum, index=False)

    print(f"[OK] Wrote per-seed subperiods → {out_seed}")
    print(f"[OK] Wrote champions summary  → {out_sum}")
    print("[HINT] Sort by std_return to spot time-unstable tickers; low std with good mean is what you want.")


if __name__ == "__main__":
    main()