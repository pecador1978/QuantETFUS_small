#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
s76_rule_signals.py — Rule-based intraday BUY / DO NOTHING from s32 outputs (no ML).

Inputs
- data_enriched/30min/{TICKER}.parquet      (from s32_enrich_30m_intraday.py)
- param_results/s70_whitelist.csv            (optional; uses 'ml_usable' as whitelist)
- param_results/per_ticker_quality.csv       (optional; used for display only)

Outputs
- param_results/rule_live_signals_<ts>.csv                (full board, all tickers + flags)
- param_results/operator_today_RULE_top10_<ts>.csv        (Top-10 BUYs + flags)
- param_results/operator_today_RULE_all_<ts>.csv          (All tickers, BUY first + flags)
- param_results/operator_today_RULE_<ts>.csv              (BUY-only shortlist; kept for compatibility)

Rules (default, tweak via CLI flags):
- Daily trend: ema20_d > ema44_d  [--no-daily-trend to disable]
- Daily RSI guard: rsi14_d >= 50  [--no-rsi-guard to disable]
- Intraday momentum: m30_close > m30_ema275
- Not at lows: m30_ll80_from_close_pct >= -0.02 (within 2% of 80-bar low)
- Vol filter: 0.002 <= m30_atr14_norm <= 0.05
- Require whitelist if present (ml_usable == True) unless --ignore-whitelist

Ranking
- A simple strength_score ranks BUYs:
    2 * (m30_close/m30_ema275 - 1, clipped ±10%)
  + 0.01 * (rsi14_d - 50)
  + 0.5 * proximity of ATR to window mid
"""

from __future__ import annotations
from pathlib import Path
from datetime import datetime, timezone
import sys
import pandas as pd
import numpy as np

# ---------- project paths ----------
SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
from common.paths import P  # ROOT, DATA_ENRICHED, PARAM_RESULTS, etc.

def _ts() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%d_%H%M")

def _load_whitelist() -> pd.DataFrame | None:
    wl = P.ROOT / "param_results" / "s70_whitelist.csv"
    if not wl.exists():
        return None
    try:
        df = pd.read_csv(wl)
        if "ml_usable" not in df.columns:
            df["ml_usable"] = True
        return df[["ticker","ml_usable"]].drop_duplicates()
    except Exception:
        return None

def _load_quality() -> pd.DataFrame | None:
    q = P.ROOT / "param_results" / "per_ticker_quality.csv"
    if not q.exists():
        return None
    try:
        df = pd.read_csv(q)
        low = {c.lower(): c for c in df.columns}
        tcol = next((low[k] for k in ["ticker"] if k in low), None)
        qcol = next((low[k] for k in ["quality"] if k in low), None)
        if not tcol:
            return None
        if not qcol:
            df["quality"] = pd.NA
            qcol = "quality"
        return df.rename(columns={tcol:"ticker", qcol:"quality"})[["ticker","quality"]]
    except Exception:
        return None

def _yesno(x: bool) -> str:
    return "YES" if bool(x) else "NO"

def main():
    import argparse
    ap = argparse.ArgumentParser(description="Rule-based live decisions from s32 features.")
    ap.add_argument("--limit", type=int, default=None, help="Score only first N tickers (debug).")
    ap.add_argument("--no-daily-trend", action="store_true", help="Disable ema20_d > ema44_d filter.")
    ap.add_argument("--no-rsi-guard", action="store_true", help="Disable rsi14_d >= 50 guard.")
    ap.add_argument("--min-atr-norm", type=float, default=0.002, help="Lower bound for m30_atr14_norm.")
    ap.add_argument("--max-atr-norm", type=float, default=0.05, help="Upper bound for m30_atr14_norm.")
    ap.add_argument("--near-low", type=float, default=-0.02, help="Min m30_ll80_from_close_pct (e.g., -0.02 for not within 2% of low).")
    ap.add_argument("--ignore-whitelist", action="store_true", help="Ignore s70_whitelist.csv if present.")
    args = ap.parse_args()

    m30_dir = P.ROOT / "data_enriched" / "30min"
    if not m30_dir.exists():
        raise SystemExit(f"[ERR] {m30_dir} not found. Run s32 first.")

    parqs = sorted(m30_dir.glob("*.parquet"))
    if not parqs:
        raise SystemExit(f"[ERR] No parquet files in {m30_dir}.")
    if args.limit:
        parqs = parqs[: args.limit]

    wl = None if args.ignore_whitelist else _load_whitelist()
    qual = _load_quality()

    rows = []
    req_cols = [
        "close","m30_ema275","m30_atr14_norm","m30_ll80_from_close_pct",
        "ema20_d","ema44_d","rsi14_d"
    ]

    for pq in parqs:
        tkr = pq.stem
        try:
            df = pd.read_parquet(pq)
            if df.empty:
                continue
            last = df.iloc[[-1]].copy()
            last["ticker"] = tkr

            # normalize m30_close
            last["m30_close"] = last["close"] if "close" in last.columns else np.nan

            # ensure required columns exist
            for c in req_cols:
                if c not in last.columns:
                    last[c] = np.nan

            rows.append(last[["ticker","m30_close","m30_ema275","m30_atr14_norm","m30_ll80_from_close_pct","ema20_d","ema44_d","rsi14_d"]])
        except Exception as e:
            print(f"[WARN] {tkr}: {e}")

    if not rows:
        raise SystemExit("[ERR] No rows to decide.")

    X = pd.concat(rows, ignore_index=True)

    # Optional annotations
    if wl is not None:
        X = X.merge(wl, on="ticker", how="left")
        X["ml_usable"] = X["ml_usable"].fillna(False)
    else:
        X["ml_usable"] = True

    if qual is not None:
        X = X.merge(qual, on="ticker", how="left")
    else:
        X["quality"] = pd.NA

    # ----- RULES -----
    # Daily trend
    cond_trend = (X["ema20_d"] > X["ema44_d"]) if not args.no_daily_trend else pd.Series(True, index=X.index)

    # RSI guard
    cond_rsi = (X["rsi14_d"] >= 50) if not args.no_rsi_guard else pd.Series(True, index=X.index)

    # Intraday momentum
    cond_momo = (X["m30_close"] > X["m30_ema275"])

    # Not at lows (≥ near_low)
    cond_low = (X["m30_ll80_from_close_pct"] >= float(args.near_low))

    # Volatility window
    cond_vol = (X["m30_atr14_norm"] >= float(args.min_atr_norm)) & (X["m30_atr14_norm"] <= float(args.max_atr_norm))

    base_ok = cond_trend & cond_rsi & cond_momo & cond_low & cond_vol
    final_ok = base_ok & X["ml_usable"].astype(bool)

    # Reasons
    def reason(i):
        r = []
        if not cond_trend.iloc[i]: r.append("trend")
        if not cond_rsi.iloc[i]:   r.append("rsi")
        if not cond_momo.iloc[i]:  r.append("momo")
        if not cond_low.iloc[i]:   r.append("near_low")
        if not cond_vol.iloc[i]:   r.append("vol")
        if not bool(X["ml_usable"].iloc[i]): r.append("whitelist")
        return "OK" if len(r)==0 else ("FAIL: " + ",".join(r))

    X["decision"] = ["BUY" if v else "DO NOTHING" for v in final_ok]
    X["rule_trend"] = [_yesno(v) for v in cond_trend]
    X["rule_rsi"]   = [_yesno(v) for v in cond_rsi]
    X["rule_momo"]  = [_yesno(v) for v in cond_momo]
    X["rule_low"]   = [_yesno(v) for v in cond_low]
    X["rule_vol"]   = [_yesno(v) for v in cond_vol]
    X["whitelisted"] = [_yesno(v) for v in X["ml_usable"]]
    X["reason"] = [reason(i) for i in range(len(X))]

    # ----- Strength score for ranking BUYs -----
    above_ema = (X["m30_close"] / X["m30_ema275"] - 1.0).clip(-0.10, 0.10)
    rsi_term = 0.01 * (X["rsi14_d"] - 50.0)
    mid = (float(args.min_atr_norm) + float(args.max_atr_norm)) / 2.0
    atr_prox = 1.0 - (X["m30_atr14_norm"] - mid).abs() / max(mid, 1e-9)
    atr_prox = atr_prox.clip(lower=0.0)
    X["strength_score"] = 2.0 * above_ema.fillna(0.0) + rsi_term.fillna(0.0) + 0.5 * atr_prox.fillna(0.0)

    # ----- Outputs -----
    pr = P.ROOT / "param_results"
    pr.mkdir(parents=True, exist_ok=True)
    ts = _ts()

    board_cols = [c for c in [
        "ticker","decision","reason","quality",
        "m30_close","m30_ema275","m30_atr14_norm","m30_ll80_from_close_pct",
        "ema20_d","ema44_d","rsi14_d",
        "rule_trend","rule_rsi","rule_momo","rule_low","rule_vol","whitelisted",
        "strength_score"
    ] if c in X.columns]

    # Full board (ALL tickers)
    board_csv = pr / f"rule_live_signals_{ts}.csv"
    X[board_cols].to_csv(board_csv, index=False)
    print(f"[OK] Rule live signals (full board) → {board_csv}")

    # BUY-only shortlist (legacy)
    buy = X[X["decision"]=="BUY"].copy()
    buy = buy.sort_values("strength_score", ascending=False)
    buy_csv = pr / f"operator_today_RULE_{ts}.csv"
    buy[["ticker","decision","reason","quality","strength_score"]].to_csv(buy_csv, index=False)
    print(f"[OK] Operator shortlist (BUY only) → {buy_csv}  (rows={len(buy)})")

    # Top-10 BUYs with flags
    top10 = buy.head(10).copy()
    top10_csv = pr / f"operator_today_RULE_top10_{ts}.csv"
    top10[[c for c in ["ticker","decision","reason","quality",
                       "rule_trend","rule_rsi","rule_momo","rule_low","rule_vol","whitelisted",
                       "m30_close","m30_ema275","rsi14_d","m30_atr14_norm","strength_score"] if c in top10.columns]].to_csv(top10_csv, index=False)
    print(f"[OK] Operator Top-10 (RULE) → {top10_csv}")

    # All tickers, BUY first, then DO NOTHING, with flags
    X["decision_order"] = np.where(X["decision"]=="BUY", 0, 1)
    all_csv = pr / f"operator_today_RULE_all_{ts}.csv"
    (X.sort_values(["decision_order","strength_score"], ascending=[True, False])
      [ [c for c in ["ticker","decision","reason","quality",
                     "rule_trend","rule_rsi","rule_momo","rule_low","rule_vol","whitelisted",
                     "m30_close","m30_ema275","rsi14_d","m30_atr14_norm","strength_score"] if c in X.columns] ]
      .to_csv(all_csv, index=False))
    print(f"[OK] Operator ALL (sorted) → {all_csv}")

    # Console summary
    print("\n[Decision counts]")
    print(X["decision"].value_counts(dropna=False).to_string())

    if len(top10):
        print("\n[Top-10 BUYs]")
        print(top10[["ticker","strength_score","rule_trend","rule_rsi","rule_momo","rule_low","rule_vol","whitelisted"]]
              .to_string(index=False))

if __name__ == "__main__":
    main()