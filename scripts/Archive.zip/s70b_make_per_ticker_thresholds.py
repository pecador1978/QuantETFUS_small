#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
s70b_make_per_ticker_thresholds.py — derive per-ticker decision thresholds on VAL

Reads:
  models/classifier_val_predictions_*.csv   (from s70)

Writes:
  param_results/s70b_per_ticker_thresholds_<ts>.csv
  columns: [ticker, thr_star, n_val, prec, rec, f1, rule]
"""

from __future__ import annotations
from pathlib import Path
from datetime import datetime, timezone
import sys, numpy as np, pandas as pd

# project-aware paths
SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
from common.paths import P  # ROOT, etc.

def _ts(): return datetime.now(timezone.utc).strftime("%Y%m%d_%H%M")
def _latest(globpat: str, base: Path) -> Path | None:
    c = sorted(base.glob(globpat)); return c[-1] if c else None

def _global_thr(df: pd.DataFrame, default=0.50) -> float:
    if "threshold_used" in df.columns:
        vals = pd.to_numeric(df["threshold_used"], errors="coerce").dropna().unique()
        if len(vals) == 1: return float(vals[0])
    return float(default)

def _metrics_at_thr(y_true, y_prob, thr):
    from sklearn.metrics import precision_score, recall_score, f1_score
    y_pred = (y_prob >= thr).astype(int)
    return (
        float(precision_score(y_true, y_pred, zero_division=0)),
        float(recall_score(y_true, y_pred, zero_division=0)),
        float(f1_score(y_true, y_pred, zero_division=0)),
    )

def main():
    val_fp = _latest("classifier_val_predictions_*.csv", P.ROOT / "models")
    if not val_fp:
        raise SystemExit("[ERR] No VAL predictions found. Run s70 first.")
    df = pd.read_csv(val_fp)
    need = {"ticker", "y_true"}
    if not need.issubset(df.columns):
        raise SystemExit(f"[ERR] {val_fp.name} must contain {need}")
    if "y_prob" not in df.columns and "y_pred" not in df.columns:
        raise SystemExit("[ERR] Need y_prob (preferred) or y_pred in VAL predictions.")

    df["y_true"] = pd.to_numeric(df["y_true"], errors="coerce").fillna(0).astype(int)
    if "y_prob" in df.columns:
        df["y_prob"] = pd.to_numeric(df["y_prob"], errors="coerce").fillna(0.5).clip(0,1).astype(float)
    else:
        df["y_prob"] = df["y_pred"].astype(int).astype(float)

    gthr = _global_thr(df, default=0.50)
    print(f"[INFO] Baseline (global) threshold from VAL file: {gthr:.2f}")

    # tuning knobs
    thr_grid = np.round(np.linspace(0.10, 0.90, 33), 4)
    min_rows = 150
    min_pos  = 20
    min_neg  = 20
    min_prec = 0.60

    out_rows = []
    for tkr, g in df.groupby("ticker", dropna=False):
        tkr = str(tkr)
        y = g["y_true"].values
        p = g["y_prob"].values
        n = len(g); pos = int((y==1).sum()); neg = int((y==0).sum())

        # if too little data, fall back to global
        if n < min_rows or pos < min_pos or neg < min_neg:
            out_rows.append({"ticker": tkr, "thr_star": gthr, "n_val": n, "prec": np.nan, "rec": np.nan, "f1": np.nan, "rule": "fallback"})
            continue

        best = None
        for thr in thr_grid:
            prec, rec, f1 = _metrics_at_thr(y, p, thr)
            if prec >= min_prec:
                score = (f1, prec, rec)
                if best is None or score > best[0]:
                    best = (score, thr, prec, rec, f1)

        if best is None:
            out_rows.append({"ticker": tkr, "thr_star": gthr, "n_val": n, "prec": np.nan, "rec": np.nan, "f1": np.nan, "rule": "no_feasible"})
            continue

        _, thr_loc, prec, rec, f1 = best
        # shrink toward global: alpha grows with n
        alpha = min(1.0, n / 500.0)
        thr_star = float(alpha * thr_loc + (1.0 - alpha) * gthr)

        out_rows.append({"ticker": tkr, "thr_star": thr_star, "n_val": n, "prec": prec, "rec": rec, "f1": f1, "rule": "tuned+shrink"})

    out = pd.DataFrame(out_rows).sort_values("ticker")
    out_dir = P.ROOT / "param_results"; out_dir.mkdir(parents=True, exist_ok=True)
    out_fp = out_dir / f"s70b_per_ticker_thresholds_{_ts()}.csv"
    out.to_csv(out_fp, index=False)
    print(f"[OK] Wrote per-ticker thresholds → {out_fp}")

    try:
        print("\n[Preview top by n_val]")
        print(out.sort_values("n_val", ascending=False).head(15).to_string(index=False))
    except Exception:
        pass

if __name__ == "__main__":
    main()