#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
s80_decision_board.py — Operator-facing BUY / DO NOTHING table (one row per ticker).

Inputs (auto):
- param_results/final_signals_<ts>.csv            (preferred; from s74)
  or param_results/s70_results_with_guidance_<ts>.csv (fallback; from s70)
- param_results/s70b_per_ticker_thresholds_<ts>.csv    (optional; per-ticker thr)
- models/classifier_metrics_<ts>.json                  (optional; global thr)

Output:
- param_results/final_decisions_<ts>.csv              (technical, one-row-per-ticker)
- param_results/final_decisions_pretty_<ts>.csv       (operator board)
"""

from __future__ import annotations
from pathlib import Path
from datetime import datetime, timezone
import sys, json
import pandas as pd
import numpy as np

# project-aware paths
SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
from common.paths import P  # noqa: E402

def _ts() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%d_%H%M")

def _latest(base: Path, pat: str) -> Path | None:
    c = sorted(base.glob(pat))
    return c[-1] if c else None

def load_live() -> pd.DataFrame:
    pr = P.ROOT / "param_results"
    p = _latest(pr, "final_signals_*.csv")
    if p:
        print(f"[INFO] Using s74 file → {p.name}")
        return pd.read_csv(p)
    p = _latest(pr, "s70_results_with_guidance_*.csv")
    if p:
        print(f"[INFO] Using s70 live file → {p.name}")
        return pd.read_csv(p)
    raise SystemExit(f"[ERR] No live file found in {pr}")

def load_thr_map() -> dict[str, float]:
    pr = P.ROOT / "param_results"
    p = _latest(pr, "s70b_per_ticker_thresholds_*.csv")
    if not p:
        print("[INFO] No per-ticker thresholds (s70b).")
        return {}
    df = pd.read_csv(p)
    thr_col = "thr_star" if "thr_star" in df.columns else (
        "thr_star_val" if "thr_star_val" in df.columns else None
    )
    if not thr_col:
        print("[WARN] s70b file missing thr_star; ignoring.")
        return {}
    m = (df[["ticker", thr_col]]
         .dropna()
         .groupby("ticker")[thr_col]
         .last()
         .to_dict())
    print(f"[INFO] Loaded {len(m)} per-ticker thresholds.")
    return m

def load_global_thr() -> float:
    md = P.ROOT / "models"
    p = _latest(md, "classifier_metrics_*.json")
    if not p:
        print("[INFO] No metrics json; global threshold = 0.50")
        return 0.50
    try:
        d = json.loads(p.read_text())
        t = float(d.get("decision_threshold", 0.50))
        print(f"[INFO] Global threshold → {t:.2f}")
        return t
    except Exception:
        print("[WARN] Could not parse metrics; global threshold = 0.50")
        return 0.50

def coerce_dt_cols(df: pd.DataFrame) -> pd.DataFrame:
    # prefer 'entry_dt' if it exists; else 'date'
    if "entry_dt" in df.columns:
        df["entry_dt"] = pd.to_datetime(df["entry_dt"], errors="coerce", utc=True)
    if "date" in df.columns:
        # allow date to be date or datetime; make tz-aware at 00:00 UTC if date-like
        dtmp = pd.to_datetime(df["date"], errors="coerce", utc=True)
        df["date"] = dtmp
    return df

def pick_latest_per_ticker(df: pd.DataFrame) -> pd.DataFrame:
    df = coerce_dt_cols(df.copy())

    # build a single sortable timestamp column
    if "entry_dt" in df.columns and df["entry_dt"].notna().any():
        df["_when"] = df["entry_dt"]
    elif "date" in df.columns and df["date"].notna().any():
        df["_when"] = df["date"]
    else:
        # fallback: keep insertion order
        df["_when"] = pd.Series(range(len(df)), index=df.index)

    # pick the latest row per ticker
    # if duplicates with same timestamp exist, .tail(1) keeps the last occurrence
    latest = (df
              .sort_values(["ticker", "_when"])
              .groupby("ticker", as_index=False)
              .tail(1)
              .reset_index(drop=True)
              .drop(columns=["_when"]))
    return latest

def decide_row(r, thr_map, gthr) -> tuple[str, float]:
    sig = str(r.get("signal", "")).strip()
    ml_ok = bool(r.get("ml_usable", False))
    q = str(r.get("quality", "")).strip()
    prob = float(r.get("y_prob", np.nan)) if "y_prob" in r else np.nan

    if ml_ok:
        thr = float(thr_map.get(str(r.get("ticker")), gthr))
        buy = (sig == "Buy") and (prob >= thr)
        return ("BUY" if buy else "DO NOTHING", thr)
    else:
        buy = (sig == "Buy") and (q != "No Go")
        return ("BUY" if buy else "DO NOTHING", np.nan)

def icon(decision: str, ml_ok: bool, quality: str) -> str:
    if decision == "BUY":
        return "✅" if (ml_ok and quality in ("High Confidence", "Medium (OK)")) else "🟡"
    return "⏸️"

def main():
    df_all = load_live()
    thr_map = load_thr_map()
    gthr = load_global_thr()

    # ensure expected columns exist
    if "ml_usable" not in df_all.columns:
        df_all["ml_usable"] = False

    # one row per ticker: **latest**
    df = pick_latest_per_ticker(df_all)

    # decisions
    dec, thr_used = zip(*df.apply(lambda r: decide_row(r, thr_map, gthr), axis=1))
    df["decision"] = dec
    df["threshold_used"] = thr_used

    # operator-friendly columns
    df["ML Probability"] = (df["y_prob"].round(2) if "y_prob" in df.columns else np.nan)
    df["Signal (Strategy)"] = df.get("signal", "")
    df["Decision Icon"] = [icon(d, bool(m), str(q)) for d, m, q in
                           zip(df["decision"], df["ml_usable"], df.get("quality",""))]

    # sort: BUY first by prob desc, then others alphabetically
    sort_keys = []
    if "ML Probability" in df.columns:
        sort_keys = ["decision", "ML Probability"]
        df["decision_order"] = np.where(df["decision"] == "BUY", 0, 1)
        df = df.sort_values(["decision_order", "ML Probability"], ascending=[True, False]).drop(columns=["decision_order"])
    else:
        df = df.sort_values(["decision", "ticker"])

    pr = P.ROOT / "param_results"
    pr.mkdir(parents=True, exist_ok=True)
    ts = _ts()

    # technical one-row-per-ticker
    tech_cols = [c for c in [
        "entry_dt","date","ticker","signal","y_prob","y_pred","ml_usable",
        "quality","action_guidance","threshold_used","decision"
    ] if c in df.columns]
    out_full = pr / f"final_decisions_{ts}.csv"
    df[tech_cols].to_csv(out_full, index=False)
    print(f"[OK] Decisions (per ticker) → {out_full}")

    # pretty board
    pretty_cols = []
    for c in ("entry_dt","date"):
        if c in df.columns: pretty_cols.append(c); break
    pretty_cols += [c for c in ("ticker","Signal (Strategy)","ML Probability","quality","Decision Icon","decision","action_guidance") if c in df.columns]

    out_pretty = pr / f"final_decisions_pretty_{ts}.csv"
    df[pretty_cols].rename(columns={"quality":"Quality","action_guidance":"Action Guidance"}).to_csv(out_pretty, index=False)
    print(f"[OK] Operator board → {out_pretty}")

    print("\n[Decision counts]")
    print(df["decision"].value_counts(dropna=False).to_string())

if __name__ == "__main__":
    main()