#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
s68_split_dataset.py — Robust split of merged trades into train/val/test WITHOUT dropping rows.

Key features
------------
- Works on unique keys (ticker, entry_dt) to avoid leakage, then merges back to full df.
- Default: chronological split **per ticker** (60/20/20).
- Guard rails on fractions; accepts CSV or Parquet input.
- Enforces minimum sample thresholds on **unique keys** per ticker:
    • --min_total_per_ticker (default 120)
    • --min_per_split        (default 25)
- If ALL tickers are excluded → fallback to global chronological split.
- Writes train/val/test to <ROOT>/data_final_training + split report + counts + meta JSON.

Outputs
-------
<ROOT>/data_final_training/
  - train.csv / train.parquet
  - val.csv   / val.parquet
  - test.csv  / test.parquet

<ROOT>/param_results/
  - s68_split_report.csv
  - s68_unique_key_counts.csv
  - s68_meta.json
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import time
import sys

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

# ---- project-aware paths ----
SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
from common.paths import P   # ROOT, etc.


# ---------------- helpers ----------------

def _latest_merged_trades() -> Path | None:
    """Pick the latest merged CSV/Parquet produced by s67b."""
    md = P.ROOT / "merged_datasets"
    cands = sorted(list(md.glob("trades_enriched_*.csv")) + list(md.glob("trades_enriched_*.parquet")))
    return cands[-1] if cands else None

def _read_merged_any(path: Path) -> pd.DataFrame:
    """Load merged dataset from CSV or Parquet."""
    if path.suffix.lower() == ".parquet":
        return pd.read_parquet(path)
    if path.suffix.lower() == ".csv":
        return pd.read_csv(path)
    # try both if the suffix is odd
    try:
        return pd.read_parquet(path)
    except Exception:
        return pd.read_csv(path)

def _coerce_dt(s: pd.Series) -> pd.Series:
    return pd.to_datetime(s, utc=True, errors="coerce")

def _assert_disjoint(a: pd.DataFrame, b: pd.DataFrame, c: pd.DataFrame, key_cols: list[str]):
    def _keyset(df):
        return set(map(tuple, df[key_cols].itertuples(index=False, name=None)))
    ak, bk, ck = _keyset(a), _keyset(b), _keyset(c)
    ov_ab, ov_ac, ov_bc = len(ak & bk), len(ak & ck), len(bk & ck)
    print(f"[SANITY] Overlap by key: train∩val={ov_ab}, train∩test={ov_ac}, val∩test={ov_bc}")
    if ov_ab or ov_ac or ov_bc:
        raise SystemExit("[ERR] Splits overlap by key — this should never happen.")

def _print_dupes(df: pd.DataFrame, key_cols: list[str], label: str):
    g = (df.value_counts(key_cols).reset_index(name="n"))
    g = g[g["n"] > 1]
    if g.empty:
        print(f"[DUPES] {label}: none.")
    else:
        print(f"[DUPES] {label}: found {len(g)} duplicate keys ({key_cols}). Top 5:")
        print(g.head(5).to_string(index=False))

def _dedupe_by_key(df: pd.DataFrame, key_cols: list[str]) -> tuple[pd.DataFrame, int]:
    before = len(df)
    out = (df.sort_values(key_cols)
             .drop_duplicates(subset=key_cols, keep="first"))
    return out, before - len(out)

def _time_split_per_ticker(groups: pd.DataFrame,
                           train_frac: float,
                           val_frac: float,
                           min_total: int,
                           min_per_split: int) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """
    Chronological split per ticker on unique-key groups.
    groups must have columns ['ticker','entry_dt'] (entry_dt tz-aware UTC).
    Returns (train_g, val_g, test_g, report_df).
    """
    rows = []
    train_parts, val_parts, test_parts = [], [], []
    for tkr, g in groups.groupby("ticker", sort=True):
        g = g.sort_values("entry_dt").reset_index(drop=True)
        n_total = len(g)
        info = {"ticker": tkr, "n_total": n_total, "n_train": 0, "n_val": 0, "n_test": 0,
                "included": False, "reason": ""}

        if n_total < min_total:
            info["reason"] = f"n_total<{min_total}"
            rows.append(info); continue

        n_train = int(np.floor(n_total * train_frac))
        n_val   = int(np.floor(n_total * val_frac))
        n_test  = n_total - n_train - n_val

        # soft clamps so borderline sizes don't get excluded due to rounding
        if n_total >= 3:
            n_train = max(n_train, 1)
            n_val   = max(n_val,   1)
            n_test  = max(n_test,  1)

        if min(n_train, n_val, n_test) < min_per_split:
            info["reason"] = f"min_split<{min_per_split} (train={n_train}, val={n_val}, test={n_test})"
            rows.append(info); continue

        tr = g.iloc[:n_train]
        va = g.iloc[n_train:n_train+n_val]
        te = g.iloc[n_train+n_val:]

        train_parts.append(tr); val_parts.append(va); test_parts.append(te)
        info.update({"n_train": len(tr), "n_val": len(va), "n_test": len(te), "included": True, "reason": "OK"})
        rows.append(info)

    report = pd.DataFrame(rows).sort_values(["included", "n_total"], ascending=[True, False]).reset_index(drop=True)
    train_g = pd.concat(train_parts, ignore_index=True) if train_parts else groups.iloc[0:0]
    val_g   = pd.concat(val_parts,   ignore_index=True) if val_parts   else groups.iloc[0:0]
    test_g  = pd.concat(test_parts,  ignore_index=True) if test_parts  else groups.iloc[0:0]
    return train_g, val_g, test_g, report


# --------------- main ---------------

def parse_args() -> argparse.Namespace:
    default_input = _latest_merged_trades()
    default_out   = P.ROOT / "data_final_training"
    default_meta  = P.ROOT / "param_results"
    p = argparse.ArgumentParser(description="Group-safe split of merged trades into train/val/test.")
    p.add_argument("--input", default=str(default_input) if default_input else None,
                   help="Merged dataset path (CSV or Parquet). Default: latest trades_enriched_* under merged_datasets")
    p.add_argument("--out_dir", default=str(default_out),
                   help="Output dir (default: <ROOT>/data_final_training)")
    p.add_argument("--meta_out_dir", default=str(default_meta),
                   help="Meta dir (default: <ROOT>/param_results)")
    p.add_argument("--mode", choices=["random","time_global","time_per_ticker"], default="time_per_ticker",
                   help="Split mode. Default: time_per_ticker (robust).")
    p.add_argument("--seed", type=int, default=42, help="Random seed (random mode)")
    p.add_argument("--train_frac", type=float, default=0.60, help="Train fraction")
    p.add_argument("--val_frac", type=float, default=0.20, help="Val fraction (test = 1 - train - val if --test_frac not set)")
    p.add_argument("--test_frac", type=float, default=None,
                   help="Optional test fraction; if omitted, computed as 1 - train - val")
    p.add_argument("--date_col", default="entry_dt", help="Date column (default: entry_dt)")
    p.add_argument("--min_total_per_ticker", type=int, default=120,
               help="Exclude ticker if unique keys < this number (default 120).")
    p.add_argument("--min_per_split", type=int, default=25,
               help="Exclude ticker if any split < this number (default 25).")
    p.add_argument("--dedupe_within_split", action="store_true",
                   help="Drop duplicate rows within each split by key (ticker,date_col).")
    return p.parse_args()

def main():
    args = parse_args()
    if not args.input:
        raise SystemExit("[ERR] --input not provided and no merged file found.")

    # ---- guard rails on fractions
    if not (0 < args.train_frac < 1):
        raise SystemExit("[ERR] train_frac must be in (0,1).")
    if not (0 <= args.val_frac < 1):
        raise SystemExit("[ERR] val_frac must be in [0,1).")
    test_frac = args.test_frac
    if test_frac is None:
        test_frac = 1.0 - args.train_frac - args.val_frac
    if not (0 < test_frac < 1):
        raise SystemExit("[ERR] test_frac must be in (0,1) and train+val+test must be 1.")
    if round(args.train_frac + args.val_frac + test_frac, 6) != 1.0:
        raise SystemExit("[ERR] Fractions must sum to 1.")

    in_path = Path(args.input)
    out_dir = Path(args.out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    meta_dir = Path(args.meta_out_dir); meta_dir.mkdir(parents=True, exist_ok=True)

    print(f"[INFO] Loading dataset: {in_path}")
    df_full = _read_merged_any(in_path)

    # keys
    if "ticker" not in df_full.columns or args.date_col not in df_full.columns:
        raise SystemExit(f"[ERR] Expected columns 'ticker' and '{args.date_col}' in merged dataset.")
    df_full["ticker"] = df_full["ticker"].astype(str)
    df_full[args.date_col] = _coerce_dt(df_full[args.date_col])
    if df_full[args.date_col].isna().all():
        raise SystemExit(f"[ERR] Could not parse any {args.date_col} timestamps.")
    key_cols = ["ticker", args.date_col]

    # Report dupes in full dataset (informational)
    _print_dupes(df_full, key_cols, "MERGED")

    # unique groups (no row loss later)
    groups = df_full[key_cols].drop_duplicates().sort_values(key_cols).reset_index(drop=True)

    # --- DIAGNOSTIC: per-ticker unique-key counts ---
    counts = (groups.groupby("ticker")
                    .size()
                    .rename("unique_keys")
                    .reset_index()
                    .sort_values("unique_keys", ascending=False))
    counts_csv = meta_dir / "s68_unique_key_counts.csv"
    counts.to_csv(counts_csv, index=False)
    print(f"[INFO] Wrote per-ticker unique-key counts → {counts_csv}")
    print("[INFO] Top 10 tickers by unique keys:")
    print(counts.head(10).to_string(index=False))
    print("[INFO] Bottom 10 tickers by unique keys:")
    print(counts.tail(10).to_string(index=False))

    # choose split on groups
    mode = args.mode
    train_g = val_g = test_g = None
    split_report = None

    if mode == "random":
        strat = groups["ticker"] if groups["ticker"].nunique() > 1 else None
        train_g, temp_g = train_test_split(groups, train_size=args.train_frac, random_state=args.seed,
                                           stratify=strat, shuffle=True)
        val_share = args.val_frac / (1.0 - args.train_frac)
        strat_temp = temp_g["ticker"] if temp_g["ticker"].nunique() > 1 else None
        val_g, test_g = train_test_split(temp_g, train_size=val_share, random_state=args.seed,
                                         stratify=strat_temp, shuffle=True)
        print(f"[INFO] Random split (groups) → train={len(train_g):,}, val={len(val_g):,}, test={len(test_g):,} groups")

    elif mode == "time_global":
        g = groups.sort_values(args.date_col).reset_index(drop=True)
        n = len(g)
        n_train = int(np.floor(n * args.train_frac))
        n_val   = int(np.floor(n * args.val_frac))
        # ensure at least 1 in each (if enough data)
        if n >= 3:
            n_train = max(n_train, 1)
            n_val   = max(n_val,   1)
        train_g = g.iloc[:n_train]
        val_g   = g.iloc[n_train:n_train+n_val]
        test_g  = g.iloc[n_train+n_val:]
        print(f"[INFO] Time-global split (groups) → train={len(train_g):,}, val={len(val_g):,}, test={len(test_g):,} groups")

    else:  # time_per_ticker (robust default)
        # Perform per-ticker chronological with thresholds
        g_ren = groups.rename(columns={args.date_col: "entry_dt"})
        train_g, val_g, test_g, split_report = _time_split_per_ticker(
            groups=g_ren,
            train_frac=args.train_frac,
            val_frac=args.val_frac,
            min_total=args.min_total_per_ticker,
            min_per_split=args.min_per_split
        )
        # rename back if custom date_col was used
        train_g = train_g.rename(columns={"entry_dt": args.date_col})
        val_g   = val_g.rename(columns={"entry_dt": args.date_col})
        test_g  = test_g.rename(columns={"entry_dt": args.date_col})

        rep_csv = meta_dir / "s68_split_report.csv"
        split_report.to_csv(rep_csv, index=False)
        kept = int(split_report["included"].sum())
        dropped = int((~split_report["included"]).sum())
        print(f"[INFO] Per-ticker chronological split → kept={kept}, excluded={dropped} (report: {rep_csv})")

        # If everything excluded, auto-fallback to global time split so outputs aren't empty
        if kept == 0:
            print("[WARN] All tickers excluded by thresholds on unique keys. Falling back to time_global.")
            g = groups.sort_values(args.date_col).reset_index(drop=True)
            n = len(g)
            n_train = int(np.floor(n * args.train_frac))
            n_val   = int(np.floor(n * args.val_frac))
            if n >= 3:
                n_train = max(n_train, 1)
                n_val   = max(n_val,   1)
            train_g = g.iloc[:n_train]
            val_g   = g.iloc[n_train:n_train+n_val]
            test_g  = g.iloc[n_train+n_val:]

    # tag groups and merge back to FULL df
    def _tag(df_keys: pd.DataFrame, tag: str) -> pd.DataFrame:
        out = df_keys.copy()
        out["__split__"] = tag
        return out

    tags = pd.concat([_tag(train_g, "train"), _tag(val_g, "val"), _tag(test_g, "test")],
                     ignore_index=True)

    tagged = df_full.merge(tags, on=key_cols, how="inner")
    if len(tagged) != len(df_full):
        print(f"[WARN] Rows without split tag (should be 0): {len(df_full) - len(tagged)}")

    train_df = tagged[tagged["__split__"] == "train"].drop(columns="__split__")
    val_df   = tagged[tagged["__split__"] == "val"].drop(columns="__split__")
    test_df  = tagged[tagged["__split__"] == "test"].drop(columns="__split__")

    # disjointness + dupes
    _assert_disjoint(train_df, val_df, test_df, key_cols)
    _print_dupes(train_df, key_cols, "TRAIN (pre-dedupe)")
    _print_dupes(val_df,   key_cols, "VAL (pre-dedupe)")
    _print_dupes(test_df,  key_cols, "TEST (pre-dedupe)")

    # optional: dedupe within split
    if args.dedupe_within_split:
        train_df, rm_tr = _dedupe_by_key(train_df, key_cols)
        val_df,   rm_va = _dedupe_by_key(val_df,   key_cols)
        test_df,  rm_te = _dedupe_by_key(test_df,  key_cols)
        print(f"[CLEAN] Removed dupes within splits by {key_cols}: train -{rm_tr}, val -{rm_va}, test -{rm_te}")

    # write outputs
    out_dir.mkdir(parents=True, exist_ok=True)
    paths = {
        "train": (out_dir / "train.csv",  out_dir / "train.parquet",  train_df),
        "val":   (out_dir / "val.csv",    out_dir / "val.parquet",    val_df),
        "test":  (out_dir / "test.csv",   out_dir / "test.parquet",   test_df),
    }
    n_all = len(df_full)
    for name, (csvp, pqp, df) in paths.items():
        df.to_csv(csvp, index=False)
        df.to_parquet(pqp, index=False)
        print(f"[OK] {name.capitalize():5s} → {csvp}  ({len(df):,} rows, {len(df)/n_all:6.2%})")
    print("[OK] Also wrote Parquet versions alongside CSVs.")

    # meta JSON
    meta = {
        "created_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "input": str(in_path),
        "mode": args.mode,
        "fractions": {"train": args.train_frac, "val": args.val_frac, "test": float(test_frac)},
        "min_total_per_ticker": args.min_total_per_ticker,
        "min_per_split": args.min_per_split,
        "rows_full": int(len(df_full)),
        "rows_train": int(len(train_df)),
        "rows_val": int(len(val_df)),
        "rows_test": int(len(test_df)),
        "key_cols": key_cols,
    }
    (meta_dir / "s68_meta.json").write_text(json.dumps(meta, indent=2))
    print(f"[OK] Wrote meta → {meta_dir/'s68_meta.json'}")
    print("[DONE] s68 complete.")

if __name__ == "__main__":
    main()