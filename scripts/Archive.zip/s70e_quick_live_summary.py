#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
s70e_quick_live_summary.py
Quick audit of the latest s70 live CSV with Quality + Guidance + ml_usable.

Purpose
-------
- Finds the most recent live file from s70 (s70_results_with_guidance_<ts>.csv).
- Prints counts of ml_usable True/False/NaN.
- Lists top tickers with ML usable, and those excluded (no ML).
- Helps verify whitelist/quality overrides were applied correctly before merging into s7x signals table.

Inputs
------
<ROOT>/param_results/s70_results_with_guidance_<ts>.csv

Outputs
-------
- Console report only (no files written).
- Example sections:
  [ml_usable counts]
  [Tickers using ML (top 20)]
  [Tickers NOT using ML (top 20)]

Typical run
-----------
python scripts/s70e_quick_live_summary.py
"""
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
live = sorted((ROOT / "param_results").glob("s70_results_with_guidance_*.csv"))[-1]
df = pd.read_csv(live)

print(f"[INFO] Live file: {live}")
print("\n[ml_usable counts]")
print(df["ml_usable"].value_counts(dropna=False).to_string())

print("\n[Tickers using ML (top 20 by rows)]")
print((df[df["ml_usable"]==True]["ticker"].value_counts().head(20)).to_string())

print("\n[Tickers NOT using ML (top 20 by rows)]")
print((df[df["ml_usable"]==False]["ticker"].value_counts().head(20)).to_string())