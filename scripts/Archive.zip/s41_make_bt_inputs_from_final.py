#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
s41_make_bt_inputs_from_final.py
Create per-ticker DAILY *_bt.csv for s50 (daily engine) using the enriched parquet.

Context
-------
- Part of the daily backtest stream.
- Converts the enriched daily parquet (from s30) into lightweight per-ticker daily CSVs.
- These serve as direct inputs for s50 (daily backtest engine).
- Ensures required columns exist, computes missing EMAs if needed, and derives entry signals.

Reads
-----
- P.DATA_ENRICHED/prices_enriched.parquet   (from s30)

Processing
----------
- Normalize datetime → UTC, clean OHLC values
- Ensure EMAs: ema5, ema20, ema44
- Compute/validate entry_signal (ema5>ema20 & close>ema20 fallback if missing)
- Split by ticker

Writes
------
- P.ROOT/backtest_data/daily/{TICKER}_bt.csv
- Columns: datetime, ticker, open, high, low, close, ema5, ema20, ema44, entry_signal
"""

from pathlib import Path
import sys
import pandas as pd

# --- import centralized paths (works in QuantETF and QuantETFUS) ---
SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
from common.paths import P  # noqa: E402

FINAL = P.DATA_ENRICHED / "prices_enriched.parquet"   # <— changed
OUTDIR = P.ROOT / "backtest_data" / "daily"

REQUIRED_BASE = ["datetime","ticker","open","high","low","close"]
EMA_COLS = ["ema5","ema20","ema44"]
SIGNAL_COL = "entry_signal"

def _ensure_emas(df: pd.DataFrame) -> pd.DataFrame:
    """Compute EMAs if missing."""
    need = [c for c in EMA_COLS if c not in df.columns]
    if not need:
        return df
    df = df.sort_values(["ticker","datetime"]).copy()
    def _ema(s, n): return s.ewm(span=n, adjust=False).mean()
    df["ema5"]  = df.groupby("ticker", group_keys=False)["close"].apply(lambda s: _ema(s, 5))
    df["ema20"] = df.groupby("ticker", group_keys=False)["close"].apply(lambda s: _ema(s, 20))
    df["ema44"] = df.groupby("ticker", group_keys=False)["close"].apply(lambda s: _ema(s, 44))
    return df

def _default_signal(df: pd.DataFrame) -> pd.Series:
    """Fallback entry signal if none provided."""
    return (df["ema5"] > df["ema20"]) & (df["close"] > df["ema20"])

def main():
    if not FINAL.exists():
        raise SystemExit(f"[ERR] Missing {FINAL} — run s30 to build it first.")

    OUTDIR.mkdir(parents=True, exist_ok=True)

    df = pd.read_parquet(FINAL)
    df.columns = [c.strip().lower() for c in df.columns]

    # Normalize & basic checks
    missing = [c for c in REQUIRED_BASE if c not in df.columns]
    if missing:
        raise SystemExit(f"[ERR] parquet missing columns: {missing}")
    df["datetime"] = pd.to_datetime(df["datetime"], utc=True, errors="coerce")
    df = df.dropna(subset=["datetime","ticker"]).copy()

    # Ensure numeric OHLC
    for c in ["open","high","low","close"]:
        df[c] = pd.to_numeric(df[c], errors="coerce")

    # Ensure EMAs exist (compute if needed)
    df = _ensure_emas(df)

    # Entry signal
    if SIGNAL_COL in df.columns:
        sig = df[SIGNAL_COL].astype(bool)
    else:
        sig = _default_signal(df)

    base = df[REQUIRED_BASE + EMA_COLS].copy()
    base[SIGNAL_COL] = sig

    # Per‑ticker files
    tickers = base["ticker"].dropna().astype(str).unique()
    count = 0
    for t in tickers:
        g = base[base["ticker"] == t].sort_values("datetime").reset_index(drop=True)
        if g.empty:
            continue
        out = OUTDIR / f"{t}_bt.csv"
        g.to_csv(out, index=False)
        count += 1

    print(f"[OK] Wrote {count} file(s) to {OUTDIR}")

if __name__ == "__main__":
    main()