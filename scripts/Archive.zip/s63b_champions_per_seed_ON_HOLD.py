#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
s63b_champions_per_seed.py
Pick per-seed champions (best combo per ticker within each seed) and compute stability across seeds.

- Works in both QuantETF and QuantETFUS by importing project-aware paths from common.paths.P
- Scans P.PARAM_RESULTS for ranked per‑ticker CSVs from s62:
    param_results_{TICKER}_{SUFFIX}.csv
  …ignoring:
    - global files: param_results_ALL_*.csv
    - unfiltered per‑ticker files: *_ALL.csv

We parse the seed from the filename suffix (e.g. “…seed4”). If a file lacks a seed tag,
it’ll be tagged as “seed_unknown” but still included.

Outputs (under P.PARAM_RESULTS/s63b):
  - s63b_per_seed_champions_{TS}.csv         (one row per ticker per seed = the champion)
  - s63b_ticker_stability_{TS}.csv           (cross-seed stats per ticker)
  - s63b_seed_coverage_{TS}.csv              (which seeds we saw per ticker)

CLI knobs:
  --filename_contains  substring filter (default "_S6000")
  --min_trades         optional filter before choosing champions
  --n_jobs             parallel file loading (default: 4)
"""

from pathlib import Path
from datetime import datetime, timezone
import re
import json
import argparse
import os
import sys
import numpy as np
import pandas as pd
from joblib import Parallel, delayed

# --- force single-threaded math to avoid oversubscription ---
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("VECLIB_MAXIMUM_THREADS", "1")
os.environ.setdefault("NUMEXPR_NUM_THREADS", "1")

# ---- import shared paths (project‑aware)
SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
from common.paths import P  # dynamic per-project paths

# -------- paths (via P) --------
PARAM_RESULTS = P.PARAM_RESULTS
OUT_DIR = PARAM_RESULTS / "s63b"
CONFIG = P.CONFIG_DIR / "s60_parameters.json"

# -------- helpers --------
def _ts() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%d_%H%M")

def _load_param_keys(config_path: Path) -> list[str]:
    with open(config_path, "r") as f:
        cfg = json.load(f)
    # keep order stable
    return list(cfg.keys())

def _is_ranked_file(p: Path) -> bool:
    name = p.name
    if not name.startswith("param_results_"):
        return False
    if name.startswith("param_results_ALL_"):
        return False
    if name.endswith("_ALL.csv"):
        return False
    return name.endswith(".csv")

def _find_ranked_csvs(param_dir: Path, filename_contains: str) -> list[Path]:
    files = [p for p in param_dir.glob("param_results_*_*.csv") if _is_ranked_file(p)]
    if filename_contains:
        files = [p for p in files if filename_contains in p.name]
    return sorted(files)

def _parse_ticker_and_suffix(path: Path) -> tuple[str, str]:
    # param_results_{TICKER}_{SUFFIX}.csv
    base = path.name
    body = base[len("param_results_"):-len(".csv")]
    if "_" not in body:
        return body, "UNKNOWN"
    ticker, suffix = body.split("_", 1)
    return ticker, suffix

def _parse_seed_from_suffix(suffix: str) -> str:
    # looks for "seed{N}" anywhere in the suffix
    m = re.search(r"seed(\d+)", suffix)
    if m:
        return f"seed{m.group(1)}"
    return "seed_unknown"

def _load_ranked_file(p: Path, param_keys: list[str], min_trades: int) -> pd.DataFrame:
    """Read a ranked per-ticker CSV and normalize dtypes/columns."""
    tkr, suffix = _parse_ticker_and_suffix(p)
    seed = _parse_seed_from_suffix(suffix)

    try:
        df = pd.read_csv(p)
    except Exception as e:
        print(f"[WARN] Failed to read {p.name}: {e}")
        return pd.DataFrame()

    if df is None or df.empty:
        return pd.DataFrame()

    # ensure required metric columns exist, coerce numerics
    for c in ["total_return", "num_trades", "win_rate"]:
        if c not in df.columns:
            df[c] = np.nan
        df[c] = pd.to_numeric(df[c], errors="coerce")

    if min_trades and "num_trades" in df.columns:
        df = df[df["num_trades"] >= min_trades].copy()
        if df.empty:
            return pd.DataFrame()

    # ensure param columns exist (for traceability)
    for k in param_keys:
        if k not in df.columns:
            df[k] = np.nan

    df["ticker"] = tkr
    df["run_id"] = suffix
    df["seed"] = seed
    df["source_file"] = p.name

    return df

# -------- main --------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--param_dir", type=str, default=str(PARAM_RESULTS),
                    help="Directory with per-ticker ranked CSVs from s62.")
    ap.add_argument("--config", type=str, default=str(CONFIG),
                    help="Path to s60_parameters.json (to detect param columns).")
    ap.add_argument("--filename_contains", type=str, default="_S6000",
                    help="Only ingest ranked files whose names contain this substring "
                         '(e.g., "_S6000" or "_S6000-per_ticker"). Use "" to disable.')
    ap.add_argument("--min_trades", type=int, default=0,
                    help="Ignore rows with num_trades < min_trades before champion pick.")
    ap.add_argument("--n_jobs", type=int, default=4,
                    help="Parallel workers for reading CSVs.")
    args = ap.parse_args()

    param_dir = Path(args.param_dir)
    config_path = Path(args.config)
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    if not param_dir.exists():
        raise SystemExit(f"[ERR] param_dir not found: {param_dir}")
    if not config_path.exists():
        raise SystemExit(f"[ERR] config file not found: {config_path}")

    param_keys = _load_param_keys(config_path)
    files = _find_ranked_csvs(param_dir, args.filename_contains)
    if not files:
        raise SystemExit(f"[ERR] No ranked per-ticker CSVs matched in {param_dir} "
                         f"(filter='{args.filename_contains}').")

    print(f"[INFO] Matched {len(files)} ranked files.")
    # parallel load
    parts = Parallel(n_jobs=args.n_jobs, backend="loky")(
        delayed(_load_ranked_file)(p, param_keys, args.min_trades) for p in files
    )
    df_all = pd.concat([x for x in parts if x is not None and not x.empty],
                       ignore_index=True) if parts else pd.DataFrame()
    if df_all.empty:
        raise SystemExit("[ERR] No data loaded after filtering.")

    # Coerce sort metrics (defensive)
    df_all["total_return"] = pd.to_numeric(df_all["total_return"], errors="coerce")
    df_all["num_trades"] = pd.to_numeric(df_all["num_trades"], errors="coerce")
    df_all["win_rate"] = pd.to_numeric(df_all["win_rate"], errors="coerce")

    # ---- per-seed champions (best per ticker within each seed) ----
    df_sorted = df_all.sort_values(
        by=["ticker", "seed", "total_return", "num_trades", "win_rate"],
        ascending=[True, True, False, False, False]
    )
    per_seed_champs = (
        df_sorted.groupby(["ticker", "seed"], as_index=False).head(1).reset_index(drop=True)
    )

    # ---- seed coverage table ----
    cov = (per_seed_champs.groupby("ticker")["seed"]
           .nunique()
           .reset_index(name="count_seeds"))
    cov["seeds_list"] = (per_seed_champs.groupby("ticker")["seed"]
                         .apply(lambda s: ",".join(sorted(s.unique()))).values)

    # ---- ticker stability across seeds ----
    stab_rows = []
    for tkr, g in per_seed_champs.groupby("ticker", as_index=False):
        tr = pd.to_numeric(g["total_return"], errors="coerce")
        nt = pd.to_numeric(g["num_trades"], errors="coerce")
        wr = pd.to_numeric(g["win_rate"], errors="coerce")

        row = {
            "ticker": tkr,
            "count_seeds": int(g["seed"].nunique()),
            "observations": int(len(g)),
            "mean_return": float(tr.mean()),
            "median_return": float(tr.median()),
            "best_return": float(tr.max()),
            "worst_return": float(tr.min()),
            "std_return": float(tr.std(ddof=0)) if len(tr) else np.nan,
            "mean_num_trades": float(nt.mean()),
            "mean_win_rate": float(wr.mean()),
            "seed_list": ",".join(sorted(g["seed"].unique())),
            "run_ids": ",".join(sorted(g["run_id"].unique())),
        }
        # store modal param values for reference (handy for audits)
        for k in _load_param_keys(config_path):
            if k in g.columns:
                vals = g[k].mode(dropna=False)
                row[k] = (vals.iloc[0] if len(vals) else np.nan)
        stab_rows.append(row)

    stability = pd.DataFrame(stab_rows)
    # Final score: emphasize mean_return; small bonuses for breadth & volume
    stability["final_score"] = (
        stability["mean_return"].fillna(0.0)
        + 0.001 * stability["count_seeds"].fillna(0.0)
        + 0.0001 * stability["mean_num_trades"].fillna(0.0)
        + 0.0001 * stability["mean_win_rate"].fillna(0.0)
    )

    # ---- save outputs ----
    ts = _ts()
    out_champs = OUT_DIR / f"s63b_per_seed_champions_{ts}.csv"
    out_stab = OUT_DIR / f"s63b_ticker_stability_{ts}.csv"
    out_cov = OUT_DIR / f"s63b_seed_coverage_{ts}.csv"

    per_seed_champs.to_csv(out_champs, index=False)
    stability.sort_values(
        ["final_score", "count_seeds", "mean_return"], ascending=[False, False, False]
    ).to_csv(out_stab, index=False)
    cov.sort_values(["count_seeds", "ticker"], ascending=[False, True]).to_csv(out_cov, index=False)

    print(f"[OK] Wrote per-seed champions → {out_champs}")
    print(f"[OK] Wrote ticker stability   → {out_stab}")
    print(f"[OK] Wrote seed coverage      → {out_cov}")
    print("[HINT] Inspect 'count_seeds' and 'std_return':")
    print("       - High count_seeds + low std_return = robust.")
    print("       - Low count_seeds or high std_return = consider more seeds or review params.")

if __name__ == "__main__":
    main()