#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
s70c_pick_threshold_from_val.py
Pick a global decision threshold using the latest VALIDATION predictions to maximize F1
subject to a minimum precision constraint (default >= 0.55). Then:
- runs s70 with that threshold,
- prints split metrics via s70a.

Run (no extra flags needed):
    python scripts/s70c_pick_threshold_from_val.py

Optional flags:
    --min_precision 0.60     # precision floor
    --step 0.01              # threshold step
    --dry_run                # only print chosen threshold, do not retrain
"""

from __future__ import annotations
from pathlib import Path
import argparse
import re
import sys
import subprocess
import pandas as pd
import numpy as np
from sklearn.metrics import precision_score, recall_score, f1_score

ROOT = Path(__file__).resolve().parent.parent
PY   = str(ROOT / "venv" / "bin" / "python")
S70  = str(ROOT / "scripts" / "s70_train_model_classifier_calibrated.py")
S70A = str(ROOT / "scripts" / "s70a_metrics_split_report.py")
MODELS = ROOT / "models"

def _latest_val_preds() -> Path:
    # Find latest classifier_val_predictions_YYYYMMDD_HHMM.csv
    pats = sorted(MODELS.glob("classifier_val_predictions_*.csv"))
    if not pats:
        print("[ERR] No validation prediction files found in models/. Run s70 first.", file=sys.stderr)
        sys.exit(1)
    return pats[-1]

def _ts_from_name(p: Path) -> str:
    m = re.search(r"_(\d{8}_\d{4})\.csv$", p.name)
    return m.group(1) if m else "NA"

def _pick_threshold(df: pd.DataFrame, min_prec: float = 0.55, step: float = 0.01) -> dict:
    if not {"y_true","y_prob"}.issubset(df.columns):
        raise SystemExit("[ERR] Validation CSV must contain y_true and y_prob columns.")
    y_true = df["y_true"].astype(int).values
    y_prob = df["y_prob"].astype(float).values

    best = {"thr": 0.50, "precision": np.nan, "recall": np.nan, "f1": -1.0}
    thr_values = np.arange(0.0, 1.000001, step)
    for thr in thr_values:
        y_pred = (y_prob >= thr).astype(int)
        prec = precision_score(y_true, y_pred, zero_division=0)
        rec  = recall_score(y_true, y_pred, zero_division=0)
        f1   = f1_score(y_true, y_pred, zero_division=0)
        # constraint: precision >= min_prec
        if prec >= min_prec and f1 > best["f1"]:
            best = {"thr": float(thr), "precision": float(prec), "recall": float(rec), "f1": float(f1)}
    return best

def _run(cmd):
    print("+", " ".join(cmd))
    r = subprocess.run(cmd)
    if r.returncode != 0:
        sys.exit(r.returncode)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--min_precision", type=float, default=0.55, help="Precision floor for threshold search (validation).")
    ap.add_argument("--step", type=float, default=0.01, help="Threshold step.")
    ap.add_argument("--dry_run", action="store_true", help="Only print chosen threshold; do not retrain.")
    args = ap.parse_args()

    val_fp = _latest_val_preds()
    df_val = pd.read_csv(val_fp)
    choice = _pick_threshold(df_val, min_prec=args.min_precision, step=args.step)

    print(f"[INFO] Latest VAL preds: {val_fp.name}")
    print(f"[INFO] Chosen threshold (precision >= {args.min_precision:.2f}): "
          f"thr={choice['thr']:.2f}  | prec={choice['precision']:.3f}  "
          f"| rec={choice['recall']:.3f} | f1={choice['f1']:.3f}")

    if args.dry_run:
        return

    # Retrain/export with chosen threshold
    _run([PY, S70, "--decision_threshold", str(choice["thr"])])
    # Print split metrics summary
    _run([PY, S70A])

if __name__ == "__main__":
    main()