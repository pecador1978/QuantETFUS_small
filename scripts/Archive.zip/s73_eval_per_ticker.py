#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
s73_eval_per_ticker.py — Per-ticker metrics for TRAIN / VAL / TEST with optional per-ticker thresholds.

What it does
------------
- Auto-loads the latest prediction CSVs produced by s70:
    models/classifier_{train,val,test}_predictions_*.csv
  Each file must contain at least: ['ticker','y_true'] and either
  - 'y_pred' (then we can compute counts directly), or
  - 'y_prob' (preferred; lets us re-threshold)

- If a per-ticker thresholds file from s70b exists:
    param_results/s70b_per_ticker_thresholds_*.csv
  the script will compute a second set of metrics using the per-ticker threshold
  (column 'thr_star', else tries 'thr_best'/'thr_opt').

Outputs
-------
- models/per_ticker_metrics_train_<ts>.csv
- models/per_ticker_metrics_val_<ts>.csv
- models/per_ticker_metrics_test_<ts>.csv
- models/per_ticker_metrics_ALL_<ts>.csv   (stacked with 'split' column)

Notes
-----
- Global threshold defaults to 0.50; if 'threshold_used' exists in the file it is used.
- When per-ticker thresholds are available but a ticker is missing a threshold,
  we fall back to the global threshold for that ticker and tag decision_rule="global_fallback".
"""

from __future__ import annotations
from pathlib import Path
from datetime import datetime, timezone
import sys
import numpy as np
import pandas as pd

# project-aware paths
SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
from common.paths import P  # ROOT, etc.

def _ts() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%d_%H%M")

def _latest(globpat: str, base: Path) -> Path | None:
    cands = sorted(base.glob(globpat))
    return cands[-1] if cands else None

def _load_preds(split: str) -> pd.DataFrame:
    fp = _latest(f"classifier_{split}_predictions_*.csv", P.ROOT / "models")
    if not fp:
        raise SystemExit(f"[ERR] Missing predictions for {split}.")
    df = pd.read_csv(fp)
    if "ticker" not in df.columns or "y_true" not in df.columns:
        raise SystemExit(f"[ERR] {fp} must contain 'ticker' and 'y_true'.")
    # discover global threshold if present
    thr = 0.50
    if "threshold_used" in df.columns:
        try:
            vals = pd.to_numeric(df["threshold_used"], errors="coerce").dropna().unique()
            if len(vals) == 1:
                thr = float(vals[0])
        except Exception:
            pass
    return df, thr, fp

def _load_s70b_thresholds() -> dict[str, float]:
    pr = P.ROOT / "param_results"
    f = _latest("s70b_per_ticker_thresholds_*.csv", pr)
    if not f:
        return {}
    tdf = pd.read_csv(f)
    thr_col = None
    for c in ["thr_star", "thr_best", "thr_opt", "thr_val_star"]:
        if c in tdf.columns:
            thr_col = c
            break
    if thr_col is None or "ticker" not in tdf.columns:
        return {}
    tdf = tdf.loc[np.isfinite(tdf[thr_col]), ["ticker", thr_col]]
    return dict(zip(tdf["ticker"].astype(str), tdf[thr_col].astype(float)))
    print(f"[INFO] Using per-ticker thresholds file: {f.name}")
    print(f"[INFO] Threshold column detected: {thr_col}  | tickers={tdf['ticker'].nunique()}")

def _metrics(y_true: np.ndarray, y_prob: np.ndarray, thr: np.ndarray | float):
    # normalize inputs
    y_true = np.asarray(y_true).astype(int)
    y_prob = np.asarray(y_prob).astype(float)
    if y_true.size == 0:
        return {
            "accuracy": np.nan, "precision": np.nan, "recall": np.nan, "f1": np.nan,
            "roc_auc": np.nan, "brier": np.nan, "log_loss": np.nan,
            "tn": 0, "fp": 0, "fn": 0, "tp": 0
        }

    # threshold vector
    if np.isscalar(thr):
        thr_vec = np.full_like(y_prob, float(thr), dtype=float)
    else:
        thr_vec = np.asarray(thr, dtype=float)
        if thr_vec.shape != y_prob.shape:
            thr_vec = np.full_like(y_prob, 0.50, dtype=float)

    y_pred = (y_prob >= thr_vec).astype(int)

    from sklearn.metrics import (
        accuracy_score, precision_score, recall_score, f1_score, roc_auc_score,
        brier_score_loss, log_loss, confusion_matrix
    )

    # classification metrics (always defined even for single-class via zero_division)
    acc = float(accuracy_score(y_true, y_pred))
    prec = float(precision_score(y_true, y_pred, zero_division=0))
    rec = float(recall_score(y_true, y_pred, zero_division=0))
    f1 = float(f1_score(y_true, y_pred, zero_division=0))

    # probability metrics (guard single-class edge cases)
    try:
        auc = float(roc_auc_score(y_true, y_prob))
    except Exception:
        auc = float("nan")
    try:
        br = float(brier_score_loss(y_true, y_prob))
    except Exception:
        br = float("nan")
    try:
        ll = float(log_loss(y_true, np.clip(y_prob, 1e-6, 1 - 1e-6), labels=[0, 1]))
    except Exception:
        ll = float("nan")

    # confusion matrix robust to single-class
    try:
        tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()
    except Exception:
        # Construct counts manually as a last resort
        tn = int(((y_true == 0) & (y_pred == 0)).sum())
        fp = int(((y_true == 0) & (y_pred == 1)).sum())
        fn = int(((y_true == 1) & (y_pred == 0)).sum())
        tp = int(((y_true == 1) & (y_pred == 1)).sum())

    return {
        "accuracy": acc, "precision": prec, "recall": rec, "f1": f1,
        "roc_auc": auc, "brier": br, "log_loss": ll,
        "tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp),
    }

def _per_ticker(df: pd.DataFrame, global_thr: float, thr_map: dict[str,float] | None):
    need_prob = "y_prob" in df.columns
    if not need_prob and "y_pred" not in df.columns:
        raise SystemExit("[ERR] Need 'y_prob' or 'y_pred' in predictions.")
    rows = []
    for tkr, g in df.groupby("ticker", dropna=False):
        tkr = str(tkr)
        y_true = g["y_true"].astype(int).values
        if "y_prob" in g.columns and np.isfinite(g["y_prob"]).any():
            y_prob = pd.to_numeric(g["y_prob"], errors="coerce").fillna(0.5).values
        else:
            # synth prob from y_pred if absolutely needed
            yp = g["y_pred"].astype(int).values
            y_prob = yp.astype(float)

        # Global
        m_glob = _metrics(y_true, y_prob, global_thr)
        # Per-ticker (if available)
        if thr_map and tkr in thr_map and np.isfinite(thr_map[tkr]):
            m_local = _metrics(y_true, y_prob, float(thr_map[tkr]))
            rule = "per_ticker"
            thr_used = float(thr_map[tkr])
        else:
            m_local = _metrics(y_true, y_prob, global_thr)
            rule = "global_fallback"
            thr_used = float(global_thr)

        rows.append({
            "ticker": tkr,
            "n": int(len(g)),
            # global
            "accuracy": m_glob["accuracy"],
            "precision": m_glob["precision"],
            "recall": m_glob["recall"],
            "f1": m_glob["f1"],
            "roc_auc": m_glob["roc_auc"],
            "thr_used_global": float(global_thr),
            # per-ticker-applied
            "accuracy_pt": m_local["accuracy"],
            "precision_pt": m_local["precision"],
            "recall_pt": m_local["recall"],
            "f1_pt": m_local["f1"],
            "thr_used_pt": thr_used,
            "decision_rule": rule
        })
    out = pd.DataFrame(rows).sort_values(["ticker"]).reset_index(drop=True)
    return out

def main():
    thr_map = _load_s70b_thresholds()
    if thr_map:
        print(f"[INFO] Found per-ticker thresholds (s70b): {len(thr_map)} tickers.")

    ts = _ts()  # single timestamp for this whole run
    outputs = []

    for split in ["train", "val", "test"]:
        df, gthr, src = _load_preds(split)
        print(f"[INFO] {split.upper()} from {src}")

        # prefer y_prob; clean to floats if present
        if "y_prob" in df.columns:
            df["y_prob"] = pd.to_numeric(df["y_prob"], errors="coerce").fillna(0.5).astype(float)

        per = _per_ticker(df, gthr, thr_map if thr_map else None)

        out_path = P.ROOT / "models" / f"per_ticker_metrics_{split}_{ts}.csv"
        per.to_csv(out_path, index=False)
        print(f"[OK] {split.upper()} per-ticker → {out_path}")

        per = per.copy()
        per.insert(0, "split", split)
        outputs.append(per)

    all_df = pd.concat(outputs, axis=0, ignore_index=True)
    all_path = P.ROOT / "models" / f"per_ticker_metrics_ALL_{ts}.csv"
    all_df.to_csv(all_path, index=False)
    print(f"[OK] ALL splits (stacked) → {all_path}")

    # quick console sanity
    print("\n[Preview TEST top 10 by AUC]")
    try:
        print(all_df[all_df["split"]=="test"]
              .sort_values("roc_auc", ascending=False)
              .head(10)[["ticker","n","roc_auc","f1","accuracy","thr_used_pt","decision_rule"]]
              .to_string(index=False))
    except Exception:
        pass

if __name__ == "__main__":
    main()